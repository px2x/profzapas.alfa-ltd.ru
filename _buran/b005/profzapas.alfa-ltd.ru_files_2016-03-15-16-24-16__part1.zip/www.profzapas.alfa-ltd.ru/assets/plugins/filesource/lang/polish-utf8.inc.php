<?php
$_lang["Static file path"] = 'Ścieżka do pliku statycznego';
