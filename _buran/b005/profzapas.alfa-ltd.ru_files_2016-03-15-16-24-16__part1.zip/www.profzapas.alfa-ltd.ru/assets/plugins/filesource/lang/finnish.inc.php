<?php
$_lang["Static file path"] = 'Staattinen tiedostopolku';
