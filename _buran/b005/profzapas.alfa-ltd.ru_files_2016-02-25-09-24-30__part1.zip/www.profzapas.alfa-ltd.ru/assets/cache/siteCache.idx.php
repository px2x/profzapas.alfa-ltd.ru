<?php
$c=&$this->config;
$c['manager_theme'] = "MODxRE";
$c['settings_version'] = "1.0.15";
$c['show_meta'] = "0";
$c['server_offset_time'] = "0";
$c['server_protocol'] = "http";
$c['manager_language'] = "russian-UTF8";
$c['modx_charset'] = "UTF-8";
$c['site_name'] = "ООО «Передовые Технологии»";
$c['site_start'] = "1";
$c['error_page'] = "114";
$c['unauthorized_page'] = "1";
$c['site_status'] = "1";
$c['site_unavailable_message'] = "The site is currently unavailable";
$c['track_visitors'] = "0";
$c['top_howmany'] = "10";
$c['auto_template_logic'] = "parent";
$c['default_template'] = "3";
$c['old_template'] = "3";
$c['publish_default'] = "1";
$c['cache_default'] = "1";
$c['search_default'] = "1";
$c['friendly_urls'] = "1";
$c['friendly_url_prefix'] = "";
$c['friendly_url_suffix'] = ".html";
$c['friendly_alias_urls'] = "1";
$c['use_alias_path'] = "1";
$c['use_udperms'] = "1";
$c['udperms_allowroot'] = "1";
$c['failed_login_attempts'] = "20";
$c['blocked_minutes'] = "20";
$c['use_captcha'] = "0";
$c['captcha_words'] = "MODX,Access,Better,BitCode,Cache,Desc,Design,Excell,Enjoy,URLs,TechView,Gerald,Griff,Humphrey,Holiday,Intel,Integration,Joystick,Join(),Tattoo,Genetic,Light,Likeness,Marit,Maaike,Niche,Netherlands,Ordinance,Oscillo,Parser,Phusion,Query,Question,Regalia,Righteous,Snippet,Sentinel,Template,Thespian,Unity,Enterprise,Verily,Veri,Website,WideWeb,Yap,Yellow,Zebra,Zygote";
$c['emailsender'] = "korneva.ola@gmail.com";
$c['email_method'] = "mail";
$c['smtp_auth'] = "0";
$c['smtp_host'] = "";
$c['smtp_port'] = "25";
$c['smtp_username'] = "";
$c['emailsubject'] = "Your login details";
$c['number_of_logs'] = "100";
$c['number_of_messages'] = "30";
$c['number_of_results'] = "20";
$c['use_editor'] = "1";
$c['use_browser'] = "1";
$c['rb_base_dir'] = "/home/users/a/alfa-ltd-ru/domains/profzapas.alfa-ltd.ru/assets/";
$c['rb_base_url'] = "assets/";
$c['which_editor'] = "TinyMCE";
$c['fe_editor_lang'] = "russian-UTF8";
$c['fck_editor_toolbar'] = "standard";
$c['fck_editor_autolang'] = "0";
$c['editor_css_path'] = "";
$c['editor_css_selectors'] = "";
$c['strip_image_paths'] = "1";
$c['upload_images'] = "bmp,ico,gif,jpeg,jpg,png,psd,tif,tiff";
$c['upload_media'] = "au,avi,mp3,mp4,mpeg,mpg,wav,wmv";
$c['upload_flash'] = "fla,flv,swf";
$c['upload_files'] = "aac,au,avi,css,cache,doc,docx,gz,gzip,htaccess,htm,html,js,mp3,mp4,mpeg,mpg,ods,odp,odt,pdf,ppt,pptx,rar,tar,tgz,txt,wav,wmv,xls,xlsx,xml,z,zip";
$c['upload_maxsize'] = "100048576";
$c['new_file_permissions'] = "0755";
$c['new_folder_permissions'] = "0755";
$c['filemanager_path'] = "/home/users/a/alfa-ltd-ru/domains/profzapas.alfa-ltd.ru/";
$c['theme_refresher'] = "";
$c['manager_layout'] = "4";
$c['custom_contenttype'] = "application/rss+xml,application/pdf,application/vnd.ms-word,application/vnd.ms-excel,text/html,text/css,text/xml,text/javascript,text/plain,application/json";
$c['auto_menuindex'] = "1";
$c['session.cookie.lifetime'] = "604800";
$c['mail_check_timeperiod'] = "60";
$c['manager_direction'] = "ltr";
$c['tinymce_editor_theme'] = "editor";
$c['tinymce_custom_plugins'] = "style,advimage,advlink,searchreplace,print,contextmenu,paste,fullscreen,nonbreaking,xhtmlxtras,visualchars,media";
$c['tinymce_custom_buttons1'] = "undo,redo,selectall,separator,pastetext,pasteword,separator,search,replace,separator,nonbreaking,hr,charmap,separator,image,link,unlink,anchor,media,separator,cleanup,removeformat,separator,fullscreen,print,code,help";
$c['tinymce_custom_buttons2'] = "bold,italic,underline,strikethrough,sub,sup,separator,bullist,numlist,outdent,indent,separator,justifyleft,justifycenter,justifyright,justifyfull,separator,styleselect,formatselect,separator,styleprops";
$c['tree_show_protected'] = "0";
$c['rss_url_news'] = "http://feeds.feedburner.com/modx-announce";
$c['rss_url_security'] = "http://feeds.feedburner.com/modxsecurity";
$c['validate_referer'] = "1";
$c['datepicker_offset'] = "-10";
$c['xhtml_urls'] = "1";
$c['allow_duplicate_alias'] = "0";
$c['automatic_alias'] = "1";
$c['datetime_format'] = "dd-mm-YYYY";
$c['warning_visibility'] = "0";
$c['remember_last_tab'] = "1";
$c['enable_bindings'] = "1";
$c['seostrict'] = "1";
$c['cache_type'] = "1";
$c['maxImageWidth'] = "7777";
$c['maxImageHeight'] = "7777";
$c['thumbWidth'] = "150";
$c['thumbHeight'] = "150";
$c['thumbsDir'] = ".thumbs";
$c['jpegQuality'] = "100";
$c['denyZipDownload'] = "0";
$c['denyExtensionRename'] = "0";
$c['showHiddenFiles'] = "0";
$c['docid_incrmnt_method'] = "0";
$c['make_folders'] = "1";
$c['site_id'] = "56b0b068b8510";
$c['site_unavailable_page'] = "";
$c['reload_site_unavailable'] = "";
$c['siteunavailable_message_default'] = "В настоящее время сайт недоступен.";
$c['check_files_onlogin'] = "index.php\r\n.htaccess\r\nmanager/index.php\r\nmanager/includes/config.inc.php";
$c['error_reporting'] = "1";
$c['send_errormail'] = "0";
$c['pwd_hash_algo'] = "MD5";
$c['reload_captcha_words'] = "";
$c['captcha_words_default'] = "MODX,Access,Better,BitCode,Chunk,Cache,Desc,Design,Excell,Enjoy,URLs,TechView,Gerald,Griff,Humphrey,Holiday,Intel,Integration,Joystick,Join(),Oscope,Genetic,Light,Likeness,Marit,Maaike,Niche,Netherlands,Ordinance,Oscillo,Parser,Phusion,Query,Question,Regalia,Righteous,Snippet,Sentinel,Template,Thespian,Unity,Enterprise,Verily,Tattoo,Veri,Website,WideWeb,Yap,Yellow,Zebra,Zygote";
$c['smtp_secure'] = "none";
$c['reload_emailsubject'] = "";
$c['emailsubject_default'] = "Данные для авторизации";
$c['reload_signupemail_message'] = "";
$c['signupemail_message'] = "Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации в системе управления сайтом [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации в системе управления сайтом ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация";
$c['system_email_signup_default'] = "Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации в системе управления сайтом [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации в системе управления сайтом ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация";
$c['reload_websignupemail_message'] = "";
$c['websignupemail_message'] = "Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации на [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации на [+sname+] ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация";
$c['system_email_websignup_default'] = "Здравствуйте, [+uid+]!\r\n\r\nВаши данные для авторизации на [+sname+]:\r\n\r\nИмя пользователя: [+uid+]\r\nПароль: [+pwd+]\r\n\r\nПосле успешной авторизации на [+sname+] ([+surl+]), вы сможете изменить свой пароль.\r\n\r\nС уважением, Администрация";
$c['reload_system_email_webreminder_message'] = "";
$c['webpwdreminder_message'] = "Здравствуйте, [+uid+]!\r\n\r\nЧтобы активировать ваш новый пароль, перейдите по следующей ссылке:\r\n\r\n[+surl+]\r\n\r\nПозже вы сможете использовать следующий пароль для авторизации: [+pwd+]\r\n\r\nЕсли это письмо пришло к вам по ошибке, пожалуйста, проигнорируйте его.\r\n\r\nС уважением, Администрация";
$c['system_email_webreminder_default'] = "Здравствуйте, [+uid+]!\r\n\r\nЧтобы активировать ваш новый пароль, перейдите по следующей ссылке:\r\n\r\n[+surl+]\r\n\r\nПозже вы сможете использовать следующий пароль для авторизации: [+pwd+]\r\n\r\nЕсли это письмо пришло к вам по ошибке, пожалуйста, проигнорируйте его.\r\n\r\nС уважением, Администрация";
$c['tree_page_click'] = "27";
$c['resource_tree_node_name'] = "pagetitle";
$c['mce_editor_skin'] = "default";
$c['mce_template_docs'] = "";
$c['mce_template_chunks'] = "";
$c['mce_entermode'] = "p";
$c['mce_element_format'] = "xhtml";
$c['mce_schema'] = "html4";
$c['tinymce_custom_buttons3'] = "";
$c['tinymce_custom_buttons4'] = "";
$c['tinymce_css_selectors'] = "left=justifyleft;right=justifyright";
$c['rb_webuser'] = "0";
$c['clean_uploaded_filename'] = "0";
$c['sys_files_checksum'] = "a:4:{s:65:\"/home/users/a/alfa-ltd-ru/domains/profzapas.alfa-ltd.ru/index.php\";s:32:\"c6f73908b7b0a58acfe95b0f844d134e\";s:65:\"/home/users/a/alfa-ltd-ru/domains/profzapas.alfa-ltd.ru/.htaccess\";s:32:\"8a836dc323bac04127db9d445a76e8df\";s:73:\"/home/users/a/alfa-ltd-ru/domains/profzapas.alfa-ltd.ru/manager/index.php\";s:32:\"30df65e2d71987b65a4258e318c21aaf\";s:87:\"/home/users/a/alfa-ltd-ru/domains/profzapas.alfa-ltd.ru/manager/includes/config.inc.php\";s:32:\"ad2b77bb7a444e861b2534c356a8f28d\";}";
$this->aliasListing = array();
$a = &$this->aliasListing;
$d = &$this->documentListing;
$m = &$this->documentMap;
$d['mainmenu'] = 2;
$a[2] = array('id' => 2, 'alias' => 'mainmenu', 'path' => '', 'parent' => 0, 'isfolder' => 1);
$m[] = array('0' => '2');
$d['pages'] = 113;
$a[113] = array('id' => 113, 'alias' => 'pages', 'path' => '', 'parent' => 0, 'isfolder' => 1);
$m[] = array('0' => '113');
$d['catalog'] = 8;
$a[8] = array('id' => 8, 'alias' => 'catalog', 'path' => '', 'parent' => 0, 'isfolder' => 1);
$m[] = array('0' => '8');
$d['tech'] = 22;
$a[22] = array('id' => 22, 'alias' => 'tech', 'path' => '', 'parent' => 0, 'isfolder' => 1);
$m[] = array('0' => '22');
$d['index'] = 1;
$a[1] = array('id' => 1, 'alias' => 'index', 'path' => '', 'parent' => 2, 'isfolder' => 0);
$m[] = array('2' => '1');
$d['about'] = 3;
$a[3] = array('id' => 3, 'alias' => 'about', 'path' => '', 'parent' => 2, 'isfolder' => 0);
$m[] = array('2' => '3');
$d['servicesto'] = 4;
$a[4] = array('id' => 4, 'alias' => 'servicesto', 'path' => '', 'parent' => 2, 'isfolder' => 0);
$m[] = array('2' => '4');
$d['discounts'] = 5;
$a[5] = array('id' => 5, 'alias' => 'discounts', 'path' => '', 'parent' => 2, 'isfolder' => 0);
$m[] = array('2' => '5');
$d['delivery'] = 6;
$a[6] = array('id' => 6, 'alias' => 'delivery', 'path' => '', 'parent' => 2, 'isfolder' => 0);
$m[] = array('2' => '6');
$d['contacts'] = 7;
$a[7] = array('id' => 7, 'alias' => 'contacts', 'path' => '', 'parent' => 2, 'isfolder' => 0);
$m[] = array('2' => '7');
$d['catalog/promyshlennoe-gidrooborudovanie'] = 9;
$a[9] = array('id' => 9, 'alias' => 'promyshlennoe-gidrooborudovanie', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '9');
$d['catalog/promyshlennoe-pnevmooborudovanie'] = 10;
$a[10] = array('id' => 10, 'alias' => 'promyshlennoe-pnevmooborudovanie', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '10');
$d['catalog/datchiki'] = 11;
$a[11] = array('id' => 11, 'alias' => 'datchiki', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '11');
$d['catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij'] = 12;
$a[12] = array('id' => 12, 'alias' => 'konvejernoe-oborudovanie-i-tehnika-peremeshhenij', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '12');
$d['catalog/pribory-i-elektronnye-komponenty'] = 13;
$a[13] = array('id' => 13, 'alias' => 'pribory-i-elektronnye-komponenty', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '13');
$d['catalog/promyshlennaya-avtomatika'] = 14;
$a[14] = array('id' => 14, 'alias' => 'promyshlennaya-avtomatika', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '14');
$d['catalog/specializirovannoe-promyshlennoe-oborudovanie'] = 15;
$a[15] = array('id' => 15, 'alias' => 'specializirovannoe-promyshlennoe-oborudovanie', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '15');
$d['catalog/stanki-i-instrumenty'] = 16;
$a[16] = array('id' => 16, 'alias' => 'stanki-i-instrumenty', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '16');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty'] = 17;
$a[17] = array('id' => 17, 'alias' => 'tehnologicheskoe-oborudovanie-i-komponenty', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '17');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya'] = 18;
$a[18] = array('id' => 18, 'alias' => 'elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '18');
$d['catalog/services'] = 19;
$a[19] = array('id' => 19, 'alias' => 'services', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '19');
$d['catalog/prochee'] = 20;
$a[20] = array('id' => 20, 'alias' => 'prochee', 'path' => 'catalog', 'parent' => 8, 'isfolder' => 1);
$m[] = array('8' => '20');
$d['catalog/promyshlennoe-gidrooborudovanie/nasosy-i-stancii'] = 21;
$a[21] = array('id' => 21, 'alias' => 'nasosy-i-stancii', 'path' => 'catalog/promyshlennoe-gidrooborudovanie', 'parent' => 9, 'isfolder' => 1);
$m[] = array('9' => '21');
$d['catalog/promyshlennoe-gidrooborudovanie/cilindry'] = 23;
$a[23] = array('id' => 23, 'alias' => 'cilindry', 'path' => 'catalog/promyshlennoe-gidrooborudovanie', 'parent' => 9, 'isfolder' => 1);
$m[] = array('9' => '23');
$d['catalog/promyshlennoe-gidrooborudovanie/klapany-i-regulyatory'] = 24;
$a[24] = array('id' => 24, 'alias' => 'klapany-i-regulyatory', 'path' => 'catalog/promyshlennoe-gidrooborudovanie', 'parent' => 9, 'isfolder' => 1);
$m[] = array('9' => '24');
$d['catalog/promyshlennoe-gidrooborudovanie/akkumulyatory'] = 25;
$a[25] = array('id' => 25, 'alias' => 'akkumulyatory', 'path' => 'catalog/promyshlennoe-gidrooborudovanie', 'parent' => 9, 'isfolder' => 1);
$m[] = array('9' => '25');
$d['catalog/promyshlennoe-gidrooborudovanie/filtry'] = 26;
$a[26] = array('id' => 26, 'alias' => 'filtry', 'path' => 'catalog/promyshlennoe-gidrooborudovanie', 'parent' => 9, 'isfolder' => 1);
$m[] = array('9' => '26');
$d['catalog/promyshlennoe-gidrooborudovanie/gidravlicheskie-sistemy'] = 27;
$a[27] = array('id' => 27, 'alias' => 'gidravlicheskie-sistemy', 'path' => 'catalog/promyshlennoe-gidrooborudovanie', 'parent' => 9, 'isfolder' => 1);
$m[] = array('9' => '27');
$d['catalog/promyshlennoe-gidrooborudovanie/cifrovaya-elektronika'] = 28;
$a[28] = array('id' => 28, 'alias' => 'cifrovaya-elektronika', 'path' => 'catalog/promyshlennoe-gidrooborudovanie', 'parent' => 9, 'isfolder' => 1);
$m[] = array('9' => '28');
$d['catalog/promyshlennoe-gidrooborudovanie/aksessuary-dlya-gidravliki'] = 29;
$a[29] = array('id' => 29, 'alias' => 'aksessuary-dlya-gidravliki', 'path' => 'catalog/promyshlennoe-gidrooborudovanie', 'parent' => 9, 'isfolder' => 1);
$m[] = array('9' => '29');
$d['catalog/promyshlennoe-pnevmooborudovanie/pnevmoraspredeliteli'] = 30;
$a[30] = array('id' => 30, 'alias' => 'pnevmoraspredeliteli', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '30');
$d['catalog/promyshlennoe-pnevmooborudovanie/pnevmocilindry'] = 31;
$a[31] = array('id' => 31, 'alias' => 'pnevmocilindry', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '31');
$d['catalog/promyshlennoe-pnevmooborudovanie/podgotovka-szhatogo-vozduha'] = 32;
$a[32] = array('id' => 32, 'alias' => 'podgotovka-szhatogo-vozduha', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '32');
$d['catalog/promyshlennoe-pnevmooborudovanie/pnevmodrosseli-/-obratnye-klapany'] = 33;
$a[33] = array('id' => 33, 'alias' => 'pnevmodrosseli-/-obratnye-klapany', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '33');
$d['catalog/promyshlennoe-pnevmooborudovanie/klapany-filtry'] = 34;
$a[34] = array('id' => 34, 'alias' => 'klapany-filtry', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '34');
$d['catalog/promyshlennoe-pnevmooborudovanie/soedineniya-/-trubki'] = 35;
$a[35] = array('id' => 35, 'alias' => 'soedineniya-/-trubki', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '35');
$d['catalog/promyshlennoe-pnevmooborudovanie/vakuumnoe-oborudovanie-/-zahvaty'] = 36;
$a[36] = array('id' => 36, 'alias' => 'vakuumnoe-oborudovanie-/-zahvaty', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '36');
$d['catalog/promyshlennoe-pnevmooborudovanie/datchiki-elektricheskie-komponenty'] = 37;
$a[37] = array('id' => 37, 'alias' => 'datchiki-elektricheskie-komponenty', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '37');
$d['catalog/promyshlennoe-pnevmooborudovanie/prochee1'] = 38;
$a[38] = array('id' => 38, 'alias' => 'prochee1', 'path' => 'catalog/promyshlennoe-pnevmooborudovanie', 'parent' => 10, 'isfolder' => 1);
$m[] = array('10' => '38');
$d['catalog/datchiki/industrialnye-sredstva-izmereniya'] = 39;
$a[39] = array('id' => 39, 'alias' => 'industrialnye-sredstva-izmereniya', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '39');
$d['catalog/datchiki/fotoelektricheskie-datchiki'] = 40;
$a[40] = array('id' => 40, 'alias' => 'fotoelektricheskie-datchiki', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '40');
$d['catalog/datchiki/induktivnye-datchiki'] = 41;
$a[41] = array('id' => 41, 'alias' => 'induktivnye-datchiki', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '41');
$d['catalog/datchiki/emkostnye-datchiki'] = 42;
$a[42] = array('id' => 42, 'alias' => 'emkostnye-datchiki', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '42');
$d['catalog/datchiki/mashinnoe-i-tehnicheskoe-zrenie'] = 43;
$a[43] = array('id' => 43, 'alias' => 'mashinnoe-i-tehnicheskoe-zrenie', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '43');
$d['catalog/datchiki/vesoizmerenie-i-dozirovanie'] = 44;
$a[44] = array('id' => 44, 'alias' => 'vesoizmerenie-i-dozirovanie', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '44');
$d['catalog/datchiki/ultrazvukovye-datchiki'] = 45;
$a[45] = array('id' => 45, 'alias' => 'ultrazvukovye-datchiki', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '45');
$d['catalog/datchiki/datchiki-bezopasnosti'] = 46;
$a[46] = array('id' => 46, 'alias' => 'datchiki-bezopasnosti', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '46');
$d['catalog/datchiki/enkodery-pozicionery'] = 47;
$a[47] = array('id' => 47, 'alias' => 'enkodery-pozicionery', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '47');
$d['catalog/datchiki/analizatory-i-registratory'] = 48;
$a[48] = array('id' => 48, 'alias' => 'analizatory-i-registratory', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '48');
$d['catalog/datchiki/prochee2'] = 49;
$a[49] = array('id' => 49, 'alias' => 'prochee2', 'path' => 'catalog/datchiki', 'parent' => 11, 'isfolder' => 1);
$m[] = array('11' => '49');
$d['catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij/konvejery-i-transportery'] = 50;
$a[50] = array('id' => 50, 'alias' => 'konvejery-i-transportery', 'path' => 'catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij', 'parent' => 12, 'isfolder' => 1);
$m[] = array('12' => '50');
$d['catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij/ruduktora-i-privody'] = 51;
$a[51] = array('id' => 51, 'alias' => 'ruduktora-i-privody', 'path' => 'catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij', 'parent' => 12, 'isfolder' => 1);
$m[] = array('12' => '51');
$d['catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij/pulty-upravleniya'] = 52;
$a[52] = array('id' => 52, 'alias' => 'pulty-upravleniya', 'path' => 'catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij', 'parent' => 12, 'isfolder' => 1);
$m[] = array('12' => '52');
$d['catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij/barabany'] = 53;
$a[53] = array('id' => 53, 'alias' => 'barabany', 'path' => 'catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij', 'parent' => 12, 'isfolder' => 1);
$m[] = array('12' => '53');
$d['catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij/lenta'] = 54;
$a[54] = array('id' => 54, 'alias' => 'lenta', 'path' => 'catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij', 'parent' => 12, 'isfolder' => 1);
$m[] = array('12' => '54');
$d['catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij/natyazhnye-stancii'] = 55;
$a[55] = array('id' => 55, 'alias' => 'natyazhnye-stancii', 'path' => 'catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij', 'parent' => 12, 'isfolder' => 1);
$m[] = array('12' => '55');
$d['catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij/prochee3'] = 56;
$a[56] = array('id' => 56, 'alias' => 'prochee3', 'path' => 'catalog/konvejernoe-oborudovanie-i-tehnika-peremeshhenij', 'parent' => 12, 'isfolder' => 1);
$m[] = array('12' => '56');
$d['catalog/pribory-i-elektronnye-komponenty/izmeritelnye-pribory'] = 57;
$a[57] = array('id' => 57, 'alias' => 'izmeritelnye-pribory', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '57');
$d['catalog/pribory-i-elektronnye-komponenty/elektronnye-komponenty'] = 58;
$a[58] = array('id' => 58, 'alias' => 'elektronnye-komponenty', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '58');
$d['catalog/pribory-i-elektronnye-komponenty/optoelektronika'] = 59;
$a[59] = array('id' => 59, 'alias' => 'optoelektronika', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '59');
$d['catalog/pribory-i-elektronnye-komponenty/knopki-pereklyuchateli-razemy-i-rele'] = 60;
$a[60] = array('id' => 60, 'alias' => 'knopki-pereklyuchateli-razemy-i-rele', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '60');
$d['catalog/pribory-i-elektronnye-komponenty/payalnoe-oborudovanie'] = 61;
$a[61] = array('id' => 61, 'alias' => 'payalnoe-oborudovanie', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '61');
$d['catalog/pribory-i-elektronnye-komponenty/instrument'] = 62;
$a[62] = array('id' => 62, 'alias' => 'instrument', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '62');
$d['catalog/pribory-i-elektronnye-komponenty/rashodnye-materialy'] = 63;
$a[63] = array('id' => 63, 'alias' => 'rashodnye-materialy', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '63');
$d['catalog/pribory-i-elektronnye-komponenty/korpusnye-i-ustanovochnye-izdeliya'] = 64;
$a[64] = array('id' => 64, 'alias' => 'korpusnye-i-ustanovochnye-izdeliya', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '64');
$d['catalog/pribory-i-elektronnye-komponenty/bloki-i-elementy-pitaniya'] = 65;
$a[65] = array('id' => 65, 'alias' => 'bloki-i-elementy-pitaniya', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '65');
$d['catalog/pribory-i-elektronnye-komponenty/provoda-shnury-kabeli'] = 66;
$a[66] = array('id' => 66, 'alias' => 'provoda-shnury-kabeli', 'path' => 'catalog/pribory-i-elektronnye-komponenty', 'parent' => 13, 'isfolder' => 1);
$m[] = array('13' => '66');
$d['catalog/promyshlennaya-avtomatika/kontrollery-i-vvod/vyvod'] = 67;
$a[67] = array('id' => 67, 'alias' => 'kontrollery-i-vvod/vyvod', 'path' => 'catalog/promyshlennaya-avtomatika', 'parent' => 14, 'isfolder' => 1);
$m[] = array('14' => '67');
$d['catalog/promyshlennaya-avtomatika/vizualizaciya'] = 68;
$a[68] = array('id' => 68, 'alias' => 'vizualizaciya', 'path' => 'catalog/promyshlennaya-avtomatika', 'parent' => 14, 'isfolder' => 1);
$m[] = array('14' => '68');
$d['catalog/promyshlennaya-avtomatika/pch-/-servoprivoda-i-komponenty'] = 69;
$a[69] = array('id' => 69, 'alias' => 'pch-/-servoprivoda-i-komponenty', 'path' => 'catalog/promyshlennaya-avtomatika', 'parent' => 14, 'isfolder' => 1);
$m[] = array('14' => '69');
$d['catalog/promyshlennaya-avtomatika/kommutacionnaya-apparatura'] = 70;
$a[70] = array('id' => 70, 'alias' => 'kommutacionnaya-apparatura', 'path' => 'catalog/promyshlennaya-avtomatika', 'parent' => 14, 'isfolder' => 1);
$m[] = array('14' => '70');
$d['catalog/promyshlennaya-avtomatika/bp-i-ibp'] = 71;
$a[71] = array('id' => 71, 'alias' => 'bp-i-ibp', 'path' => 'catalog/promyshlennaya-avtomatika', 'parent' => 14, 'isfolder' => 1);
$m[] = array('14' => '71');
$d['catalog/promyshlennaya-avtomatika/sistemy-bezopasnosti'] = 72;
$a[72] = array('id' => 72, 'alias' => 'sistemy-bezopasnosti', 'path' => 'catalog/promyshlennaya-avtomatika', 'parent' => 14, 'isfolder' => 1);
$m[] = array('14' => '72');
$d['catalog/promyshlennaya-avtomatika/avtomatizaciya-zdanij'] = 73;
$a[73] = array('id' => 73, 'alias' => 'avtomatizaciya-zdanij', 'path' => 'catalog/promyshlennaya-avtomatika', 'parent' => 14, 'isfolder' => 1);
$m[] = array('14' => '73');
$d['catalog/promyshlennaya-avtomatika/setevoe-oborudovanie'] = 74;
$a[74] = array('id' => 74, 'alias' => 'setevoe-oborudovanie', 'path' => 'catalog/promyshlennaya-avtomatika', 'parent' => 14, 'isfolder' => 1);
$m[] = array('14' => '74');
$d['catalog/specializirovannoe-promyshlennoe-oborudovanie/robototehnika'] = 75;
$a[75] = array('id' => 75, 'alias' => 'robototehnika', 'path' => 'catalog/specializirovannoe-promyshlennoe-oborudovanie', 'parent' => 15, 'isfolder' => 1);
$m[] = array('15' => '75');
$d['catalog/specializirovannoe-promyshlennoe-oborudovanie/manipulyatory'] = 76;
$a[76] = array('id' => 76, 'alias' => 'manipulyatory', 'path' => 'catalog/specializirovannoe-promyshlennoe-oborudovanie', 'parent' => 15, 'isfolder' => 1);
$m[] = array('15' => '76');
$d['catalog/specializirovannoe-promyshlennoe-oborudovanie/rozliv'] = 77;
$a[77] = array('id' => 77, 'alias' => 'rozliv', 'path' => 'catalog/specializirovannoe-promyshlennoe-oborudovanie', 'parent' => 15, 'isfolder' => 1);
$m[] = array('15' => '77');
$d['catalog/specializirovannoe-promyshlennoe-oborudovanie/upakovka'] = 78;
$a[78] = array('id' => 78, 'alias' => 'upakovka', 'path' => 'catalog/specializirovannoe-promyshlennoe-oborudovanie', 'parent' => 15, 'isfolder' => 1);
$m[] = array('15' => '78');
$d['catalog/specializirovannoe-promyshlennoe-oborudovanie/fasovka'] = 79;
$a[79] = array('id' => 79, 'alias' => 'fasovka', 'path' => 'catalog/specializirovannoe-promyshlennoe-oborudovanie', 'parent' => 15, 'isfolder' => 1);
$m[] = array('15' => '79');
$d['catalog/specializirovannoe-promyshlennoe-oborudovanie/paletizaciya'] = 80;
$a[80] = array('id' => 80, 'alias' => 'paletizaciya', 'path' => 'catalog/specializirovannoe-promyshlennoe-oborudovanie', 'parent' => 15, 'isfolder' => 1);
$m[] = array('15' => '80');
$d['catalog/stanki-i-instrumenty/stanki'] = 81;
$a[81] = array('id' => 81, 'alias' => 'stanki', 'path' => 'catalog/stanki-i-instrumenty', 'parent' => 16, 'isfolder' => 1);
$m[] = array('16' => '81');
$d['catalog/stanki-i-instrumenty/komplektuyushhie'] = 82;
$a[82] = array('id' => 82, 'alias' => 'komplektuyushhie', 'path' => 'catalog/stanki-i-instrumenty', 'parent' => 16, 'isfolder' => 1);
$m[] = array('16' => '82');
$d['catalog/stanki-i-instrumenty/stanochnaya-gidravlika'] = 83;
$a[83] = array('id' => 83, 'alias' => 'stanochnaya-gidravlika', 'path' => 'catalog/stanki-i-instrumenty', 'parent' => 16, 'isfolder' => 1);
$m[] = array('16' => '83');
$d['catalog/stanki-i-instrumenty/stanochnaya-pnevmatika'] = 84;
$a[84] = array('id' => 84, 'alias' => 'stanochnaya-pnevmatika', 'path' => 'catalog/stanki-i-instrumenty', 'parent' => 16, 'isfolder' => 1);
$m[] = array('16' => '84');
$d['catalog/stanki-i-instrumenty/stanochnaya-elektrika-i-avtomatika'] = 85;
$a[85] = array('id' => 85, 'alias' => 'stanochnaya-elektrika-i-avtomatika', 'path' => 'catalog/stanki-i-instrumenty', 'parent' => 16, 'isfolder' => 1);
$m[] = array('16' => '85');
$d['catalog/stanki-i-instrumenty/smazochnoe-i-filtruyushhee-oborudovanie'] = 86;
$a[86] = array('id' => 86, 'alias' => 'smazochnoe-i-filtruyushhee-oborudovanie', 'path' => 'catalog/stanki-i-instrumenty', 'parent' => 16, 'isfolder' => 1);
$m[] = array('16' => '86');
$d['catalog/stanki-i-instrumenty/prochee4'] = 87;
$a[87] = array('id' => 87, 'alias' => 'prochee4', 'path' => 'catalog/stanki-i-instrumenty', 'parent' => 16, 'isfolder' => 1);
$m[] = array('16' => '87');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty/nasosy-i-gomogenizatory'] = 88;
$a[88] = array('id' => 88, 'alias' => 'nasosy-i-gomogenizatory', 'path' => 'catalog/tehnologicheskoe-oborudovanie-i-komponenty', 'parent' => 17, 'isfolder' => 1);
$m[] = array('17' => '88');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty/klapany'] = 89;
$a[89] = array('id' => 89, 'alias' => 'klapany', 'path' => 'catalog/tehnologicheskoe-oborudovanie-i-komponenty', 'parent' => 17, 'isfolder' => 1);
$m[] = array('17' => '89');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty/teploobmenniki'] = 90;
$a[90] = array('id' => 90, 'alias' => 'teploobmenniki', 'path' => 'catalog/tehnologicheskoe-oborudovanie-i-komponenty', 'parent' => 17, 'isfolder' => 1);
$m[] = array('17' => '90');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty/rezervuary-i-oborudovanie'] = 91;
$a[91] = array('id' => 91, 'alias' => 'rezervuary-i-oborudovanie', 'path' => 'catalog/tehnologicheskoe-oborudovanie-i-komponenty', 'parent' => 17, 'isfolder' => 1);
$m[] = array('17' => '91');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty/separatory'] = 92;
$a[92] = array('id' => 92, 'alias' => 'separatory', 'path' => 'catalog/tehnologicheskoe-oborudovanie-i-komponenty', 'parent' => 17, 'isfolder' => 1);
$m[] = array('17' => '92');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty/truboprovody-i-detali'] = 93;
$a[93] = array('id' => 93, 'alias' => 'truboprovody-i-detali', 'path' => 'catalog/tehnologicheskoe-oborudovanie-i-komponenty', 'parent' => 17, 'isfolder' => 1);
$m[] = array('17' => '93');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty/sistemy'] = 94;
$a[94] = array('id' => 94, 'alias' => 'sistemy', 'path' => 'catalog/tehnologicheskoe-oborudovanie-i-komponenty', 'parent' => 17, 'isfolder' => 1);
$m[] = array('17' => '94');
$d['catalog/tehnologicheskoe-oborudovanie-i-komponenty/prochee5'] = 95;
$a[95] = array('id' => 95, 'alias' => 'prochee5', 'path' => 'catalog/tehnologicheskoe-oborudovanie-i-komponenty', 'parent' => 17, 'isfolder' => 1);
$m[] = array('17' => '95');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/sistemy-generacii-energii'] = 96;
$a[96] = array('id' => 96, 'alias' => 'sistemy-generacii-energii', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '96');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/vysokovoltnoe-oborudovanie'] = 97;
$a[97] = array('id' => 97, 'alias' => 'vysokovoltnoe-oborudovanie', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '97');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/dvigateli-i-generatory'] = 98;
$a[98] = array('id' => 98, 'alias' => 'dvigateli-i-generatory', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '98');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/transformatory-i-komponenty'] = 99;
$a[99] = array('id' => 99, 'alias' => 'transformatory-i-komponenty', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '99');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/raspredelenie-elektroenergii'] = 100;
$a[100] = array('id' => 100, 'alias' => 'raspredelenie-elektroenergii', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '100');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/puskoreguliruyushhaya-apparatura'] = 101;
$a[101] = array('id' => 101, 'alias' => 'puskoreguliruyushhaya-apparatura', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '101');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/shkafy-i-komponenty-dlya-motazha'] = 102;
$a[102] = array('id' => 102, 'alias' => 'shkafy-i-komponenty-dlya-motazha', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '102');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/elektroustanovochnye-izdeliya'] = 103;
$a[103] = array('id' => 103, 'alias' => 'elektroustanovochnye-izdeliya', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '103');
$d['catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya/kabelenesushhie-sistemy-i-materialy'] = 104;
$a[104] = array('id' => 104, 'alias' => 'kabelenesushhie-sistemy-i-materialy', 'path' => 'catalog/elektrooborudovanie-i-kabelno-provodnikovaya-produkciya', 'parent' => 18, 'isfolder' => 1);
$m[] = array('18' => '104');
$d['lk'] = 106;
$a[106] = array('id' => 106, 'alias' => 'lk', 'path' => '', 'parent' => 22, 'isfolder' => 1);
$m[] = array('22' => '106');
$d['dmtcaptcha_img'] = 112;
$a[112] = array('id' => 112, 'alias' => 'dmtcaptcha_img', 'path' => '', 'parent' => 22, 'isfolder' => 0);
$m[] = array('22' => '112');
$d['dmtcaptcha'] = 111;
$a[111] = array('id' => 111, 'alias' => 'dmtcaptcha', 'path' => '', 'parent' => 22, 'isfolder' => 0);
$m[] = array('22' => '111');
$d['lk/reg'] = 107;
$a[107] = array('id' => 107, 'alias' => 'reg', 'path' => 'lk', 'parent' => 106, 'isfolder' => 0);
$m[] = array('106' => '107');
$d['lk/auth'] = 108;
$a[108] = array('id' => 108, 'alias' => 'auth', 'path' => 'lk', 'parent' => 106, 'isfolder' => 0);
$m[] = array('106' => '108');
$d['lk/restorepassword'] = 109;
$a[109] = array('id' => 109, 'alias' => 'restorepassword', 'path' => 'lk', 'parent' => 106, 'isfolder' => 0);
$m[] = array('106' => '109');
$d['lk/agreed'] = 110;
$a[110] = array('id' => 110, 'alias' => 'agreed', 'path' => 'lk', 'parent' => 106, 'isfolder' => 0);
$m[] = array('106' => '110');
$d['lk/lkmenu'] = 115;
$a[115] = array('id' => 115, 'alias' => 'lkmenu', 'path' => 'lk', 'parent' => 106, 'isfolder' => 1);
$m[] = array('106' => '115');
$d['404'] = 114;
$a[114] = array('id' => 114, 'alias' => '404', 'path' => '', 'parent' => 113, 'isfolder' => 1);
$m[] = array('113' => '114');
$d['lk/svodnaya-informaciya'] = 116;
$a[116] = array('id' => 116, 'alias' => 'svodnaya-informaciya', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '116');
$d['lk/pokupki'] = 117;
$a[117] = array('id' => 117, 'alias' => 'pokupki', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '117');
$d['lk/prodazhi'] = 118;
$a[118] = array('id' => 118, 'alias' => 'prodazhi', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '118');
$d['lk/aukcion'] = 125;
$a[125] = array('id' => 125, 'alias' => 'aukcion', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '125');
$d['lk/izbrannoe'] = 119;
$a[119] = array('id' => 119, 'alias' => 'izbrannoe', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '119');
$d['lk/finasy'] = 120;
$a[120] = array('id' => 120, 'alias' => 'finasy', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '120');
$d['lk/lichnaya-informaciya'] = 121;
$a[121] = array('id' => 121, 'alias' => 'lichnaya-informaciya', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '121');
$d['lk/soobshheniya'] = 122;
$a[122] = array('id' => 122, 'alias' => 'soobshheniya', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '122');
$d['lk/garantiya'] = 126;
$a[126] = array('id' => 126, 'alias' => 'garantiya', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '126');
$d['lk/moi-tovary'] = 123;
$a[123] = array('id' => 123, 'alias' => 'moi-tovary', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '123');
$d['lk/moi-otzyvy'] = 124;
$a[124] = array('id' => 124, 'alias' => 'moi-otzyvy', 'path' => 'lk', 'parent' => 115, 'isfolder' => 0);
$m[] = array('115' => '124');
$c = &$this->contentTypes;
$c = &$this->chunkCache;
$c['mm_rules'] = '// more example rules are in assets/plugins/managermanager/example_mm_rules.inc.php
// example of how PHP is allowed - check that a TV named documentTags exists before creating rule

if ($modx->db->getValue($modx->db->select(\'count(id)\', $modx->getFullTableName(\'site_tmplvars\'), "name=\'documentTags\'"))) {
	mm_widget_tags(\'documentTags\', \' \'); // Give blog tag editing capabilities to the \'documentTags (3)\' TV
}
mm_widget_showimagetvs(); // Always give a preview of Image TVs

mm_moveFieldsToTab( "published,alias_visible", "general" );
	
mm_moveFieldsToTab( \'longtitle,description,menutitle,log,searchable,link_attributes\', \'settings\' );
';
$c['HEAD'] = '<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
		
		<base_and_canonical />
		
		<title>[*seo_title*]</title>
		<meta name="description" content="[*seo_description*]" />
		<meta name="keywords" content="[*seo_keywords*]" />
		
		<meta name="viewport" content="width=1160" />
		
		<!-- ============================================================================================= -->
		
		<link rel="stylesheet" type="text/css" href="template/css/main.css" />
		<link rel="stylesheet" type="text/css" href="template/css/dop.css" />
		<link rel="stylesheet" type="text/css" href="template/css/catalog.css" />
		<link rel="stylesheet" type="text/css" href="template/js/jquery_scorn_table/jquery_scorn_table.css" />
		<noscript><link rel="stylesheet" type="text/css" href="template/css/noscript.css" /></noscript>
		
		<link rel="icon" href="favicon.ico" type="image/x-icon" />
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
		
		<script type="text/javascript" src="template/js/jquery/jquery-2.1.4.min.js"></script>
		<script type="text/javascript" src="template/js/jquery/jquery-ui.min.js"></script>
		
		<script type="text/javascript" src="template/js/javascript.js"></script>
		
		<!-- <a class="highslide" onclick="return hs.expand(this)"> -->
	</head>
	<body>
		<div class="mainwrapper">
<!-- ================================================= -->
';
$c['FOOTER'] = '<!-- ================================================= -->
<div style="height:100px;border-top:1px solid #ccc;margin-top:50px;">&nbsp;</div>
</div>
</body>
</html>';
$c['TOP'] = '<header class="wrapper_header">
	<div class="top_line">
		<div class="mw1100px">
			<div class="topuserpanel">[!_LK_UserPanel!]</div>
			
			<div class="topmenu">
				[[WayfinderScorn? &startId=`2` &level=`1` &linkClass=`as2` &sortOrder=`DESC`]]
			</div>
			<div class="clr">&nbsp;</div>
		</div>
	</div>
	
	<div class="header">
		<div class="mw1100px">
			<div class="_logo_">
				<a href="[(base_url)]"><img src="template/images/__logo.png" /></a>
				<div class="slogo">Покупайте и продавайте оборудование</div>
			</div>
			
			[!Catalog_TopSearch!]
			
			<div class="clr">&nbsp;</div>
		</div>
	</div>
</header>

';
$c['INDEXSLIDER'] = '<div class="mw1100px">
	<div class="mainslider">
		СЛАЙДЕР
	</div>
</div>';
$c['Catalog_TopMenu'] = '<div class="mw1100px">
	<div class="catalog_top_menu">
		<div class="ctm_button">Каталог</div>
		
		<div class="ctm_catalog">
			[[Catalog_BigMenu]]
		</div>
	</div>
</div>';
$s = &$this->snippetCache;
$s['Reflect'] = '/*
 * Author: 
 *      Mark Kaplan for MODX CMF
 * 
 * Note: 
 *      If Reflect is not retrieving its own documents, make sure that the
 *          Ditto call feeding it has all of the fields in it that you plan on
 *       calling in your Reflect template. Furthermore, Reflect will ONLY
 *          show what is currently in the Ditto result set.
 *       Thus, if pagination is on it will ONLY show that page\'s items.
*/
 

// ---------------------------------------------------
//  Includes
// ---------------------------------------------------

$reflect_base = isset($reflect_base) ? $modx->config[\'base_path\'].$reflect_base : $modx->config[\'base_path\']."assets/snippets/reflect/";
/*
    Param: ditto_base
    
    Purpose:
    Location of Ditto files

    Options:
    Any valid folder location containing the Ditto source code with a trailing slash

    Default:
    [(base_path)]assets/snippets/ditto/
*/

$config = (isset($config)) ? $config : "default";
/*
    Param: config

    Purpose:
    Load a custom configuration

    Options:
    "default" - default blank config file
    CONFIG_NAME - Other configs installed in the configs folder or in any folder within the MODX base path via @FILE

    Default:
    "default"
    
    Related:
    - <extenders>
*/

require($reflect_base."configs/default.config.php");
require($reflect_base."default.templates.php");
if ($config != "default") {
    require((substr($config, 0, 5) != "@FILE") ? $reflect_base."configs/$config.config.php" : $modx->config[\'base_path\'].trim(substr($config, 5)));
}

// ---------------------------------------------------
//  Parameters
// ---------------------------------------------------

$id = isset($id) ? $id."_" : false;
/*
    Param: id

    Purpose:
    Unique ID for this Ditto instance for connection with other scripts (like Reflect) and unique URL parameters

    Options:
    Any valid folder location containing the Ditto source code with a trailing slash

    Default:
    "" - blank
*/
$getDocuments = isset($getDocuments) ? $getDocuments : 0;
/*
    Param: getDocuments

    Purpose:
    Force Reflect to get documents

    Options:
    0 - off
    1 - on
    
    Default:
    0 - off
*/
$showItems = isset($showItems) ? $showItems : 1;
/*
    Param: showItems

    Purpose:
    Show individual items in the archive

    Options:
    0 - off
    1 - on
    
    Default:
    1 - on
*/
$groupByYears = isset($groupByYears)? $groupByYears : 1;
/*
    Param: groupByYears

    Purpose:
    Group the archive by years

    Options:
    0 - off
    1 - on
    
    Default:
    1 - on
*/
$targetID = isset($targetID) ? $targetID : $modx->documentObject[\'id\'];
/*
    Param: targetID

    Purpose:
    ID for archive links to point to

    Options:
    Any MODX document with a Ditto call setup with extenders=`dateFilter`
    
    Default:
    Current MODX Document
*/
$dateSource = isset($dateSource) ? $dateSource : "createdon";
/*
    Param: dateSource

    Purpose:
    Date source to display for archive items

    Options:
    # - Any UNIX timestamp from MODX fields or TVs such as createdon, pub_date, or editedon
    
    Default:
    "createdon"
    
    Related:
    - <dateFormat>
*/
$dateFormat = isset($dateFormat) ? $dateFormat : "%d-%b-%y %H:%M";  
/*
    Param: dateFormat

    Purpose:
    Format the [+date+] placeholder in human readable form

    Options:
    Any PHP valid strftime option

    Default:
    "%d-%b-%y %H:%M"
    
    Related:
    - <dateSource>
*/
$yearSortDir = isset($yearSortDir) ? $yearSortDir : "DESC";
/*
    Param: yearSortDir

    Purpose:
    Direction to sort documents

    Options:
    ASC - ascending
    DESC - descending

    Default:
    "DESC"
    
    Related:
    - <monthSortDir>
*/
$monthSortDir = isset($monthSortDir) ? $monthSortDir : "ASC";
/*
    Param: monthSortDir

    Purpose:
    Direction to sort the months

    Options:
    ASC - ascending
    DESC - descending

    Default:
    "ASC"
    
    Related:
    - <yearSortDir>
*/
$start = isset($start)? intval($start) : 0;
/*
    Param: start

    Purpose:
    Number of documents to skip in the results
    
    Options:
    Any number

    Default:
    0
*/  
$phx = (isset($phx))? $phx : 1;
/*
    Param: phx

    Purpose:
    Use PHx formatting

    Options:
    0 - off
    1 - on
    
    Default:
    1 - on
*/

// ---------------------------------------------------
//  Initialize Ditto
// ---------------------------------------------------
$placeholder = ($id != false && $getDocuments == 0) ? true : false;
if ($placeholder === false) {
    $rID = "reflect_".rand(1,1000);
    $itemTemplate = isset($tplItem) ? $tplItem: "@CODE:".$defaultTemplates[\'item\'];
    $dParams = array(
        "id" => "$rID",
        "save" => "3",  
        "summarize" => "all",
        "tpl" => $itemTemplate,
    );
    
    $source = $dittoSnippetName;
    $params = $dittoSnippetParameters;
        // TODO: Remove after 3.0
        
    if (isset($params)) {
        $givenParams = explode("|",$params);
        foreach ($givenParams as $parameter) {
            $p = explode(":",$parameter);
            $dParams[$p[0]] = $p[1];
        }
    }
    /*
        Param: params

        Purpose:
        Pass parameters to the Ditto instance used to retreive the documents

        Options:
        Any valid ditto parameters in the format name:value 
        with multiple parameters separated by a pipe (|)
        
        Note:
        This parameter is only needed for config, start, and phx as you can
        now simply use the parameter as if Reflect was Ditto

        Default:
        [NULL]
    */
    
    $reflectParameters = array(\'reflect_base\',\'config\',\'id\',\'getDocuments\',\'showItems\',\'groupByYears\',\'targetID\',\'yearSortDir\',\'monthSortDir\',\'start\',\'phx\',\'tplContainer\',\'tplYear\',\'tplMonth\',\'tplMonthInner\',\'tplItem\',\'save\');
    $params =& $modx->event->params;
    if(is_array($params)) {
        foreach ($params as $param=>$value) {
            if (!in_array($param,$reflectParameters) && substr($param,-3) != \'tpl\') {
                $dParams[$param] = $value;
            }
        }
    }

    $source = isset($source) ? $source : "Ditto";
    /*
        Param: source

        Purpose:
        Name of the Ditto snippet to use

        Options:
        Any valid snippet name

        Default:
        "Ditto"
    */
    $snippetOutput = $modx->runSnippet($source,$dParams);
    $ditto = $modx->getPlaceholder($rID."_ditto_object");
    $resource = $modx->getPlaceholder($rID."_ditto_resource");
} else {
    $ditto = $modx->getPlaceholder($id."ditto_object");
    $resource = $modx->getPlaceholder($id."ditto_resource");
}
if (!is_object($ditto) || !isset($ditto) || !isset($resource)) {
    return !empty($snippetOutput) ? $snippetOutput : "The Ditto object is invalid. Please check it.";
}

// ---------------------------------------------------
//  Templates
// ---------------------------------------------------

$templates[\'tpl\'] = isset($tplContainer) ? $ditto->template->fetch($tplContainer): $defaultTemplates[\'tpl\'];
/*
    Param: tplContainer

    Purpose:
    Container template for the archive

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'year\'] = isset($tplYear) ? $ditto->template->fetch($tplYear): $defaultTemplates[\'year\'];
/*
    Param: tplYear

    Purpose:
    Template for the year item

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'year_inner\'] = isset($tplYearInner) ? $ditto->template->fetch($tplYearInner): $defaultTemplates[\'year_inner\'];
/*
    Param: tplYearInner

    Purpose:
    Template for the year item (the ul to hold the year template)

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'month\'] = isset($tplMonth) ? $ditto->template->fetch($tplMonth): $defaultTemplates[\'month\'];
/*
    Param: tplMonth

    Purpose:
    Template for the month item

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'month_inner\'] = isset($tplMonthInner) ? $ditto->template->fetch($tplMonthInner): $defaultTemplates[\'month_inner\'];
/*
    Param: tplMonthInner

    Purpose:
    Template for the month item  (the ul to hold the month template)

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/
$templates[\'item\'] = isset($tplItem) ? $ditto->template->fetch($tplItem): $defaultTemplates[\'item\'];
/*
    Param: tplItem

    Purpose:
    Template for the individual item

    Options:
    - Any valid chunk name
    - Code via @CODE:
    - File via @FILE:

    Default:
    See default.tempates.php
*/

$ditto->addField("date","display","custom");
    // force add the date field if receiving data from a Ditto instance

// ---------------------------------------------------
//  Reflect
// ---------------------------------------------------

if (function_exists("reflect") === FALSE) {
function reflect($templatesDocumentID, $showItems, $groupByYears, $resource, $templatesDateSource, $dateFormat, $ditto, $templates,$id,$start,$yearSortDir,$monthSortDir) {
    global $modx;
    $cal = array();
    $output = \'\';
    $ph = array(\'year\'=>\'\',\'month\'=>\'\',\'item\'=>\'\',\'out\'=>\'\');
    $build = array();
    $stop = count($resource);

    // loop and fetch all the results
    for ($i = $start; $i < $stop; $i++) {
        $date = getdate($resource[$i][$templatesDateSource]);
        $year = $date["year"];
        $month = $date["mon"];
        $cal[$year][$month][] = $resource[$i];
    }
    if ($yearSortDir == "DESC") {
        krsort($cal);
    } else {
        ksort($cal);
    }
    foreach ($cal as $year=>$months) {
        if ($monthSortDir == "ASC") {
            ksort($months);
        } else {
            krsort($months);
        }
        $build[$year] = $months;
    }
    
    foreach ($build as $year=>$months) {
        $r_year = \'\';
        $r_month = \'\';
        $r_month_2 = \'\';
        $year_count = 0;
        $items = array();
        
        foreach ($months as $mon=>$month) {
            $month_text = strftime("%B", mktime(10, 10, 10, $mon, 10, $year));
            $month_url = $ditto->buildURL("month=".$mon."&year=".$year."&day=false&start=0",$templatesDocumentID,$id);
            $month_count = count($month);
            $year_count += $month_count;
            $r_month = $ditto->template->replace(array("year"=>$year,"month"=>$month_text,"url"=>$month_url,"count"=>$month_count),$templates[\'month\']);
            if ($showItems) {
                foreach ($month as $item) {
                    $items[$year][$mon][\'items\'][] = $ditto->render($item, $templates[\'item\'], false, $templatesDateSource, $dateFormat, array(),$phx);
                }
                $r_month_2 = $ditto->template->replace(array(\'wrapper\' => implode(\'\',$items[$year][$mon][\'items\'])),$templates[\'month_inner\']);
                $items[$year][$mon] = $ditto->template->replace(array(\'wrapper\' => $r_month_2),$r_month);
            } else {
                $items[$year][$mon] = $r_month;
            }
        }
        if ($groupByYears) {
            $year_url = $ditto->buildURL("year=".$year."&month=false&day=false&start=0",$templatesDocumentID,$id);
            $r_year =  $ditto->template->replace(array("year"=>$year,"url"=>$year_url,"count"=>$year_count),$templates[\'year\']);
            $var = $ditto->template->replace(array(\'wrapper\'=>implode(\'\',$items[$year])),$templates[\'year_inner\']);
            $output .= $ditto->template->replace(array(\'wrapper\'=>$var),$r_year);
        } else {
            $output .= implode(\'\',$items[$year]);
        }
    }

    $output = $ditto->template->replace(array(\'wrapper\'=>$output),$templates[\'tpl\']);
    $modx->setPlaceholder($id.\'reset\',$ditto->buildURL(\'year=false&month=false&day=false\',$templatesDocumentID,$id));

return $output;
    
}
}

return reflect($targetID, $showItems, $groupByYears, $resource, $dateSource, $dateFormat, $ditto, $templates,$id,$start,$yearSortDir,$monthSortDir);';
$s['Ditto'] = 'return require MODX_BASE_PATH.\'assets/snippets/ditto/snippet.ditto.php\';';
$s['UltimateParent'] = 'return require MODX_BASE_PATH.\'assets/snippets/ultimateparent/snippet.ultimateparent.php\';';
$s['Jot'] = '/*####
#
# Author: Armand "bS" Pondman (apondman@zerobarrier.nl)
#
# Latest Version: http://modx.com/extras/package/jot
# Jot Demo Site: http://projects.zerobarrier.nl/modx/
# Documentation: http://wiki.modxcms.com/index.php/Jot (wiki)
#
####*/

$jotPath = $modx->config[\'base_path\'] . \'assets/snippets/jot/\';
include_once($jotPath.\'jot.class.inc.php\');

$Jot = new CJot;
$Jot->VersionCheck("1.1.4");
$Jot->Set("path",$jotPath);
$Jot->Set("action", $action);
$Jot->Set("postdelay", $postdelay);
$Jot->Set("docid", $docid);
$Jot->Set("tagid", $tagid);
$Jot->Set("subscribe", $subscribe);
$Jot->Set("moderated", $moderated);
$Jot->Set("captcha", $captcha);
$Jot->Set("badwords", $badwords);
$Jot->Set("bw", $bw);
$Jot->Set("sortby", $sortby);
$Jot->Set("numdir", $numdir);
$Jot->Set("customfields", $customfields);
$Jot->Set("guestname", $guestname);
$Jot->Set("canpost", $canpost);
$Jot->Set("canview", $canview);
$Jot->Set("canedit", $canedit);
$Jot->Set("canmoderate", $canmoderate);
$Jot->Set("trusted", $trusted);
$Jot->Set("pagination", $pagination);
$Jot->Set("placeholders", $placeholders);
$Jot->Set("subjectSubscribe", $subjectSubscribe);
$Jot->Set("subjectModerate", $subjectModerate);
$Jot->Set("subjectAuthor", $subjectAuthor);
$Jot->Set("notify", $notify);
$Jot->Set("notifyAuthor", $notifyAuthor);
$Jot->Set("validate", $validate);
$Jot->Set("title", $title);
$Jot->Set("authorid", $authorid);
$Jot->Set("css", $css);
$Jot->Set("cssFile", $cssFile);
$Jot->Set("cssRowAlt", $cssRowAlt);
$Jot->Set("cssRowMe", $cssRowMe);
$Jot->Set("cssRowAuthor", $cssRowAuthor);
$Jot->Set("tplForm", $tplForm);
$Jot->Set("tplComments", $tplComments);
$Jot->Set("tplModerate", $tplModerate);
$Jot->Set("tplNav", $tplNav);
$Jot->Set("tplNotify", $tplNotify);
$Jot->Set("tplNotifyModerator", $tplNotifyModerator);
$Jot->Set("tplNotifyAuthor", $tplNotifyAuthor);
$Jot->Set("tplSubscribe", $tplSubscribe);
$Jot->Set("debug", $debug);
$Jot->Set("output", $output);
return $Jot->Run();';
$s['phpthumb'] = 'return require MODX_BASE_PATH.\'assets/snippets/phpthumb/snippet.phpthumb.php\';
';
$s['Breadcrumbs'] = 'return require MODX_BASE_PATH.\'assets/snippets/breadcrumbs/snippet.breadcrumbs.php\';';
$s['WebLogin'] = '# Created By Raymond Irving 2004
#::::::::::::::::::::::::::::::::::::::::
# Params:	
#
#	&loginhomeid 	- (Optional)
#		redirects the user to first authorized page in the list.
#		If no id was specified then the login home page id or 
#		the current document id will be used
#
#	&logouthomeid 	- (Optional)
#		document id to load when user logs out	
#
#	&pwdreqid 	- (Optional)
#		document id to load after the user has submited
#		a request for a new password
#
#	&pwdactid 	- (Optional)
#		document id to load when the after the user has activated
#		their new password
#
#	&logintext		- (Optional) 
#		Text to be displayed inside login button (for built-in form)
#
#	&logouttext 	- (Optional)
#		Text to be displayed inside logout link (for built-in form)
#	
#	&tpl			- (Optional)
#		Chunk name or document id to as a template
#				  
#	Note: Templats design:
#			section 1: login template
#			section 2: logout template 
#			section 3: password reminder template 
#
#			See weblogin.tpl for more information
#
# Examples:
#
#	[[WebLogin? &loginhomeid=`8` &logouthomeid=`1`]] 
#
#	[[WebLogin? &loginhomeid=`8,18,7,5` &tpl=`Login`]] 

# Set Snippet Paths 
$snipPath = $modx->config[\'base_path\'] . "assets/snippets/";

# check if inside manager
if ($m = $modx->isBackend()) {
	return \'\'; # don\'t go any further when inside manager
}

# deprecated params - only for backward compatibility
if(isset($loginid)) $loginhomeid=$loginid;
if(isset($logoutid)) $logouthomeid = $logoutid;
if(isset($template)) $tpl = $template;

# Snippet customize settings
$liHomeId	= isset($loginhomeid)? array_filter(array_map(\'intval\', explode(\',\', $loginhomeid))):array($modx->config[\'login_home\'],$modx->documentIdentifier);
$loHomeId	= isset($logouthomeid)? $logouthomeid:$modx->documentIdentifier;
$pwdReqId	= isset($pwdreqid)? $pwdreqid:0;
$pwdActId	= isset($pwdactid)? $pwdactid:0;
$loginText	= isset($logintext)? $logintext:\'Login\';
$logoutText	= isset($logouttext)? $logouttext:\'Logout\';
$tpl		= isset($tpl)? $tpl:"";

# System settings
$webLoginMode = isset($_REQUEST[\'webloginmode\'])? $_REQUEST[\'webloginmode\']: \'\';
$isLogOut		= $webLoginMode==\'lo\' ? 1:0;
$isPWDActivate	= $webLoginMode==\'actp\' ? 1:0;
$isPostBack		= count($_POST) && (isset($_POST[\'cmdweblogin\']) || isset($_POST[\'cmdweblogin_x\']));
$txtPwdRem 		= isset($_REQUEST[\'txtpwdrem\'])? $_REQUEST[\'txtpwdrem\']: 0;
$isPWDReminder	= $isPostBack && $txtPwdRem==\'1\' ? 1:0;

$site_id = isset($site_id)? $site_id: \'\';
$cookieKey = substr(md5($site_id."Web-User"),0,15);

# Start processing
include_once $snipPath."weblogin/weblogin.common.inc.php";
include_once ($modx->config[\'site_manager_path\'] . "includes/crypt.class.inc.php");

if ($isPWDActivate || $isPWDReminder || $isLogOut || $isPostBack) {
	# include the logger class
	include_once $modx->config[\'site_manager_path\'] . "includes/log.class.inc.php";
	include_once $snipPath."weblogin/weblogin.processor.inc.php";
}

include_once $snipPath."weblogin/weblogin.inc.php";

# Return
return $output;
';
$s['WebLoginProps'] = '&loginhomeid=Login Home Id;string; &logouthomeid=Logout Home Id;string; &logintext=Login Button Text;string; &logouttext=Logout Button Text;string; &tpl=Template;string; ';
$s['FirstChildRedirect'] = 'return require MODX_BASE_PATH.\'assets/snippets/firstchildredirect/snippet.firstchildredirect.php\';';
$s['eForm'] = 'return require MODX_BASE_PATH.\'assets/snippets/eform/snippet.eform.php\';';
$s['Wayfinder'] = 'return require MODX_BASE_PATH.\'assets/snippets/wayfinder/snippet.wayfinder.php\';
';
$s['MemberCheck'] = 'return require MODX_BASE_PATH.\'assets/snippets/membercheck/snippet.membercheck.php\';';
$s['WebChangePwd'] = '# Created By Raymond Irving April, 2005
#::::::::::::::::::::::::::::::::::::::::
# Params:	
#
#	&tpl			- (Optional)
#		Chunk name or document id to use as a template
#				  
#	Note: Templats design:
#			section 1: change pwd template
#			section 2: notification template 
#
# Examples:
#
#	[[WebChangePwd? &tpl=`ChangePwd`]] 

# Set Snippet Paths 
$snipPath  = (($modx->isBackend())? "../":"");
$snipPath .= "assets/snippets/";

# check if inside manager
if ($m = $modx->isBackend()) {
	return \'\'; # don\'t go any further when inside manager
}


# Snippet customize settings
$tpl		= isset($tpl)? $tpl:"";

# System settings
$isPostBack		= count($_POST) && isset($_POST[\'cmdwebchngpwd\']);

# Start processing
include_once $snipPath."weblogin/weblogin.common.inc.php";
include_once $snipPath."weblogin/webchangepwd.inc.php";

# Return
return $output;



';
$s['WebSignup'] = '# Created By Raymond Irving April, 2005
#::::::::::::::::::::::::::::::::::::::::
# Usage:     
#    Allows a web user to signup for a new web account from the website
#    This snippet provides a basic set of form fields for the signup form
#    You can customize this snippet to create your own signup form
#
# Params:    
#
#    &tpl        - (Optional) Chunk name or document id to use as a template
#	    		   If custom template AND captcha on AND using WebSignup and 
#                  WebLogin on the same page make sure you have a field named
#                  cmdwebsignup. In the default template it is the submit button 
#                  One can use a hidden field.
#    &groups     - Web users groups to be assigned to users
#    &useCaptcha - (Optional) Determine to use (1) or not to use (0) captcha
#                  on signup form - if not defined, will default to system
#                  setting. GD is required for this feature. If GD is not 
#                  available, useCaptcha will automatically be set to false;
#                  
#    Note: Templats design:
#        section 1: signup template
#        section 2: notification template 
#
# Examples:
#
#    [[WebSignup? &tpl=`SignupForm` &groups=`NewsReaders,WebUsers`]] 

# Set Snippet Paths 
$snipPath = $modx->config[\'base_path\'] . "assets/snippets/";

# check if inside manager
if ($m = $modx->isBackend()) {
    return \'\'; # don\'t go any further when inside manager
}


# Snippet customize settings
$tpl = isset($tpl)? $tpl:"";
$useCaptcha = isset($useCaptcha)? $useCaptcha : $modx->config[\'use_captcha\'] ;
// Override captcha if no GD
if ($useCaptcha && !gd_info()) $useCaptcha = 0;

# setup web groups
$groups = isset($groups) ? array_filter(array_map(\'trim\', explode(\',\', $groups))):array();

# System settings
$isPostBack        = count($_POST) && isset($_POST[\'cmdwebsignup\']);

$output = \'\';

# Start processing
include_once $snipPath."weblogin/weblogin.common.inc.php";
include_once $snipPath."weblogin/websignup.inc.php";

# Return
return $output;';
$s['WebSignupProps'] = '&tpl=Template;string; ';
$s['Personalize'] = 'return require MODX_BASE_PATH.\'assets/snippets/personalize/snippet.personalize.php\';';
$s['AjaxSearch'] = 'return require MODX_BASE_PATH.\'assets/snippets/ajaxSearch/snippet.ajaxSearch.php\';';
$s['if'] = 'return require MODX_BASE_PATH.\'assets/snippets/if/snippet.if.php\';';
$s['ListIndexer'] = 'return require MODX_BASE_PATH.\'assets/snippets/listindexer/snippet.listindexer.php\';';
$s['WayfinderScorn'] = '
if(!defined(\'MODX_BASE_PATH\')){die(\'What are you doing? Get out of here!\');}
/*
::::::::::::::::::::::::::::::::::::::::
 Snippet name: Wayfinder
 Short Desc: builds site navigation
 Version: 2.0.1
 Authors: 
	Kyle Jaebker (muddydogpaws.com)
	Ryan Thrash (vertexworks.com)
 Date: February 27, 2006
::::::::::::::::::::::::::::::::::::::::
Description:
    Totally refactored from original DropMenu nav builder to make it easier to
    create custom navigation by using chunks as output templates. By using templates,
    many of the paramaters are no longer needed for flexible output including tables,
    unordered- or ordered-lists (ULs or OLs), definition lists (DLs) or in any other
    format you desire.
::::::::::::::::::::::::::::::::::::::::
Example Usage:
    [[Wayfinder? &startId=`0`]]
::::::::::::::::::::::::::::::::::::::::
*/

$wayfinder_sc_base = $modx->config[\'base_path\']."assets/snippets/wayfinder_scorn/";

//Include a custom config file if specified
$config = (isset($config)) ? "{$wayfinder_sc_base}configs/{$config}.config.php" : "{$wayfinder_sc_base}configs/default.config.php";
if (file_exists($config)) {
	include("$config");
}

include_once("{$wayfinder_sc_base}wayfinder.inc.php");

if (class_exists(\'ScornWayfinder\')) {
   $wf = new ScornWayfinder();
} else {
    return \'error: Wayfinder class not found\';
}

$wf->_config = array(
	\'id\' => isset($startId) ? $startId : $modx->documentIdentifier,
	\'level\' => isset($level) ? $level : 0,
	\'includeDocs\' => isset($includeDocs) ? $includeDocs : 0,
	\'excludeDocs\' => isset($excludeDocs) ? $excludeDocs : 0,
	\'ph\' => isset($ph) ? $ph : FALSE,
	\'debug\' => isset($debug) ? TRUE : FALSE,
	\'ignoreHidden\' => isset($ignoreHidden) ? $ignoreHidden : FALSE,
	\'hideSubMenus\' => isset($hideSubMenus) ? $hideSubMenus : FALSE,
	\'useWeblinkUrl\' => isset($useWeblinkUrl) ? $useWeblinkUrl : TRUE,
	\'fullLink\' => isset($fullLink) ? $fullLink : FALSE,
	\'nl\' => isset($removeNewLines) ? \'\' : "\\n",
	\'sortOrder\' => isset($sortOrder) ? strtoupper($sortOrder) : \'ASC\',
	\'sortBy\' => isset($sortBy) ? $sortBy : \'menuindex\',
	\'limit\' => isset($limit) ? $limit : 0,
	\'cssTpl\' => isset($cssTpl) ? $cssTpl : FALSE,
	\'jsTpl\' => isset($jsTpl) ? $jsTpl : FALSE,
	\'rowIdPrefix\' => isset($rowIdPrefix) ? $rowIdPrefix : FALSE,
	\'textOfLinks\' => isset($textOfLinks) ? $textOfLinks : \'menutitle\',
	\'titleOfLinks\' => isset($titleOfLinks) ? $titleOfLinks : \'pagetitle\',
	\'displayStart\' => isset($displayStart) ? $displayStart : FALSE,
	\'entityEncode\' => isset($entityEncode) ? $entityEncode : TRUE,
	
	\'prefFC\' => isset($prefClass) ? $prefClass : \'\',
	\'only\' => $onlyThis == \'folders\' ? \'folders\' : FALSE,
	\'onlyStart\' => isset($onlyThisStart) ? $onlyThisStart : FALSE,
	\'onlyForReg\' => isset($onlyForReg) ? $onlyForReg : FALSE,
);

//get user class definitions
$wf->_css = array(
	\'first\' => isset($firstClass) ? $prefClass . $firstClass : \'\',
	\'last\' => isset($lastClass) ? $prefClass . $lastClass : $prefClass . \'last\',
	\'here\' => isset($hereClass) ? $prefClass . $hereClass : $prefClass . \'active\',
	\'parent\' => isset($parentClass) ? $prefClass . $parentClass : \'\',
	\'row\' => isset($rowClass) ? $prefClass . $rowClass : \'\',
	\'outer\' => isset($outerClass) ? $prefClass . $outerClass : \'\',
	\'inner\' => isset($innerClass) ? $prefClass . $innerClass : \'\',
	\'level\' => isset($levelClass) ? $prefClass . $levelClass: \'\',
	\'self\' => isset($selfClass) ? $prefClass . $selfClass : $prefClass . \'iam\',
	\'weblink\' => isset($webLinkClass) ? $prefClass . $webLinkClass : \'\',
	
	\'open\' => isset($openClass) ? $prefClass . $openClass : $prefClass . \'open\',
	\'empty\' => isset($emptyClass) ? $prefClass . $emptyClass : $prefClass . \'empty\',
	\'link\' => isset($linkClass) ? $linkClass : \'\',
);

//get user templates
$wf->_templates = array(
	\'outerTpl\' => isset($outerTpl) ? $outerTpl : \'\',
	\'rowTpl\' => isset($rowTpl) ? $rowTpl : \'\',
	\'parentRowTpl\' => isset($parentRowTpl) ? $parentRowTpl : \'\',
	\'parentRowHereTpl\' => isset($parentRowHereTpl) ? $parentRowHereTpl : \'\',
	\'hereTpl\' => isset($hereTpl) ? $hereTpl : \'\',
	\'innerTpl\' => isset($innerTpl) ? $innerTpl : \'\',
	\'innerRowTpl\' => isset($innerRowTpl) ? $innerRowTpl : \'\',
	\'innerHereTpl\' => isset($innerHereTpl) ? $innerHereTpl : \'\',
	\'activeParentRowTpl\' => isset($activeParentRowTpl) ? $activeParentRowTpl : \'\',
	\'categoryFoldersTpl\' => isset($categoryFoldersTpl) ? $categoryFoldersTpl : \'\',
	\'startItemTpl\' => isset($startItemTpl) ? $startItemTpl : \'\',
);

//Process Wayfinder
$output = $wf->run();

if ($wf->_config[\'debug\']) {
	$output .= $wf->renderDebugOutput();
}

//Ouput Results
if ($wf->_config[\'ph\']) {
    $modx->setPlaceholder($wf->_config[\'ph\'],$output);
    return;
} else {
    return $output;
}
';
$s['StrToLower'] = '
//v01
//=======================================================================
$lower = array( "А"=>"а", "Б"=>"б", "В"=>"в", "Г"=>"г", "Д"=>"д", "Е"=>"е", "Ё"=>"ё", "Ж"=>"ж", "З"=>"з", "И"=>"и", "Й"=>"й",
        "К"=>"к", "Л"=>"л", "М"=>"м", "Н"=>"н", "О"=>"о", "П"=>"п", "Р"=>"р", "С"=>"с", "Т"=>"т", "У"=>"у", "Ф"=>"ф", "Х"=>"х", "Ц"=>"й", "Ч"=>"ч", "Ш"=>"ш",
        "Щ"=>"щ", "Ы"=>"ы", "Ь"=>"ь", "Ъ"=>"ъ", "Э"=>"э", "Ю"=>"ю", "Я"=>"я" );
$upper= array_flip( $lower );
$txt= strtolower( $txt );
$txt= ucfirst( $txt );
$txt= strtr( $txt, $lower );
if( $upper[ substr( $txt, 0, 2 ) ] ) $txt= $upper[ substr( $txt, 0, 2 ) ] . substr( $txt, 2 );
return $txt;
';
$s['Price'] = '
if( empty( $delimiter ) ) $delimiter= \'&thinsp;\';
	if( empty( $round ) ) $round= 2;
	
$price= mysql_escape_string( trim( $price ) );
	
	$price= str_replace( ",", ".", $price );
	
	$price= round( $price, $round );

	if( $price <= 0 || $price == \'\' ) return "&mdash;";
	
	$tmp= explode( ".", $price );
	
	$itogo_price= \'\';
	$ii= 0;
	for( $kk=strlen( $tmp[ 0 ] )-1; $kk >= 0; $kk-- )
	{
		$ii++;
		$itogo_price= substr( $tmp[ 0 ], $kk, 1 ) . $itogo_price;
		if( $ii % 3 == 0 && $kk > 0 )
		{
			$itogo_price= $delimiter . $itogo_price;
		}
	}
	if( $tmp[ 1 ] > 0 ) $itogo_price .= \',\'. $tmp[ 1 ];

//$price= @number_format( $price, ( strstr( $price, "." ) ? 2 : 0 ), \',\', "&thinsp;" );
//$price= @money_format( $price, ( strstr( $price, "." ) ? 2 : 0 ), \',\', "&thinsp;" );
	
//$pr .= \'<span class="pr_mini">,00</span>\';
	
	return $itogo_price;
';
$s['GetLvl'] = '
//v002
//================== Определение уровня вложенности ====================
	if( $id == $koren )
	{
		print \'1\';
	
	}else{
		$lvl= 2;
		$doc= $modx->getDocument( $id, \'parent\' );
		
		while( $doc[ \'parent\' ] != $koren && $doc[ \'parent\' ] != 0 )
		{
			$lvl++;
			$doc= $modx->getDocument( $doc[ \'parent\' ], \'parent\' );
		}
		
		if( $koren != 0 && $doc[ \'parent\' ] == 0 )
		{
			print \'0\';
		}else{
			print $lvl;	
		}
	}
//====================================================================
';
$s['GetIdOnLvl'] = '
//v005
//================== Список ИД всех родителей ====================
$doc= $modx->getDocument( $id, \'id,parent\'.( $fields ? \',\' : \'\' ).$fields );

$list[]= $doc;

while( $id != $koren && $doc[ \'parent\' ] != $koren && $doc[ \'parent\' ] != 0 )
{
	$doc= $modx->getDocument( $doc[ \'parent\' ], \'id,parent\'.( $fields ? \',\' : \'\' ).$fields );
	$list[]= $doc;
}

if( $doc[ \'parent\' ] == 0 )
{
	$list[]= array( \'id\'=>0 );
}elseif( $doc[ \'parent\' ] == $koren ){
	$doc= $modx->getDocument( $doc[ \'parent\' ], \'id,parent\'.( $fields ? \',\' : \'\' ).$fields );
	$list[]= $doc;
}

$list[]= false;
$list= array_reverse( $list );

return ( $lvl ? $list[ $lvl ][ ( $prm ? $prm : \'id\' ) ] : $list );
//====================================================================
';
$s['GetDoc6'] = '
// 6.0 ver.
//==========================================================================
	
	// idslist - только эти документы
	// slice - срез итогового массива документов - функция array_slice();
	
// id = 1,2,5,255
	// type = this | childs | all
	// depth = 0 | 3 | 1,2,4 : 4-макс.уровень, а 1 и 2 игнорируются
	// fields = \'pagetitle,content\'
	// tvfileds = \'image,price\'
	// sort = \'field DESC, field_2 ASC\'
	// tpl = 0 | 10 | 6,-7,8
	// isf
	// param
	// query
	// limit
	// clone - Клонировать в категории (ID TV параметра) значение параметра: ,345,123,56,
	// publ
	// del

// ВЫЧЛЕНЕНИЕ ДОКУМЕНТОВ
	//function getdoc50( $ids=\'0,1\', $type=\'childs\', $depth=0, $fields=\'\', $tvfileds=\'\', $sort=\'isfolder DESC, menuindex\', $tpl=0, $isf=\'all\', $param=\'\', $query=\'\', $limit=0, $clone=\'\' )
	//{
	
	$table1= \'site_content\';
	$table2= \'site_tmplvars\';
	$table3= \'site_tmplvar_contentvalues\';
	
	$docs= explode( \',\', $ids );
	
	if( count( $docs ) > 0 )
	{
		$type= ( $type && ( $type == \'this\' || $type == \'all\' ) ? $type : \'childs\' );
		
		if( ! empty( $fields ) )
		{
			$arr_fields= explode( \',\', $fields );
		}
		
		if( ! empty( $tvfileds ) )
		{
			$tvfileds= explode( \',\', $tvfileds );
			$tvfileds_flag= true;
			foreach( $tvfileds AS $val )
			{
				if( $qq_tvfileds != "" ) $qq_tvfileds .= " OR ";
				$qq_tvfileds .= "tv.`name`=\'{$val}\'";
			}
			if( $qq_tvfileds ) $qq_tvfileds= "AND ( {$qq_tvfileds} )";
		}
			
		if( $tpl )
		{
			$flag_tpl= ( strstr( $tpl, "-" ) ? false : true );
			$tpl= trim( $tpl, "-" );
			$arr_tpl= explode( \',\', $tpl );
			foreach( $arr_tpl AS $key => $val )
			{
				if( $val == 0 )
				{
					$qq_tpl= "";
					break 1;
				}else{
					if( $qq_tpl != \'\' ) $qq_tpl .= ( $flag_tpl ? " OR " : " AND " );
					$qq_tpl .= "template ".( $flag_tpl ? "=" : "<>" )." {$val}";
				}
			}
			if( $qq_tpl ) $qq_tpl= "AND ( {$qq_tpl} )";
		}
		
		if( empty( $isf ) ) $isf= "0";
		if( $isf != \'all\' )
		{
			$qq_isf= "AND isfolder=". ( $isf ? "1" : "0" );
		}
		
		$qq_published= "AND published=";
		if( $publ == \'0\' ) $qq_published .= "0"; else $qq_published .= "1";
		if( $publ == \'all\' ) $qq_published= "";
		
		$qq_deleted= "AND deleted=";
		if( $del == \'1\' ) $qq_deleted .= "1"; else $qq_deleted .= "0";
		if( $del == \'all\' ) $qq_deleted= "";
		
		$query= ( ! empty( $query ) ? "AND ". $query : "" );
		
		if( $type != \'this\' )
		{
			if( $depth )
			{
				$depths= explode( \',\', $depth );
				
				if( count( $depths ) >= 2 )
				{
					$maxlvl= $depths[ count( $depths )-1 ];
					foreach( $depths AS $key => $val ) if( $key != count( $depths )-1 ) $ignore_lvl[ $val ]= true;
					
				}elseif( count( $depths ) == 1 ){
					$maxlvl= $depth;
				}
			}
			if( ! $maxlvl ) $maxlvl= 999;
			
			$qq_sort= ( ! empty( $sort ) ? "ORDER BY ". $sort : "" );
			
			$qq_limit= ( ! empty( $limit ) ? "LIMIT ". $limit : "" );
			
			if( $slice ) $slice= explode( ",", $slice );
		}
		
		
//======================================================
		
		foreach( $docs AS $row )
		{
			if( ! $ignore_lvl[ 0 ] )
			{
				$ids_for_result[ $row ]= array( $row, 0, true );
			}
			$ids_for_check[ $row ]= array( $row, 0, true );
			
			if( $type != \'this\' )
			{
				if( ! empty( $clone ) )
				{
					$rr= mysql_query( "SELECT * FROM ". $modx->getFullTableName( $table3 ) ." WHERE tmplvarid={$clone} AND `value` LIKE \'%,{$row},%\'" );
					if( $rr && mysql_num_rows( $rr ) > 0 )
					{
						while( $cln= mysql_fetch_assoc( $rr ) )
						{
							$clones[ $cln[ \'contentid\' ] ]= $cln[ \'contentid\' ];
						}
					}
				}
			}
		}
		
		$idslist= explode( \',\', $idslist );
		$qq_onlyids= "";
		if( ! empty( $idslist ) )
		{
			foreach( $idslist AS $val )
			{
				if( $val ) $qq_onlyids .= ( $qq_onlyids ? " OR " : "AND ( " ) ."id={$val}";
			}
			if( ! empty( $qq_onlyids ) ) $qq_onlyids .= " )";
		}
		
		if( $type != \'this\' )
		{
			while( count( $ids_for_check ) > 0 )
			{
				$row= array_shift( $ids_for_check );
				$rr= mysql_query( "SELECT id FROM ". $modx->getFullTableName( $table1 ) ." WHERE parent={$row[0]} AND isfolder=1 {$qq_published} {$qq_deleted}" );
				if( $rr && mysql_num_rows( $rr ) > 0 )
				{
					$lvlii= $row[ 1 ] + 1;
					for( $kk=0; $kk<mysql_num_rows( $rr ); $kk++ )
					{
						if( $lvlii <= $maxlvl )
						{
							$ids_for_result[ mysql_result( $rr, $kk, \'id\' ) ]= array( mysql_result( $rr, $kk, \'id\' ), $lvlii );
							$ids_for_check[ mysql_result( $rr, $kk, \'id\' ) ]= array( mysql_result( $rr, $kk, \'id\' ), $lvlii );
						}
					}
				}
			}
		}
		
		if( count( $ids_for_result ) > 0 )
		{
			foreach( $ids_for_result AS $key => $val )
			{
				$lvlii= $val[ 1 ];
				$lvliii= $lvlii + 1;
				
				$tmp1= ( ! $ignore_lvl[ $lvlii ] && $lvlii <= $maxlvl && ( $type != \'childs\' || ! $val[ 2 ] ) ? "id={$key}" : "" );
				$tmp2= ( ! $ignore_lvl[ $lvliii ] && $lvliii <= $maxlvl && ( ! $isf || $isf == \'all\' ) ? ( $tmp1 ? " OR " : "" ) ."parent={$key}" : "" );
				
				if( $tmp1 || $tmp2 )
				{
					if( $qq_ids != \'\' ) $qq_ids .= " OR ";
					$qq_ids .= "( {$tmp1}{$tmp2} )";
				}
			}
		}
		
		if( ! empty( $clones ) )
		{
			foreach( $clones AS $cln )
			{
				$qq_ids .= ( ! empty( $qq_ids ) ? " OR " : "" ) ."( id={$cln} )";
			}
		}
		
		$qq= "SELECT id".( $fields ? ",".$fields : "" )." FROM ". $modx->getFullTableName( $table1 ) ."
			WHERE ( {$qq_ids} ) {$qq_onlyids} {$qq_tpl} {$qq_isf} {$query} {$qq_published} {$qq_deleted}
				{$qq_sort} {$qq_limit}";
		
		$rr= mysql_query( $qq );
		$qq_ids= "";
		if( $rr )
		{
			while( $row= mysql_fetch_assoc( $rr ) )
			{
				$itogo[ $row[ \'id\' ] ]= $row;
				
				if( $tvfileds_flag )
				{
					if( $qq_ids != "" ) $qq_ids .= " OR ";
					$qq_ids .= "tvc.contentid={$row[id]}";
				}
			}
		}
		
		if( $tvfileds_flag && ! empty( $itogo ) )
		{
			if( $qq_ids ) $qq_ids= "AND ( {$qq_ids} )";
			
			$rr= mysql_query( "SELECT id, name, default_text FROM ". $modx->getFullTableName( $table2 ) ." AS tv WHERE 1=1 {$qq_tvfileds}" );
			if( $rr )
			{
				while( $row= mysql_fetch_assoc( $rr ) )
				{
					$tvdefault[ $row[ \'name\' ] ]= $row[ \'default_text\' ];
				}
			}
			
			$rr= mysql_query( "SELECT tv.default_text,tv.`name`,tvc.contentid,tvc.`value` FROM ". $modx->getFullTableName( $table2 ) ." AS tv, ". $modx->getFullTableName( $table3 ) ." AS tvc
				WHERE tv.id=tvc.tmplvarid {$qq_tvfileds} {$qq_ids} ORDER BY tv.id" );
			if( $rr )
			{
				while( $row= mysql_fetch_assoc( $rr ) )
				{
					$itogo[ $row[ \'contentid\' ] ][ $row[ \'name\' ] ]= $row[ \'value\' ];
				}
			}
			
			foreach( $itogo AS $key => $val )
			{
				foreach( $tvfileds AS $key2 => $val2 )
				{
					if( ! isset( $val[ $val2 ] ) || empty( $val[ $val2 ] ) )
						$itogo[ $key ][ $val2 ]= $tvdefault[ $val2 ];
				}
			}
		}
		
		if( $slice )
		{
			$itogo= array_slice( $itogo, $slice[ 0 ], ( $slice[ 1 ] ? $slice[ 1 ] : null ) );
		}
	}
	
	return $itogo;
//}


	// СОРТИРОВКА ПО TV-параметрам
	/*if( $docs2 )
	{
		foreach( $docs2 AS $row )
		{
			$tmp= intval( $row[ \'price\' ] );
			$tmp= str_pad( $tmp, 10, \'0\', STR_PAD_LEFT );
			$sortirovka[ $tmp .\'__\'. $row[ \'pagetitle\' ] .\'__\'. $row[ \'id\' ] ]= $row;
		}
		ksort( $sortirovka );
		$docs2= array_slice( $sortirovka, $page_s, $MaxItemsInPage );
	}*/
	// СОРТИРОВКА ПО TV-параметрам
';
$s['Alt'] = '
//v002
//============================================================================
global $altcounter;
if( $plus ) $altcounter[ $name ] += $plus;
if( $print == \'ii\' ) return $altcounter[ $name ];
	elseif( ! empty( $print ) && $kk && $altcounter[ $name ] % $kk == 0 ) return $print;
';
$s['AJAX'] = '

';
$s['CATALOG'] = '
//============================================================================
	
	
$myid= $modx->documentIdentifier;
if( empty( $id ) ) $id= $myid;
$doc= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$id, \'type\'=>\'this\', \'fields\'=>\'pagetitle\', \'tvfileds\'=>\'\', \'isf\'=>\'all\' ) );
$doc= $doc[ $id ];


$MaxItemsInPage= 99999;
$koren= 8;


$modx->catalogItemId= intval( $modx->catalogItemId );


$mylvl= $modx->runSnippet( \'GetLvl\', array( \'koren\' => $koren, \'id\' => $id ) );


$page= intval( $modx->catalogPageNum );
if( $page > 1 && $page < 100 ){}else{ $page= 1; }
$page_s= ( $page - 1 ) * $MaxItemsInPage;


if( $modx->catalogItemId )
{
	$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'_catalog\' )." WHERE parent={$id} AND id=". $modx->catalogItemId ." LIMIT 1" );
	if( $rr && mysql_num_rows( $rr ) == 1 )
	{
		
		
	}elseif( $rr ){
		$modx->sendErrorPage();
	}
	
}else{
	$dopqq= $dopdopww= "";
	if( $modx->catalogFilterListX )
	{
		$xps= explode( "/", $modx->catalogFilterListX );
		$xps_vals= array();
		if( $xps )
		{
			foreach( $xps AS $xp )
			{
				if( $xp == \'p_y\' ){ $dopqq .= " AND packaging=\'y\'";
				}elseif( $xp == \'d_y\' ){ $dopqq .= " AND documentation!=\'\'";
				}elseif( $xp == \'dc_y\' ){ $dopqq .= " AND discount!=\'0\'";
				}elseif( $xp == \'s1_y\' ){ $dopdopww .= ( ! empty( $dopdopww ) ? " OR " : "" ) ."state=\'new\'";
				}elseif( $xp == \'s2_y\' ){ $dopdopww .= ( ! empty( $dopdopww ) ? " OR " : "" ) ."state=\'bu\'";
				}elseif( $xp == \'s3_y\' ){ $dopdopww .= ( ! empty( $dopdopww ) ? " OR " : "" ) ."state=\'zapch\'";
				}else{
					$xp= explode( "_", $xp );
					if( $xp[ 0 ] == \'a\' && ! empty( $xp[ 1 ] ) )
					{
						$dopqq .= " AND code LIKE \'%{$xp[1]}%\'";
						
					}elseif( $xp[ 0 ] == \'v\' && ! empty( $xp[ 1 ] ) ){
						$dopqq .= " AND manufacturer LIKE \'%{$xp[1]}%\'";
						
					}elseif( $xp[ 0 ] == \'c\' && ! empty( $xp[ 1 ] ) ){
						
					}elseif( $xp[ 0 ] == \'t\' && ! empty( $xp[ 1 ] ) ){
						$dopqq .= " AND ( code LIKE \'%{$xp[1]}%\' OR title LIKE \'%{$xp[1]}%\' OR manufacturer LIKE \'%{$xp[1]}%\' OR text LIKE \'%{$xp[1]}%\' )";
					}
				}
			}
		}
	}
	if( $dopdopww ) $dopqq .= " AND ( {$dopdopww} )";
	
	if( $mylvl == 1 && ! $modx->catalogFilterListX )
	{
		$print_categories .= $modx->runSnippet( \'Catalog_BigMenu\' );
		
	}else{
		if( $id != $koren )
		{
			$childs= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$id, \'type\'=>\'all\', \'depth\'=>\'0\', \'isf\'=>\'all\' ) );
			if( $childs )
			{
				foreach( $childs AS $row ) $childsids .= ( ! empty( $childsids ) ? " OR " : "" ) ."parent=". $row[ \'id\' ];
			}
		}else{
			$childsids= "1=1";
		}
		
		
		if( $id != $koren )
		{
			$subcat= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$id, \'type\'=>\'childs\', \'depth\'=>\'1\', \'fields\'=>\'pagetitle\', \'isf\'=>\'all\' ) );
			if( $subcat )
			{
				$print_categories .= \'<div class="catcatsmini">\';
				foreach( $subcat AS $row )
				{
					$print_categories .= \'<div class="catcatmin"><a class="as2" href="\'. $modx->makeUrl( $row[ \'id\' ] ) .\'">\'. $row[ \'pagetitle\' ] .\'</a></div>\';
				}
				$print_categories .= \'<div class="clr">&nbsp;</div></div>\';
			}
		}
		
		
		$items= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'_catalog\' )." WHERE ( {$childsids} ) {$dopqq} ORDER BY id" );
		
		$print_items .= \'<table class="catalog_table" cellpadding="0" cellspacing="0">\';
		$print_items .= \'<tr class="jqt_row_tit">\';
		$print_items .= \'<td class="jqtrt_col jqtrtc_code">Код</td>\';
		$print_items .= \'<td class="jqtrt_col jqtrtc_vend">Производитель</td>\';
		$print_items .= \'<td class="jqtrt_col jqtrtc_name">Описание</td>\';
		$print_items .= \'<td class="jqtrt_col jqtrtc_stock">В наличии</td>\';
		$print_items .= \'<td class="jqtrt_col jqtrtc_price">Цена, руб.</td>\';
		$print_items .= \'<td class="jqtrt_col jqtrtc_basket">Заказ</td>\';
		$print_items .= \'<td class="jqtrt_col jqtrtc_city">Продавец</td>\';
		$print_items .= \'</tr>\';
		
		$ii= 0;
		while( $row= mysql_fetch_assoc( $items ) )
		{
			$ii++;
			$print_items .= $modx->runSnippet( \'CAT_ITEM\', array( \'type\' => \'item\', \'row\' => $row, \'last\' => ( $ii % 2 == 0 ? true : false ) ) );
		}
		
		$print_items .= \'</table>\';
	}
}


$print .= \'<div class="catalog">\';
if( ! empty( $print_categories ) )
{
	$print .= $print_categories;
	$print .= \'<div class="clr">&nbsp;</div>\';
}
if( ! empty( $print_items ) )
{
	$print .= $print_items;
	$print .= \'<div class="clr">&nbsp;</div>\';
}
$print .= \'</div>\';


return $print;
';
$s['CAT_ITEM'] = '
$states= array(
	\'new\' => \'Новое\', \'bu\' => \'Б/У\', \'zapch\' => \'На запчасти\',
);
	
if( $type == \'category_1\' )
{
	$podcat= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$row[ \'id\' ], \'type\'=>\'childs\', \'depth\'=>\'1\', \'fields\'=>\'pagetitle\', \'isf\'=>\'all\' ) );
	
	$result .= \'<div class="catcat_big \'.( $last ? \'catcat_big_last\' : \'\' ).\'">
		<div class="catcatb_img"><img src="\'. $modx->runSnippet( \'ImgCrop6\', array( \'img\'=>$row[ \'image\' ], \'w\'=>86, \'h\'=>86, \'backgr\'=>true ) ) .\'" /></div>
		<div class="catcatb_rght">
			<div class="catcatb_tit"><a class="as1" href="\'. $modx->makeUrl( $row[ \'id\' ] ) .\'">\'. $row[ \'pagetitle\' ] .\'</a></div>
			<div class="catcatb_podcat">\';
	
	if( $podcat )
	{
		foreach( $podcat AS $row2 )
		{
			$result .= \'<div class="catcatb_podcat_itm"><span class="famicon">&nbsp;&nbsp;</span><a class="as2" href="\'. $modx->makeUrl( $row2[ \'id\' ] ) .\'">\'. $row2[ \'pagetitle\' ] .\'</a></div>\';
		}
	}
	
	$result .= \'</div>
		</div>
		<div class="clr">&nbsp;</div>
	</div>\';
	
	if( $last ? \'catcat_big_last\' : \'\' ) $result .= \'<div class="clr">&nbsp;</div>\';
}








if( $type == \'category_2\' )
{
	$result .= \'<div class="catcat \'.( $last ? \'catcat_last\' : \'\' ).\'"><a href="\'. $modx->makeUrl( $row[ \'id\' ] ) .\'">
					<div class="catc_img"><img src="\'. $modx->runSnippet( \'ImgCrop6\', array( \'img\'=>$row[ \'image\' ], \'w\'=>180, \'h\'=>180, \'fill\'=>1 ) ) .\'" /></div>
					<div class="catc_a"><span class="as2">\'. $row[ \'pagetitle\' ] .\'</span></div>
				</a></div>\';
	
	if( $last ? \'catcat_last\' : \'\' ) $result .= \'<div class="clr">&nbsp;</div>\';
}








if( $type == \'item\' )
{
	$item_state= $modx->runSnippet( \'BasketAction\', array( \'act\' => \'stat\', \'id\' => $row[ \'id\' ] ) );
	
	if( $row[ \'currency\' ] != \'rub\' ) $row[ \'price\' ]= $modx->runSnippet( \'ExchangeRates_Price\', array( \'price\'=>$row[ \'price\' ], \'c\'=>$row[ \'currency\' ] ) );
	
	$row[ \'text\' ]= $modx->runSnippet( \'str_replace\', array( \'from\'=>"\\n", \'to\'=>\'<br />\', \'txt\'=>$row[ \'text\' ] ) );
	
	$result .= \'<tr class="jqt_row_itm \'.( $last ? \'jqtri_chet\' : \'\' ).\'">\';
		$result .= \'<td class="jqtri_col jqtric_code"><a class="as1" href="\'. $modx->makeUrl( $row[ \'parent\' ] ) .\'i/\'. $row[ \'id\' ] .\'/">\'. $row[ \'code\' ] .\'</a></td>\';
		$result .= \'<td class="jqtri_col jqtric_vend">\'. $row[ \'manufacturer\' ] .\'</td>\';
	$result .= \'<td class="jqtri_col jqtric_name"><div class="descr">\'. $row[ \'text\' ] .\'</div><div class="fulldescription"><div class="ugolok">&nbsp;</div>\'. $row[ \'text\' ] .\'</div></td>\';
		$result .= \'<td class="jqtri_col jqtric_stock">\'. $row[ \'in_stock\' ] .\' шт.</td>\';
		$result .= \'<td class="jqtri_col jqtric_price"><nobr><span class="price">\'. $modx->runSnippet( \'Price\', array( \'price\' => $row[ \'price\' ], \'round\' => 0 ) ) .\'</span> <span class="rubl">a</span></nobr></td>\';
		$result .= \'<td class="jqtri_col jqtric_basket"><div class="cati_tobasket add_to_basket" id="ci_tobasket_\'. $row[ \'id\' ] .\'" data-itemid="\'. $row[ \'id\' ] .\'">
			<button class="buttonsubmit">В корзину</button>
		</td>\';
		$result .= \'<td class="jqtri_col jqtric_city">Ростов-на-Дону</td>\';
	$result .= \'</tr>\';
}








return $result;
';
$s['ImgCrop6'] = '
/* v.6 */
//function ImgCrop( $img, $w=0, $h=0, $backgr=false, $fill=false, $x=\'center\', $y=\'center\', $rgba=\'255,255,255,127\', $wm=false, $filter=-1, $png=false, $refresh=false )
/*
	$img=
	$w=
	$h=
	$backgr=
	$fill=
	$x=
	$y=
	$rgba=
	$wm=
	$filter=
	$png=
	$r=
	$ellipse=
	$dopimg=
	$toimg=
	$quality=
*/
//===============================================================================================================================
	
	$img= urldecode( $img );
	$w= ( empty( $w ) ? 0 : $w );
	$h= ( empty( $h ) ? 0 : $h );
	$backgr= ( empty( $backgr ) ? false : $backgr );
	$fill= ( empty( $fill ) ? false : $fill );
	$x= ( empty( $x ) ? \'center\' : $x );
	$y= ( empty( $y ) ? \'center\' : $y );
	$rgba= ( empty( $rgba ) ? \'255,255,255,127\' : $rgba );
	$wm= ( empty( $wm ) ? false : $wm );
	$png= ( empty( $png ) ? false : $png );
	$filter= ( empty( $filter ) ? -1 : $filter );
	$refresh= ( empty( $r ) ? false : true );
	$slash= ( substr( $img, 0, 1 ) != "/" ? true : false );
	$root= rtrim( MODX_BASE_PATH, "/\\\\" ) . ( $slash ? \'/\' : \'\' );
	$img= trim( $img );

	$quality= intval( $quality );
	$quality= ( empty( $quality ) || $quality < 0 || $quality > 100 ? 100 : $quality );

	$ellipse= ( $ellipse == \'max\' ? \'max\' : intval( $ellipse ) );
	if( $dopimg ) $dopimg= $root . ( $slash ? \'\' : \'/\' ) . urldecode( $dopimg );
	
	$toimg= urldecode( trim( $toimg ) );
	if( $toimg )
	{
		if( substr( $toimg, 0, 1 ) == "/" && $slash ) $toimg= substr( $toimg, 1 );
		if( substr( $toimg, 0, 1 ) != "/" && ! $slash ) $toimg= "/". $toimg;
	}
	
	$ipathnotphoto= ( $slash ? \'\' : \'/\' ) . \'template/images/notphoto.png\';
	$ipathwatermark= ( $slash ? \'\' : \'/\' ) . \'template/images/watermark_2.png\'; // ТОЛЬКО .PNG
	
	if( ! file_exists( $root . $img ) || ! is_file( $root . $img ) )
	{
		$img= $ipathnotphoto;
		if( $fill ){ $fill= false; $backgr= true; $rgba= \'1:1\'; }
	}
	if( ! file_exists( $root . $img ) || ! is_file( $root . $img ) ) return false;
	if( $wm && ( ! file_exists( $root . $ipathwatermark ) || ! is_file( $root . $ipathwatermark ) ) )
	{
		$wm= false;
		$img= $ipathnotphoto;
	}

	if( ! $toimg )
	{
		$imgrassh= explode( ".", $img );
		$imgrassh= $imgrassh[ count( $imgrassh )-1 ];
		$newimg= \'_th\'. md5( $img . $w . $h . $backgr . $fill . $x . $y . $rgba . $wm . $filter . $ellipse . $dopimg . $quality ) . ( $png ? \'.png\' : \'.\'. $imgrassh );
		
		$imgarr= explode( "/", $img );
		unset( $imgarr[ count( $imgarr )-1 ] );
		foreach( $imgarr AS $val )
		{
			$newimg_dir .= $val ."/";
		}
		$newimg_dir .= \'.th/\';
		if( ! file_exists( $root . $newimg_dir ) )
			@mkdir( $root . $newimg_dir, 0777 );
		
		$newimg_path= $root . $newimg_dir . $newimg;
		$newimg_path_return= ( $fullpath ? MODX_SITE_URL : \'\' ) . $newimg_dir . $newimg;
		
	}else{
		$newimg_path= $toimg;
		$newimg_path_return= ( $fullpath ? MODX_SITE_URL : \'\' ) . $toimg;
	}
	
	if( ! file_exists( $newimg_path ) || filemtime( $root . $img ) > filemtime( $newimg_path ) ) $refresh= true;
	if( filesize( $root . $img ) > 1024*1024*10 ) return $img;
// ======================================================

	if( $refresh )
	{
		$img1_info= @getimagesize( $root . $img );
		if( ! $img1_info[ 1 ] ) return false;
		$ot= $img1_info[ 0 ] / $img1_info[ 1 ];
		$dstW= ( $w > 0 ? $w : $img1_info[ 0 ] );
		$dstH= ( $h > 0 ? $h : $img1_info[ 1 ] );
		$dstX= 0;
		$dstY= 0;
		$srcW= $img1_info[ 0 ];
		$srcH= $img1_info[ 1 ];
		$srcX= 0;
		$srcY= 0;
		if( $fill )
		{
			$srcW= $img1_info[ 0 ];
			$srcH= round( $img1_info[ 0 ] / ( $dstW / $dstH ) );
			if( $srcH > $img1_info[ 1 ] )
			{
				$srcW= round( $img1_info[ 1 ] / ( $dstH / $dstW ) );
				$srcH= $img1_info[ 1 ];
			}
			if( $x == \'center\' ) $srcX= round( ( $img1_info[ 0 ] - $srcW ) / 2 );
			if( $x == \'right\' ) $srcX= $img1_info[ 0 ] - $srcW;
			if( $y == \'center\' ) $srcY= round( ( $img1_info[ 1 ] - $srcH ) / 2 );
			if( $y == \'bottom\' ) $srcY= $img1_info[ 1 ] - $srcH;
		}else{
			if( ( $img1_info[ 0 ] > $w && $w > 0 ) || ( $img1_info[ 1 ] > $h && $h > 0 ) )
			{
				$dstH= round( $dstW / $ot );
				
				if( $dstH > $h && $h > 0 )
				{
					$dstH= $h;
					$dstW= round( $dstH * $ot );
				}
			}else{
				$dstW= $img1_info[ 0 ];
				$dstH= $img1_info[ 1 ];
			}
			if( $backgr )
			{
				if( $dstW < $w )
				{
					if( $x == \'center\' ) $dstX= round( ( $w - $dstW ) / 2 );
					if( $x == \'right\' ) $dstX= $w - $dstW;
				}
				if( $dstH < $h )
				{
					if( $y == \'center\' ) $dstY= round( ( $h - $dstH ) / 2 );
					if( $y == \'bottom\' ) $dstY= $h - $dstH;
				}
			}
		}
		$crW= ( $backgr && $w > 0 ? $w : $dstW );
		$crH= ( $backgr && $h > 0 ? $h : $dstH );
		if( strstr( $rgba, "," ) )
		{
			$rgba_arr= explode( ",", $rgba );
			for( $kk=0; $kk<=3; $kk++ )
			{
				$rgba_arr[ $kk ]= intval( $rgba_arr[ $kk ] );
				if( $kk <= 2 && ( $rgba_arr[ $kk ] < 0 || $rgba_arr[ $kk ] > 255 ) ) $rgba_arr[ $kk ]= 255;
				if( $kk == 3 && ( $rgba_arr[ $kk ] < 0 || $rgba_arr[ $kk ] > 127 ) ) $rgba_arr[ $kk ]= 127;
			}
			$rgba= \'rgba\';
		}else{
			$coord_arr= explode( ":", $rgba );
			$rgba= \'coord\';
		}
//========================================================================================
		
		if( $img1_info[ 2 ] == 1 ) $img1= @imagecreatefromgif( $root . $img );
			
		elseif( $img1_info[ 2 ] == 2 ) $img1= @imagecreatefromjpeg( $root . $img );
			
		elseif( $img1_info[ 2 ] == 3 ){
			$img1= @imagecreatefrompng( $root . $img );
			$png= true;
		}
		
		if( $rgba == \'coord\' )
		{
			$col= imagecolorat( $img1, $coord_arr[ 0 ], $coord_arr[ 1 ] );
			$rgba= imagecolorsforindex( $img1, $col );
			$rgba_arr[ 0 ]= $rgba[ \'red\' ];
			$rgba_arr[ 1 ]= $rgba[ \'green\' ];
			$rgba_arr[ 2 ]= $rgba[ \'blue\' ];
			$rgba_arr[ 3 ]= $rgba[ \'alpha\' ];
		}
		
		$img2= @ImageCreateTrueColor( $crW, $crH );
		
		if( $png )
		{
			@imagealphablending( $img2, true );
			@imagesavealpha( $img2, true );
			$col= @imagecolorallocatealpha( $img2, $rgba_arr[ 0 ], $rgba_arr[ 1 ], $rgba_arr[ 2 ], $rgba_arr[ 3 ] );
		}else{
			$col= @imagecolorallocate( $img2, $rgba_arr[ 0 ], $rgba_arr[ 1 ], $rgba_arr[ 2 ] );
		}
		
		@imagefill( $img2, 0,0, $col );
		@imagecopyresampled( $img2, $img1, $dstX, $dstY, $srcX, $srcY, $dstW, $dstH, $srcW, $srcH );
		
		if( $wm )
		{
			$wm_info= @getimagesize( $root . $ipathwatermark );
			$img3= @imagecreatefrompng( $root . $ipathwatermark );
			$wm_ot= $wm_info[ 0 ] / $wm_info[ 1 ];
			$wmW= $wm_info[ 0 ];
			$wmH= $wm_info[ 1 ];
			if( $crW < $wm_info[ 0 ] )
			{
				$wmW= $crW - round( $crW / 30 );
				$wmH= round( $wmW / $wm_ot );
			}
			if( $crH < $wmH )
			{
				$wmH= $crH - round( $crH / 30 );
				$wmW= round( $wmH * $wm_ot );
			}
			$wmX= round( ( $crW - $wmW ) / 2 );
			$wmY= round( ( $crH - $wmH ) / 2 );
			@imagecopyresampled( $img2, $img3, $wmX, $wmY, 0, 0, $wmW, $wmH, $wm_info[ 0 ], $wm_info[ 1 ] );
			@imagedestroy( $img3 );
		}
		
		$filter= explode( \'|\', $filter );
		if( ! empty( $filter ) )
		{
			foreach( $filter AS $row )
			{
				$tmp= explode( \';\', $row );
				if( $tmp[ 0 ] == 2 || $tmp[ 0 ] == 3 || $tmp[ 0 ] == 10 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ] );
				elseif( $tmp[ 0 ] == 4 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ], $tmp[ 3 ], $tmp[ 4 ] );
				elseif( $tmp[ 0 ] == 11 ) imagefilter( $img2, $tmp[ 0 ], $tmp[ 1 ], $tmp[ 2 ] );
				else imagefilter( $img2, $tmp[ 0 ] );
			}
		}
		
		if( $ellipse )
		{
			$degstep= ( $degstep ? intval( $degstep ) : 5 );
			$w= ( $crW > $crH ? $crH : $crW );
			$cntr= ($w/2);
			$coord= array();
			$opacitycolor= imagecolorallocatealpha( $img2, 255, 255, 255, 127 );
			if( $ellipse == \'max\' ) $ellipse_r= $cntr-1; else $ellipse_r= $ellipse;
			for( $part=1; $part<=4; $part++ )
			{
				for( $deg=0; $deg<90; $deg+=$degstep )
				{
					$mydeg= $deg;
					if( $part == 2 || $part == 4 ) $mydeg= 90 - $deg;
					if( ! $coord[ $mydeg ][ \'x\' ] ) $coord[ $mydeg ][ \'x\' ]= round( $ellipse_r * cos( deg2rad( $mydeg ) ) );
					if( ! $coord[ $mydeg ][ \'y\' ] ) $coord[ $mydeg ][ \'y\' ]= round( $ellipse_r * sin( deg2rad( $mydeg ) ) );
					$x= $coord[ $mydeg ][ \'x\' ];
					$y= $coord[ $mydeg ][ \'y\' ];
					if( $part == 4 ){ $y *= -1; }
					if( $part == 3 ){ $x *= -1; $y *= -1; }
					if( $part == 2 ){ $x *= -1; }
					$points[]= $cntr + $x;
					$points[]= $cntr + $y;
				}
			}
			$points[]= $cntr + $ellipse_r; $points[]= $cntr;
			$points[]= $w; $points[]= $cntr;
			$points[]= $w; $points[]= $w;
			$points[]= 0; $points[]= $w;
			$points[]= 0; $points[]= 0;
			$points[]= $w; $points[]= 0;
			$points[]= $w; $points[]= $cntr;
			$png= true;
			imagealphablending( $img2, false );
			imagesavealpha( $img2, true );
			imagefilledpolygon( $img2, $points, count($points)/2, $opacitycolor );
			//$autrum= imagecolorallocate( $img2, 216, 181, 85 );
			//imageellipse( $img2, $cntr, $cntr, $ellipse_r*2, $ellipse_r*2, $autrum );
		}
		
		if( $dopimg )
		{
			if( $dopimg_xy )
			{
				$dopimg_xy= explode( ":", $dopimg_xy );	
			}
			imagealphablending( $img2, true );
			imagesavealpha( $img2, true );
			$dopimg_info= @getimagesize( $dopimg );
			$img3= @imagecreatefrompng( $dopimg );
			$diX= round( ( $crW - $dopimg_info[ 0 ] ) / 2 ) + ( $dopimg_xy[ 0 ] ? intval( $dopimg_xy[ 0 ] ) : 0 );
			$diY= round( ( $crH - $dopimg_info[ 1 ] ) / 2 ) + ( $dopimg_xy[ 1 ] ? intval( $dopimg_xy[ 1 ] ) : 0 );
			@imagecopyresampled( $img2, $img3, $diX, $diY, 0, 0, $dopimg_info[ 0 ], $dopimg_info[ 1 ], $dopimg_info[ 0 ], $dopimg_info[ 1 ] );
			@imagedestroy( $img3 );
		}
		
		if( $png ){
			@imagepng( $img2, $newimg_path );
		}elseif( $img1_info[ 2 ] == 1 ){
			@imagegif( $img2, $newimg_path, $quality );
		}elseif( $img1_info[ 2 ] == 2 ){
			@imagejpeg( $img2, $newimg_path, $quality );
		}
		@chmod( $newimg_path, 0777 );
		@imagedestroy( $img1 );
		@imagedestroy( $img2 );
	}

	return $newimg_path_return;
';
$s['_LK_'] = '
//v05
//==================================================================================
$lk= 106;
$reg= 107;
$auth= 108;
$restorepassword= 109;
$agreed= 110;
$DMTCaptcha= 111;
$DMTCaptcha_img= 112;
//==================================================================================

$topage= ( $topage ? intval( $topage ) : $modx->documentIdentifier );
$topage_url= $modx->makeUrl( $topage );



';
$s['str_replace'] = '
return str_replace( $from, $to, $txt );
';
$s['ExchangeRates'] = '
//v01
//=============================================================
	
$file= MODX_BASE_PATH .\'mybox/ExchangeRates.txt\';

$currency_num= array(
	\'eur\' => 2,
	\'usd\' => 3,
);

$c= $currency_num[ $c ];

$currency= array(
	2 => array( 40, \'R01239\', 978 ),
	3 => array( 30, \'R01235\', 840 ),
);

//$_SESSION[ \'ExchangeRates\' ]= array();

if( ! $_SESSION[ \'ExchangeRates\' ][ 2 ] || ! $_SESSION[ \'ExchangeRates\' ][ 3 ] || ! $_SESSION[ \'ExchangeRates\' ][ 0 ] || time() - $_SESSION[ \'ExchangeRates\' ][ 1 ] >= 60*60*24 )
{
	$currency_from_file= array();
	if( file_exists( $file ) )
	{
		$fp= fopen( $file, \'r\' );
		if( $fp )
		{
			while( ! feof( $fp ) )
			{ 
				$currency_from_file[]= fgets( $fp ); 
			}
			fclose( $fp ); 
		}
	}
	if( ! $currency_from_file[ 0 ] || time() - $currency_from_file[ 1 ] >= 60*60*24 )
	{
		$info= @simplexml_load_file( \'http://cbr.ru/scripts/XML_daily.asp\' ); //http://cbr.ru/scripts/XML_daily.asp?date_req=23/02/2016\'
		if( $info )
		{
			foreach( $info->{Valute} AS $row )
			{
				foreach( $currency AS $key2 => $row2 )
				{
					if( $row[ \'ID\' ] == $row2[ 1 ] )
					{
						$val= $row->{Value};
						$val= str_replace( ",", ".", $val );
						$val= round( $val, 2 );
						$currency[ $key2 ][ 0 ]= $val;
						$currency[ $key2 ][ 3 ]= $row->{CharCode};
						$currency[ $key2 ][ 4 ]= $row->{Name};
					}
				}
			}
		}
		
		$fp= fopen( $file, \'w\' );
		if( $fp )
		{
			$tmp= time() ."\\n";
			$tmp .= mktime( 0,0,0, date( \'m\' ), date( \'d\' ), date( \'Y\' ) ) ."\\n";
			$tmp .= $currency[ 2 ][ 0 ] ."\\n";
			$tmp .= $currency[ 3 ][ 0 ];
			fwrite( $fp, $tmp );
			fclose( $fp );	
		}
		
	}else{
		$currency[ 2 ][ 0 ]= $currency_from_file[ 1 ];
		$currency[ 3 ][ 0 ]= $currency_from_file[ 2 ];
		foreach( $currency AS $key2 => $row2 )
		{
			$currency[ $key2 ][ 0 ]= $currency_from_file[ $key2 ];
		}
	}
	$_SESSION[ \'ExchangeRates\' ][ 0 ]= time();
	$_SESSION[ \'ExchangeRates\' ][ 1 ]= mktime( 0,0,0, date( \'m\' ), date( \'d\' ), date( \'Y\' ) );
	foreach( $currency AS $key2 => $row2 )
	{
		$_SESSION[ \'ExchangeRates\' ][ $key2 ]= $row2[ 0 ];
	}
}
//print_r( $_SESSION[ \'ExchangeRates\' ] );
return $_SESSION[ \'ExchangeRates\' ][ $c ];
';
$s['ExchangeRates_Price'] = '
//v01
//=============================================================
if( $c == \'rub\' ) return $price;
$rate= $modx->runSnippet( \'ExchangeRates\', array( \'c\' => $c ) );
$price= str_replace( ",", ".", $price );
$rate= str_replace( ",", ".", $rate );
return round( $price * $rate );
';
$s['ExchangeRates_Info'] = '
//v01
//============================================================
$usd= $modx->runSnippet( \'ExchangeRates\', array( \'c\'=>\'usd\' ) );
$eur= $modx->runSnippet( \'ExchangeRates\', array( \'c\'=>\'eur\' ) );

return \'<div class="exchange_rates">Курс ЦБ &nbsp;|&nbsp; USD <span class="usd">\'. $usd .\'</span> &nbsp;|&nbsp; EUR <span class="eur">\'. $eur .\'</span></div>\';
';
$s['_LK_Restore_Password'] = '
//v05
//==================================================================================
$lk= 106;
$reg= 107;
$auth= 108;
$restorepassword= 109;
$agreed= 110;
$DMTCaptcha= 111;
$DMTCaptcha_img= 112;
//==================================================================================

$sc_site= \'profzapas.ru\';
$mailto= \'korneva.ola@gmail.com\';
$mailto_bcc= false;
$mailto= \'sergey.it7@gmail.com\';
$mailfrom= \'profzapas-noreply@yandex.ru\';
$mailtype= \'smtp\';
$mailpassw= \'m_y642onB5pr\';
//Любимый киногерой: mWdqjMJ28geu_lSJZ7_0
$smtp= \'smtp.yandex.ru\';
$smtpport= 465;
include_once( MODX_MANAGER_PATH .\'includes/controls/class.phpmailer.php\' );
//SNIPPET _LK_Restore_Password, SNIPPET _LK_Reg
//===============================================================================
//===============================================================================

$topage= ( $topage ? intval( $topage ) : $modx->documentIdentifier );
$topage_url= $modx->makeUrl( $topage );

// =======================================================================================================


$etap= intval( $etap ); if( ! $etap ) $etap= 1;

if( isset( $_GET[ \'e1ok\' ] ) ) $etap= 2;

if( isset( $_GET[ \'u\' ] ) && isset( $_GET[ \'s\' ] ) ) $etap= 3;

srand( time() );


if( isset( $_POST[ \'restp_restp\' ] ) )
{
	$restp_email= addslashes( trim( $_POST[ \'restp_email\' ] ) );
	$restp_mobile= addslashes( trim( $_POST[ \'restp_mobile\' ] ) );
	
	if( $_POST[ \'reg_captcha\' ] != $_SESSION[ \'DMTCaptcha\' ] )
	{
		$restp_err .= \'<p>- Введено неверное число с картинки</p>\';
		
	}else{
		if( empty( $restp_email ) || empty( $restp_mobile ) )
		{
			$restp_err .= \'<p>- Необходимо заполнить все поля формы.</p>\';
		}
	}
	
	if( empty( $restp_err ) )
	{
		$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'_user\' )." WHERE email=\'{$restp_email}\' AND mobile=\'{$restp_mobile}\' LIMIT 1" );
		if( $rr && mysql_num_rows( $rr ) == 1 )
		{
			$password_new= $modx->runSnippet( \'GenerPassword\' );
			$password_new_md5= md5( $password_new );
			
			$secret= md5( $password_new . rand( 100,999 ) . $restp_email . time() . mysql_result( $rr, 0, \'dt\' ) );
			
			$secret_link= $modx->makeUrl( $restorepassword, \'\', \'\', \'full\' ) .\'?u=\'. mysql_result( $rr, 0, \'id\' ) .\'&s=\'. $secret;
			
			mysql_query( "UPDATE ".$modx->getFullTableName( \'_user\' )." SET password_new=\'{$password_new_md5}\', password_dt=\'". time() ."\', secret=\'{$secret}\' WHERE email=\'{$restp_email}\' LIMIT 1" );
			
			$subject= "Активация нового пароля на сайте www.". $sc_site;
			
			$emailtext= \'<html>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<title>\'. $subject .\'</title>
		</head>
		<body>
			<h2>\'. $subject .\'</h2>
			<p>Через форму на сайте было запрошено восстановление доступа к Вашему личному кабинету.</p>
			<p>Новый пароль: <b>\'. $password_new .\'</b></p>
			<p>— пароль не активирован и не действителен!</p>
			<p>Чтобы активиривать новый пароль, перейдите по ссылке или скопируйте ее в адресную строку браузера:<br />
			<a target="_blank" href="\'. $secret_link .\'">\'. $secret_link .\'</a></p>
			<p>Если вы не запрашивали восстановление доступа, просто проигнорируйте это письмо.</p>
		</body>
	</html>\';
			
// ============================================================================
					if( $mailtype == \'smtp\' || $mailtype == \'mail\' )
					{
						$phpmailer= new PHPMailer();
						if( false )
						{
							$phpmailer->SMTPDebug= 2;
							$phpmailer->Debugoutput = \'html\';
						}
						if( $mailtype == \'smtp\' )
						{
							$phpmailer->isSMTP();
							$phpmailer->Host= $smtp;
							$phpmailer->Port= $smtpport;
							$phpmailer->SMTPAuth= true;
							$phpmailer->SMTPSecure= \'ssl\';
							$phpmailer->Username= $mailfrom;
							$phpmailer->Password= $mailpassw;
						}
						$phpmailer->CharSet= \'utf-8\';
						$phpmailer->From= $mailfrom;
						$phpmailer->FromName= "";
						if( $mailto_bcc ) $phpmailer->addBCC( $mailto_bcc );
						$phpmailer->isHTML( true );
						$phpmailer->Subject= $subject;
						$phpmailer->Body= $emailtext;
						$phpmailer->addAddress( $restp_email );
						$phpmailer->send();
					}else{
						$mailto= "<". $restp_email .">";
						$headers= "Content-type: text/html; charset=utf-8\\n";
						$headers .= "From: <". $mailfrom .">\\n";
						mail( $mailto, $subject, $emailtext, $headers );
					}
// ============================================================================
			
			header( \'location: \'. $topage_url .\'?e1ok\' );
			exit();
			
		}elseif( $rr ){
			$restp_err .= \'<p>- Пользователь не найден!</p>\';
		}else{
			$restp_err .= \'<p>- Ошибка базы данных (001)</p>\';
		}
	}
}

if( $etap == 1 )
{
?>
<div class="_LK_wrapper">
	<div class="_LK_form _LK_form_restp">
		<div class="_LK_form_tit">Восстановление доступа</div>
		
		<?php if( ! empty( $restp_err ) ) print \'<div class="_LK_error">\'. $restp_err .\'</div>\'; ?>
		
		<form id="form" action="<?= $topage_url ?>" method="post">
			<div class="_LK_form_txt">На указанные адрес электронной почты и номер мобильного телефона<br />будут высланы новые данные доступа к личному кабинету.</div>
			
			<div class="_LK_form_line">
				<div class="_LK_form_lbl">Адрес электронной почты</div>
				<div class="_LK_form_inp"><input type="text" name="restp_email" /></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<div class="_LK_form_line">
				<div class="_LK_form_lbl">Номер мобильного телефона</div>
				<div class="_LK_form_inp"><input class="input_mask_mobile" type="text" name="restp_mobile" /></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<script type="text/javascript">
				$( document ).ready(function(){
					$( \'.DMTCaptcha_refr\' ).click(function(){
						$( \'.DMTCaptcha_img\' ).html( \'<img src="template/images/loading1.gif" />\' );
						$( \'.DMTCaptcha_img\' ).load( \'<?= $modx->makeUrl( $DMTCaptcha_img ) ?>\' );
					});
				});
			</script>
			<div class="_LK_form_line">
				<div class="_LK_form_lbl"><div class="DMTCaptcha_img"><img src="[~<?= $DMTCaptcha ?>~]" /></div><div class="DMTCaptcha_refr"><span class="as2">Изменить число</span></div></div>
				<div class="_LK_form_inp"><div style="padding:10px 0px 7px;">Введите число с картинки</div><input type="text" name="reg_captcha" /></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<div class="_LK_form_line _LK_form_line_butt">
				<div class="_LK_form_lbl"> </div>
				<div class="_LK_form_inp"><button class="buttonsubmit" name="restp_restp" type="submit">Продолжить</button></div>
				<div class="clr">&nbsp;</div>
			</div>
		</form>
	</div>
</div>
<?php
}

if( $etap == 2 )
{
?>
<div class="_LK_wrapper">
	<div class="_LK_form _LK_form_restp">
		<div class="_LK_form_tit">Восстановление доступа</div>
		
		<div class="_LK_ok">
			<p>На указанные адрес электронной почты и номер мобильного телефона<br />высланы новые данные доступа к личному кабинету.</p>
			<p>Если в течение 10 минут они не придут, <a class="as1" href="[~<?= $restorepassword ?>~]">повторите запрос</a>.</p>
		</div>
	</div>
</div>
<?php
}

if( $etap == 3 )
{
	$userid= intval( $_GET[ \'u\' ] );
	$secret= addslashes( $_GET[ \'s\' ] );
	
	$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'_user\' )." WHERE id={$userid} AND secret=\'{$secret}\' AND password_new<>\'\' AND password_dt>0 LIMIT 1" );
	if( $rr && mysql_num_rows( $rr ) == 1 )
	{
		if( time() - mysql_result( $rr, 0, \'password_dt\' ) < 60*60*24 )
		{
			mysql_query( "UPDATE ".$modx->getFullTableName( \'_user\' )."
				SET password=\'". mysql_result( $rr, 0, \'password_new\' ) ."\', password_new=\'\', secret=\'\', password_dt=\'\' WHERE id={$userid} LIMIT 1" );
			
			$result= \'<div class="_LK_ok"><p>Новый пароль успешно <b>активирован!</b></p><p><a class="as2" href="\'. $modx->makeUrl( $auth ) .\'">Вход в систему</a></p></div>\';
			
		}else{
			$result= \'<div class="_LK_error"><p>Срок действия ссылки на активацию нового пароля истек!</p><p>Запросите <a class="as2" href="\'. $modx->makeUrl( $restorepassword ) .\'">восстановление еще раз</a>.</p></div>\';
		}
		
	}elseif( $rr ){
		$result= \'<div class="_LK_error"><p>Неверные данные!</p></div>\';
		
	}else{
		$result= \'<div class="_LK_error"><p>Ошибка базы данных (002)</p></div>\';
	}
?>
<div class="_LK_wrapper">
	<div class="_LK_form _LK_form_restp">
		<div class="_LK_form_tit">Восстановление доступа</div>
		
		<?= $result ?>
	</div>
</div>
<?php
}
?>
';
$s['_LK_Reg'] = '
//v05
//==================================================================================
$lk= 106;
$reg= 107;
$auth= 108;
$restorepassword= 109;
$agreed= 110;
$DMTCaptcha= 111;
$DMTCaptcha_img= 112;
//==================================================================================

$sc_site= \'profzapas.ru\';
$mailto= \'korneva.ola@gmail.com\';
$mailto_bcc= false;
$mailto= \'sergey.it7@gmail.com\';
$mailfrom= \'profzapas-noreply@yandex.ru\';
$mailtype= \'smtp\';
$mailpassw= \'m_y642onB5pr\';
//Любимый киногерой: mWdqjMJ28geu_lSJZ7_0
$smtp= \'smtp.yandex.ru\';
$smtpport= 465;
include_once( MODX_MANAGER_PATH .\'includes/controls/class.phpmailer.php\' );
//SNIPPET _LK_Restore_Password, SNIPPET _LK_Reg
//===============================================================================
//===============================================================================

$topage= ( $topage ? intval( $topage ) : $modx->documentIdentifier );
$topage_url= $modx->makeUrl( $topage );

if( $_SESSION[ \'webuserinfo\' ][ \'auth\' ] )
{
	header( \'location: \'. $modx->makeUrl( $lk ) );
	exit();
}

// =======================================================================================================


if( isset( $_POST[ \'reg_reg\' ] ) && ! $_SESSION[ \'webuserinfo\' ][ \'auth\' ] )
{
	$reg_email= addslashes( trim( $_POST[ \'reg_email\' ] ) );
	$reg_mobile= addslashes( trim( $_POST[ \'reg_mobile\' ] ) );
	$reg_agreed= ( $_POST[ \'reg_agreed\' ] == \'y\' ? \'y\' : \'n\' );
	
	if( $_POST[ \'reg_captcha\' ] != $_SESSION[ \'DMTCaptcha\' ] )
	{
		$reg_err .= \'<p>- Введено неверное число с картинки</p>\';
		$reg_err_flag[ \'reg_captcha\' ]= true;
		
	}else{
		if( $reg_agreed != \'y\' )
		{
			$reg_err .= \'<p>- Необходимо принять <a class="as1" target="_blank" href="[~\'. $agreed .\'~]">условия пользовательского соглашения</a></p>\';
		}
		if( ! preg_match( "/^[a-z0-9-_\\.]{1,}@[a-z0-9-\\.]{1,}\\.[a-z]{2,10}$/i", $reg_email ) )
		{
			$reg_err .= \'<p>- Адрес электронной почты неверного формата</p>\';
			$reg_err_flag[ \'reg_email\' ]= true;
		}
		if( ! preg_match( "/^\\+7 [0-9]{3} [0-9]{3}-[0-9]{4}$/i", $reg_mobile ) )
		{
			$reg_err .= \'<p>- Номер мобильного телефона неверного формата</p>\';
			$reg_err_flag[ \'reg_mobile\' ]= true;
		}
	}
	if( empty( $reg_err ) )
	{
		$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'_user\' )." WHERE email=\'{$reg_email}\' LIMIT 1" );
		if( $rr && mysql_num_rows( $rr ) == 1 )
		{
			$reg_err .= \'<p>- Этот Адрес электронной почты уже зарегистрирован</p>\';
			$reg_err_flag[ \'reg_email\' ]= true;
		}
		
		$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'_user\' )." WHERE mobile=\'{$reg_mobile}\' LIMIT 1" );
		if( $rr && mysql_num_rows( $rr ) == 1 )
		{
			$reg_err .= \'<p>- Этот Номер мобильного телефона уже зарегистрирован</p>\';
			$reg_err_flag[ \'reg_mobile\' ]= true;
		}
		
		if( ! $reg_err )
		{
			$password_new= $modx->runSnippet( \'GenerPassword\' );
			$password_new_md5= md5( $password_new );
			
			$rrr= mysql_query( "INSERT INTO ".$modx->getFullTableName( \'_user\' )." SET email=\'{$reg_email}\', mobile=\'{$reg_mobile}\', password=\'{$password_new_md5}\', dt=\'".time()."\'" );
			if( $rrr )
			{
				$subject= "Регистрация на сайте www.". $sc_site;
				
				$emailtext= \'<html>
			<head>
				<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
				<title>\'. $subject .\'</title>
			</head>
			<body>
				<h2>\'. $subject .\'</h2>
				<p>Логин: \'. $reg_email .\'</p>
				<p>Пароль: <b>\'. $password_new .\'</b></p>
			</body>
		</html>\';
			
// ============================================================================
					if( $mailtype == \'smtp\' || $mailtype == \'mail\' )
					{
						$phpmailer= new PHPMailer();
						if( false )
						{
							$phpmailer->SMTPDebug= 2;
							$phpmailer->Debugoutput = \'html\';
						}
						if( $mailtype == \'smtp\' )
						{
							$phpmailer->isSMTP();
							$phpmailer->Host= $smtp;
							$phpmailer->Port= $smtpport;
							$phpmailer->SMTPAuth= true;
							$phpmailer->SMTPSecure= \'ssl\';
							$phpmailer->Username= $mailfrom;
							$phpmailer->Password= $mailpassw;
						}
						$phpmailer->CharSet= \'utf-8\';
						$phpmailer->From= $mailfrom;
						$phpmailer->FromName= "";
						if( $mailto_bcc ) $phpmailer->addBCC( $mailto_bcc );
						$phpmailer->isHTML( true );
						$phpmailer->Subject= $subject;
						$phpmailer->Body= $emailtext;
						$phpmailer->addAddress( $reg_email );
						$phpmailer->send();
					}else{
						$mailto= "<". $reg_email .">";
						$headers= "Content-type: text/html; charset=utf-8\\n";
						$headers .= "From: <". $mailfrom .">\\n";
						mail( $mailto, $subject, $emailtext, $headers );
					}
// ============================================================================
			
				header( \'location: \'. $topage_url .\'?ok\' );
				exit();
				
			}else{
				$reg_err .= \'<p>- Ошибка базы данных (002)</p>\';
			}
		}
	}
}

?>
<div class="_LK_wrapper">
	<div class="_LK_form _LK_form_reg _LK_form_left">
		<div class="_LK_form_tit">Регистрация</div>
		
		<?php if( isset( $_GET[ \'ok\' ] ) ){ ?>
		<div class="_LK_ok">
			<p><b>Вы успешно зарегистрированы на сайте!</b></p>
			<p>На указанные адрес электронной почты и номер мобильного телефона высланы данные доступа к личному кабинету.</p>
			<p>Если в течение 10 минут они не придут,<br />воспользуйтесь <a class="as1" href="[~<?= $restorepassword ?>~]">этой формой</a>.</p>
		</div>
		<?php }else{ ?>
		<?php if( ! empty( $reg_err ) ) print \'<div class="_LK_error">\'. $reg_err .\'</div>\'; ?>
		
		<form action="<?= $topage_url ?>" method="post">
			<div class="_LK_form_line">
				<div class="_LK_form_lbl">Адрес электронной почты</div>
				<div class="_LK_form_inp <?= ( $reg_err_flag[ \'reg_email\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="reg_email" value="<?= $reg_email ?>" /></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<div class="_LK_form_line _LK_form_line_br">
				<div class="_LK_form_lbl">Номер мобильного телефона</div>
				<div class="_LK_form_inp <?= ( $reg_err_flag[ \'reg_mobile\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input class="input_mask_mobile" type="text" name="reg_mobile" value="<?= $reg_mobile ?>" /></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<script type="text/javascript">
				$( document ).ready(function(){
					$( \'.DMTCaptcha_refr\' ).click(function(){
						$( \'.DMTCaptcha_img\' ).html( \'<img src="template/images/loading1.gif" />\' );
						$( \'.DMTCaptcha_img\' ).load( \'<?= $modx->makeUrl( $DMTCaptcha_img ) ?>\' );
					});
				});
			</script>
			<div class="_LK_form_line">
				<div class="_LK_form_lbl"><div class="DMTCaptcha_img"><img src="[~<?= $DMTCaptcha ?>~]" /></div><div class="DMTCaptcha_refr"><span class="as2">Изменить число</span></div></div>
				<div class="_LK_form_inp <?= ( $reg_err_flag[ \'reg_captcha\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><div style="padding:10px 0px 7px;">Введите число с картинки</div><input type="text" name="reg_captcha" /></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<div class="_LK_form_line">
				<div class="_LK_form_lbl"><input type="checkbox" name="reg_agreed" value="y"></div>
				<div class="_LK_form_inp">Я принимаю <a class="as1" target="_blank" href="[~<?= $agreed ?>~]">условия пользовательского соглашения</a></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<div class="_LK_form_line _LK_form_line_butt">
				<div class="_LK_form_lbl"> </div>
				<div class="_LK_form_inp"><button class="buttonsubmit" name="reg_reg" type="submit">Зарегистрироваться</button></div>
				<div class="clr">&nbsp;</div>
			</div>
		</form>
		<?php } ?>
	</div>
	
	<div class="_LK_form _LK_form_info _LK_form_right">
		<div class="_LK_form_tit">Преимущества регистрации</div>
		
		<p>Зарегистрированные пользователи получают следующие дополнительные возможности:</p>
		<ul>
			<li>участие в аукционах;</li>
			<li>добавление товара в избранное;</li>
			<li>прямое общение с администрацией портала;</li>
			<li>отправка притензий;</li>
		</ul>
		
		<p><a class="as1" href="[~<?= $auth ?>~]">Вход для зарегистрированных пользователей</a></p>
	</div>
	
	<div class="clr">&nbsp;</div>
</div>
<?php
mysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'_user\' )." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(127) NOT NULL,
  `surname` varchar(127) NOT NULL,
  `email` varchar(127) NOT NULL,
  `mobile` varchar(63) NOT NULL,
  `passport` varchar(31) NOT NULL,
  `passport_dth` varchar(15) NOT NULL,
  `passport_who` varchar(255) NOT NULL,
  `passport_address` varchar(255) NOT NULL,
  `urlico` set(\'n\',\'test\',\'y\') NOT NULL DEFAULT \'n\',
  `company` varchar(127) NOT NULL,
  `maincity` varchar(63) NOT NULL,
  `address_ur` varchar(255) NOT NULL,
  `address_ft` varchar(255) NOT NULL,
  `inn` varchar(31) NOT NULL,
  `kpp` varchar(31) NOT NULL,
  `bik` varchar(31) NOT NULL,
  `ogrn` varchar(31) NOT NULL,
  `bank` varchar(127) NOT NULL,
  `rschet` varchar(31) NOT NULL,
  `kschet` varchar(31) NOT NULL,
  `enabled` set(\'y\',\'n\') NOT NULL DEFAULT \'y\',
  `dt` bigint(20) NOT NULL,
  `dt_edit` bigint(20) NOT NULL,
  `password` varchar(63) NOT NULL,
  `password_new` varchar(63) NOT NULL,
  `password_dt` bigint(20) NOT NULL,
  `secret` varchar(63) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;" );
mysql_query( "CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'_user_h\' )." (
  `id` int(11) NOT NULL,
  `firstname` varchar(127) NOT NULL,
  `surname` varchar(127) NOT NULL,
  `email` varchar(127) NOT NULL,
  `mobile` varchar(63) NOT NULL,
  `passport` varchar(31) NOT NULL,
  `passport_dth` varchar(15) NOT NULL,
  `passport_who` varchar(255) NOT NULL,
  `passport_address` varchar(255) NOT NULL,
  `urlico` set(\'n\',\'test\',\'y\') NOT NULL DEFAULT \'n\',
  `company` varchar(127) NOT NULL,
  `maincity` varchar(63) NOT NULL,
  `address_ur` varchar(255) NOT NULL,
  `address_ft` varchar(255) NOT NULL,
  `inn` varchar(31) NOT NULL,
  `kpp` varchar(31) NOT NULL,
  `bik` varchar(31) NOT NULL,
  `ogrn` varchar(31) NOT NULL,
  `bank` varchar(127) NOT NULL,
  `rschet` varchar(31) NOT NULL,
  `kschet` varchar(31) NOT NULL,
  `enabled` set(\'y\',\'n\') NOT NULL DEFAULT \'y\',
  `dt` bigint(20) NOT NULL,
  `dt_edit` bigint(20) NOT NULL,
  `password` varchar(63) NOT NULL,
  `password_new` varchar(63) NOT NULL,
  `password_dt` bigint(20) NOT NULL,
  `secret` varchar(63) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;" );
';
$s['_LK_Auth'] = '
//v05
//==================================================================================
$lk= 106;
$reg= 107;
$auth= 108;
$restorepassword= 109;
$agreed= 110;
$DMTCaptcha= 111;
$DMTCaptcha_img= 112;
//==================================================================================

$topage= ( $topage ? intval( $topage ) : $modx->documentIdentifier );
$topage_url= $modx->makeUrl( $topage );

if( $_SESSION[ \'webuserinfo\' ][ \'auth\' ] )
{
	header( \'location: \'. $modx->makeUrl( $lk ) );
	exit();
}

// =======================================================================================================


if( isset( $_POST[ \'auth_auth\' ] ) && ! $_SESSION[ \'webuserinfo\' ][ \'auth\' ] )
{
	$auth_email= addslashes( trim( $_POST[ \'auth_email\' ] ) );
	$auth_passw= md5( $_POST[ \'auth_passw\' ] );
	
	$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'_user\' )." WHERE email=\'{$auth_email}\' AND password=\'{$auth_passw}\' LIMIT 1" );
	if( $rr && mysql_num_rows( $rr ) == 1 )
	{
		$_SESSION[ \'webuserinfo\' ][ \'info\' ]= mysql_fetch_assoc( $rr );
		$_SESSION[ \'webuserinfo\' ][ \'id\' ]= $_SESSION[ \'webuserinfo\' ][ \'info\' ][ \'id\' ];
		$_SESSION[ \'webuserinfo\' ][ \'auth\' ]= true;
		$_SESSION[ \'webuserinfo\' ][ \'login\' ]= time();
		
		header( \'location: \'. $topage_url );
		exit();
		
	}elseif( $rr ){
		$auth_err .= \'<p>- Неверно введены Логин или пароль</p>\';
	}else{
		$auth_err .= \'<p>- Ошибка базы данных (003)</p>\';
	}
}


?>
<div class="_LK_wrapper">
	<div class="_LK_form _LK_form_auth _LK_form_left">
		<div class="_LK_form_tit">Вход в систему</div>
		
		<?php if( ! empty( $auth_err ) ) print \'<div class="_LK_error">\'. $auth_err .\'</div>\'; ?>
		
		<form action="<?= $topage_url ?>" method="post">
			<div class="_LK_form_line">
				<div class="_LK_form_lbl">Адрес электронной почты</div>
				<div class="_LK_form_inp"><input type="text" name="auth_email" value="<?= $auth_email ?>" /></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<div class="_LK_form_line _LK_form_line_br">
				<div class="_LK_form_lbl">Пароль</div>
				<div class="_LK_form_inp"><input type="password" name="auth_passw" /></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<div class="_LK_form_line">
				<div class="_LK_form_lbl"></div>
				<div class="_LK_form_inp"><a class="as2" href="<?= $modx->makeUrl( $restorepassword ) ?>">Забыли пароль?</a></div>
				<div class="clr">&nbsp;</div>
			</div>
			
			<div class="_LK_form_line _LK_form_line_butt">
				<div class="_LK_form_lbl"> </div>
				<div class="_LK_form_inp"><button class="buttonsubmit" name="auth_auth" type="submit">Войти</button></div>
				<div class="clr">&nbsp;</div>
			</div>
		</form>
	</div>
	
	<div class="_LK_form _LK_form_info _LK_form_right">
		<div class="_LK_form_tit">Впервые на нашем портале?</div>
		
		<p>Зарегистрированные пользователи получают следующие дополнительные возможности:</p>
		<ul>
			<li>участие в аукционах;</li>
			<li>добавление товара в избранное;</li>
			<li>прямое общение с администрацией портала;</li>
			<li>отправка притензий;</li>
		</ul>
		
		<p><a class="as1" href="[~<?= $reg ?>~]">Регистрация в системе</a></p>
	</div>
	
	<div class="clr">&nbsp;</div>
</div>
<?php
';
$s['_LK_UserPanel'] = '
//v05
//==================================================================================
$lk= 106;
$reg= 107;
$auth= 108;
$restorepassword= 109;
$agreed= 110;
$DMTCaptcha= 111;
$DMTCaptcha_img= 112;
//==================================================================================
?>
<link rel="stylesheet" type="text/css" href="template/css/lk.css" />
<script type="text/javascript" src="template/js/lk.js"></script>
<script type="text/javascript" src="template/js/jquery-maskedinput.js"></script>
<?php
//==================================================================================
	
$topage= ( $topage ? intval( $topage ) : $modx->documentIdentifier );
$topage_url= $modx->makeUrl( $topage );

if( isset( $_GET[ \'exit\' ] ) && $_SESSION[ \'webuserinfo\' ][ \'auth\' ] )
{
	$_SESSION[ \'webuserinfo\' ]= array();
	header( \'location: \'. $topage_url );
	exit();
}

//==================================================================================


if( $_SESSION[ \'webuserinfo\' ][ \'auth\' ] )
{
	$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( \'_user\' )." WHERE id=". $_SESSION[ \'webuserinfo\' ][ \'id\' ] ." AND enabled=\'y\' LIMIT 1" );
	if( $rr && mysql_num_rows( $rr ) == 1 )
	{
		$_SESSION[ \'webuserinfo\' ][ \'info\' ]= mysql_fetch_assoc( $rr );
	}else{
		$_SESSION[ \'webuserinfo\' ]= array();
		header( \'location: \'. $topage_url );
		exit();
	}
}


$webuserinfo= $_SESSION[ \'webuserinfo\' ][ \'info\' ];


print \'<div class="_LK_topuserpanel">\';
if( $_SESSION[ \'webuserinfo\' ][ \'auth\' ] )
{
	print \'Здравствуйте, \'. $webuserinfo[ \'firstname\' ] .\' \'. $webuserinfo[ \'surname\' ] .\' &nbsp; | &nbsp; <a class="as2" href="[~\'. $lk .\'~]">Личный кабинет</a> &nbsp; | &nbsp; <a class="as2" href="[~[*id*]~]?exit">Выйти</a>\';
}else{
	print \'<a class="as2" href="[~\'. $auth .\'~]">Вход</a> &nbsp; | &nbsp; <a class="as2" href="[~\'. $reg .\'~]">Регистрация</a>\';
}
print \'</div>\';
';
$s['GenerPassword'] = '
//v01
//==============================================================
if( ! $length ) $length= 12;
$simbols= array(
	\'a\',\'b\',\'s\',\'d\',\'e\',\'f\',\'g\',\'h\',\'i\',\'j\',\'k\',\'l\',\'m\',\'n\',\'o\',\'p\',\'q\',\'r\',\'s\',\'t\',\'u\',\'v\',\'w\',\'x\',\'y\',\'z\',
	\'A\',\'B\',\'S\',\'D\',\'E\',\'F\',\'G\',\'H\',\'I\',\'J\',\'K\',\'L\',\'M\',\'N\',\'O\',\'P\',\'Q\',\'R\',\'S\',\'T\',\'U\',\'V\',\'W\',\'X\',\'Y\',\'Z\',
	\'_\',\'_\',\'_\',\'_\',
	\'0\',\'1\',\'2\',\'3\',\'4\',\'5\',\'6\',\'7\',\'8\',\'9\',	\'0\',\'1\',\'2\',\'3\',\'4\',\'5\',\'6\',\'7\',\'8\',\'9\',
);
for( $o= 1; $o <= $length; $o++ )
{
	$rand_tmp= rand( 0, count( $simbols )-1 );
	$simbol_tmp= $simbols[ $rand_tmp ];
	$password .= $simbol_tmp;
}
return $password;
';
$s['DMTCaptcha'] = '
//v01
//====================================================================================
$use_symbols= "12345679abcdefghijhkmntwpuvxyz";
$use_symbols= "2345690";
$use_symbols_len= strlen( $use_symbols );

srand();

$simbol_color= \'random\'; //red, blue, green или random - случайный

if( $simbol_color == \'random\' )
{
	$r= rand( 200, 230 );
	switch( rand( 1, 3 ) )
	{
		case 1: $scolor[ \'random\' ]= array( $r, 0, 0 ); break 1;
		case 2: $scolor[ \'random\' ]= array( 0, $r, 0 ); break 1;
		case 3: $scolor[ \'random\' ]= array( 0, 0, $r ); break 1;
	}
}

$inline= false;

$amplitude_min= 8; // Минимальная амплитуда волны
$amplitude_max= 13; // Максимальная амплитуда волны

$font_width= 26; // Приблизительная ширина символа в пикселях

$font_size_min= 40;
$font_size_max= 60;

$rand_bsimb_min= 0; // Минимальное расстояние между символами (можно отрицательное)
$rand_bsimb_max= 15; // Максимальное расстояние между символами

$rotate_simbol= 0; // Поворачивать случайно каждый символ 1 - д

$margin_left= rand( 10, 50 );// отступ слева
$margin_top= rand( 50, 60 ); // отступ сверху

$font_count= 4;// Количество шрифтов в папке DMT_captcha_fonts идущих по порядку от 1 до $font_count
$jpeg_quality= 100; // Качество картинки
$back_count= 5; // Количество фоновых рисунков в папке DMT_captcha_fonts идущих по порядку от 1 до $back_count
$length= rand( 3, 4 );
// Количество символов случайно от 3 до 4
// Если Вы укажите символов больше 4, 
// то увеличте ширину фонового рисунка ./DMT_captcha_fonts/back[все номера].gif
// Да и вообще нарисуйте свой фон!!!
//=======================================================================


while( true )
{
	$keystring= \'\';
	for( $i=0; $i<$length; $i++ ) $keystring .= $use_symbols{ rand( 0, $use_symbols_len-1 ) };
	if( ! preg_match( \'/cb|rn|rm|mm|co|do|db|qp|qb|dp|ww/\', $keystring ) ) break 1;
}

$im= @imagecreatefromjpeg( MODX_BASE_PATH."/mymodules/DMTCaptcha/back". rand( 1, $back_count ) .".jpg" );
//$im= @ImageCreateTrueColor( 200, 70 );

$width= @imagesx( $im );
$height= @imagesy( $im );		
$font_color= @imagecolorresolve( $im, $scolor[ $simbol_color ][0], $scolor[ $simbol_color ][1], $scolor[ $simbol_color ][2] );
$angle= 0;
$px= $margin_left;

if( $inline )
{
	//@imagettftext( $im, rand( $font_size_min, $font_size_max ), $angle, $px, $margin_top, $font_color, MODX_BASE_PATH."mymodules/DMTCaptcha/font". rand( 1, $font_count ) .".ttf", $keystring );
	@imagettftext( $im, rand( $font_size_min, $font_size_max ), $angle, $px, $margin_top, $font_color, MODX_BASE_PATH."mymodules/DMTCaptcha/font.ttf", $keystring );
}else{
	for( $i=0; $i<$length; $i++ )
	{
		if( $rotate_simbol )
		{
			$angle= rand( -30, 30 );
			if( $angle < 0 ) $angle= 360 + $angle;
		}
		@imagettftext( $im, rand( $font_size_min, $font_size_max ), $angle, $px, $margin_top, $font_color, MODX_BASE_PATH."mymodules/DMTCaptcha/font.ttf", $keystring[$i] );
		$px += $font_width + rand( $rand_bsimb_min, $rand_bsimb_max );
	}
}
$_SESSION[ \'DMTCaptcha\' ]= $keystring;
$ncolor= $scolor[ $simbol_color ];
//=======================================================================

$foreground_color= array( 255, 255, 255 );
$background_color= array( 255, 255, 255 );
$width= @imagesx( $im );
$height= @imagesy( $im );
$center= $width /2;
$img2= @imagecreatetruecolor( $width, $height );
$foreground= @imagecolorresolve( $img2, $foreground_color[0], $foreground_color[1], $foreground_color[2] );
$background= @imagecolorresolve( $img2, $background_color[0], $background_color[1], $background_color[2] );
@imagefilledrectangle( $img2, 0, 0, $width-1, $height-1, $background );		
@imagefilledrectangle( $img2, 0, $height, $width-1, $height+12, $foreground );

$rand1= rand( 750000, 1200000 ) /10000000;
$rand2= rand( 750000, 1200000 ) /10000000;
$rand3= rand( 750000, 1200000 ) /10000000;
$rand4= rand( 750000, 1200000 ) /10000000;
$rand5= rand( 0, 31415926 ) /10000000;
$rand6= rand( 0, 31415926 ) /10000000;
$rand7= rand( 0, 31415926 ) /10000000;
$rand8= rand( 0, 31415926 ) /10000000;
$rand9= rand( 330, 420 ) /110;
$rand10= rand( 330, 450 ) /110;

for( $x=0; $x<$width; $x++ )
{
	for( $y=0; $y<$height; $y++ )
	{
		$sx= $x + ( sin( $x * $rand1 + $rand5 ) + sin( $y * $rand3 + $rand6 ) ) * $rand9 - $width / 2 + $center + 1;
		$sy= $y + ( sin( $x * $rand2 + $rand7 ) + sin( $y * $rand4 + $rand8 ) ) * $rand10;
		
		if( $sx < 0 || $sy < 0 || $sx >= $width-1 || $sy >= $height-1 )
		{
			continue 1;
		}else{
			$color= @imagecolorat( $im, $sx, $sy ) & 0xFF;
			$color_x= @imagecolorat( $im, $sx+1, $sy ) & 0xFF;
			$color_y= @imagecolorat( $im, $sx, $sy+1 ) & 0xFF;
			$color_xy= @imagecolorat( $im, $sx+1, $sy+1 ) & 0xFF;
		}
		if( $color == 255 && $color_x == 255 && $color_y == 255 && $color_xy == 255 )
		{
			continue 1;
		}elseif( $color == 0 && $color_x == 0 && $color_y == 0 && $color_xy == 0 ){
			$newred= $foreground_color[0];
			$newgreen= $foreground_color[1];
			$newblue= $foreground_color[2];
		}else{
			$newred= $ncolor[0];
			$newgreen= $ncolor[1];
			$newblue= $ncolor[2];
		}
		
		@imagesetpixel($img2, $x, $y, @imagecolorallocate($img2, $newred, $newgreen, $newblue));
	}
}
$im= $img2;
//=======================================================================

header( \'Expires: Sat, 17 May 2008 05:00:00 GMT\' );
header( "Last-Modified: ". gmdate( "D, d M Y H:i:s" ) ." GMT" );
header( \'Cache-Control: no-store, no-cache, must-revalidate\' );
header( \'Cache-Control: post-check=0, pre-check=0\', FALSE );
header( \'Pragma: no-cache\' );

if( function_exists( "imagejpeg" ) )
{
	header( "Content-Type: image/jpeg" );
	@imagejpeg( $im, null, $jpeg_quality );
}elseif( function_exists( "imagegif" ) ){
	header( "Content-Type: image/gif" );
	@imagegif( $im );
}elseif( function_exists( "imagepng" ) ){
	header( "Content-Type: image/x-png" );
	@imagepng( $im );
}
exit();
';
$s['Catalog_BigMenu'] = '
$koren= 8;

$docs= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$koren, \'type\'=>\'childs\', \'depth\'=>\'1\', \'fields\'=>\'pagetitle\', \'tvfileds\'=>\'image\', \'isf\'=>\'all\' ) );
if( $docs )
{
	$ii= 0;
	foreach( $docs AS $row )
	{
		$ii++;
		$print .= $modx->runSnippet( \'CAT_ITEM\', array( \'type\' => \'category_1\', \'row\' => $row, \'last\' => ( $ii % 3 == 0 ? true : false ) ) );
	}
}

return $print;
';
$s['Catalog_TopSearch'] = '
$koren= 8;

$myid= $modx->documentIdentifier;
if( empty( $id ) ) $id= $myid;


if( isset( $_POST[ \'search\' ] ) )
{
	$dop= ( $_POST[ \'dop\' ] == \'y\' ? \'y\' : \'n\' );
	
	$cat= intval( $_POST[ \'cat\' ] );
	
	$txt= urlencode( trim( $_POST[ \'txt\' ] ) );
	
	if( $dop == \'y\' )
	{
		$art= urlencode( trim( $_POST[ \'art\' ] ) );
		$vend= urlencode( trim( $_POST[ \'vend\' ] ) );
		$cit= urlencode( trim( $_POST[ \'cit\' ] ) );
		
		$stt1= ( $_POST[ \'stt1\' ] == \'y\' ? \'y\' : \'n\' );
		$stt2= ( $_POST[ \'stt2\' ] == \'y\' ? \'y\' : \'n\' );
		$stt3= ( $_POST[ \'stt3\' ] == \'y\' ? \'y\' : \'n\' );
		$pack= ( $_POST[ \'pack\' ] == \'y\' ? \'y\' : \'n\' );
		$disc= ( $_POST[ \'disc\' ] == \'y\' ? \'y\' : \'n\' );
		$doc= ( $_POST[ \'doc\' ] == \'y\' ? \'y\' : \'n\' );
	}
	
	$url= ( $cat ? $modx->makeUrl( $cat ) : $modx->makeUrl( $koren ) );
	$url_x= \'x\';
	
	if( $dop == \'y\' )
	{
		if( $dop == \'y\' ) $url_x .= \'/dop_y\';
		
		if( $stt1 == \'y\' ) $url_x .= \'/s1_y\';
		if( $stt2 == \'y\' ) $url_x .= \'/s2_y\';
		if( $stt3 == \'y\' ) $url_x .= \'/s3_y\';
		
		if( $pack == \'y\' ) $url_x .= \'/p_y\';
		if( $disc == \'y\' ) $url_x .= \'/dc_y\';
		if( $doc == \'y\' ) $url_x .= \'/d_y\';
		
		if( $art ) $url_x .= \'/a_\'. $art;
		if( $vend ) $url_x .= \'/v_\'. $vend;
		if( $cit ) $url_x .= \'/c_\'. $cit;
	}
	
	if( $txt ) $url_x .= \'/t_\'. $txt;
	
	header( \'location: \'. $url .( $url_x != \'x\' ? $url_x .\'/\' : \'\' ) );
	exit();
}



if( $modx->catalogFilterListX )
{
	$xps= explode( "/", $modx->catalogFilterListX );
	$xps_vals= array();
	if( $xps )
	{
		foreach( $xps AS $xp )
		{
			$xp= explode( "_", $xp );
			$xps_vals[ $xp[ 0 ] ]= urldecode( $xp[ 1 ] );
		}
	}
}
if( $modx->catalogFilterListX ) $xps_flag_1= true;
if( $xps_vals[ \'dop\' ] == \'y\' ) $xps_flag_2= true;
if( $xps_flag_1 && $xps_flag_2 ) $xps_flag_3= true;



$select1= \'\';
$cats= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$koren, \'type\'=>\'childs\', \'depth\'=>\'1\', \'fields\'=>\'pagetitle\', \'isf\'=>\'all\' ) );
if( $cats )
{
	foreach( $cats AS $row )
	{
		$podcats= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>$row[ \'id\' ], \'type\'=>\'childs\', \'depth\'=>\'1\', \'fields\'=>\'pagetitle\', \'isf\'=>\'all\' ) );
		$select1 .= \'<optgroup label="\'. $row[ \'pagetitle\' ] .\'">\';
		if( $podcats )
		{
			foreach( $podcats AS $row2 )
			{
				$select1 .= \'<option \'.( $row2[ \'id\' ] == $id ? \'selected="selected"\' : \'\' ).\' value="\'. $row2[ \'id\' ] .\'">\'. $row2[ \'pagetitle\' ] .\'</option>\';
			}
		}
		$select1 .= \'</optgroup>\';
	}
}
?>

<div class="topsearch <?= ( $xps_flag_3 ? \'topsearch_active\' : \'\' ) ?>">
	<form action="[~8~]" method="post">
		<div class="tsch_block_1">
			<div class="tsch_pole">
				<input class="tsch_maininput default_value" type="text" name="txt" data-default="Артикул, производитель, поисковая фраза ..." value="<?= $xps_vals[ \'t\' ] ?>" />
				<div class="tsch_ico">&nbsp;</div>
				<div class="tsch_dop"><span class="famicon">&nbsp;&nbsp;</span><span class="txt">Дополнительные параметры поиска</span><div class="ugolok">&nbsp;</div></div>
			</div>
			<input class="tsch_dop_input_flag" type="hidden" name="dop" value="<?= ( $xps_flag_2 ? \'y\' : \'n\' ) ?>" />
			<div class="tsch_submit"><button type="submit" name="search">Найти</button></div>
			<div class="clr">&nbsp;</div>
		</div>
		
		<div class="clr">&nbsp;</div>
		
		<div class="tsch_block_2">
			<div class="tsch_ugolok">&nbsp;</div>
			
			<div class="tsch_close"><span class="as2">Закрыть</span></div>
			
			<div class="tsch_col tsch_col_2">
				<div class="tsch_input">
					<div class="tsch_lbl">Категория каталога</div>
					<div class="tsch_inp">
						<select name="cat" size="8">
							<option value="0" selected="selected">~ любая категория ~</option>
							<?= $select1 ?>
						</select>
					</div>
				</div>
			</div>
			
			<div class="tsch_col tsch_col_3">
				<div class="tsch_input">
					<div class="tsch_lbl">Артикул</div>
					<div class="tsch_inp"><input type="text" name="art" value="<?= $xps_vals[ \'a\' ] ?>" /></div>
				</div>
				
				<div class="tsch_input">
					<div class="tsch_lbl">Производитель</div>
					<div class="tsch_inp"><input type="text" name="vend" value="<?= $xps_vals[ \'v\' ] ?>" /></div>
				</div>
				
				<div class="tsch_input">
					<div class="tsch_lbl">Город</div>
					<div class="tsch_inp"><input type="text" name="cit" value="<?= $xps_vals[ \'c\' ] ?>" /></div>
				</div>
			</div>
			
			<div class="tsch_col">
				<div class="tsch_input">
					<div class="tsch_lbl">Состояние</div>
					<div class="tsch_inp">
						<div><label><input type="checkbox" name="stt1" value="y" <?= ( $xps_vals[ \'s1\' ] == \'y\' ? \'checked="checked"\' : \'\' ) ?> /> Новое</label></div>
						<div><label><input type="checkbox" name="stt2" value="y" <?= ( $xps_vals[ \'s2\' ] == \'y\' ? \'checked="checked"\' : \'\' ) ?> /> Б/У</label></div>
						<div><label><input type="checkbox" name="stt3" value="y" <?= ( $xps_vals[ \'s3\' ] == \'y\' ? \'checked="checked"\' : \'\' ) ?> /> На запчасти</label></div>
					</div>
				</div>
			</div>
			
			<div class="tsch_col">
				<div class="tsch_input">
					<div class="tsch_inp"><label><input type="checkbox" name="pack" value="y" <?= ( $xps_vals[ \'p\' ] == \'y\' ? \'checked="checked"\' : \'\' ) ?> /> Есть упаковка</label></div>
				</div>
				
				<div class="tsch_input">
					<div class="tsch_inp"><label><input type="checkbox" name="disc" value="y" <?= ( $xps_vals[ \'dc\' ] == \'y\' ? \'checked="checked"\' : \'\' ) ?> /> Распродажа</label></div>
				</div>
				
				<div class="tsch_input">
					<div class="tsch_inp"><label><input type="checkbox" name="doc" value="y" <?= ( $xps_vals[ \'d\' ] == \'y\' ? \'checked="checked"\' : \'\' ) ?> /> Документация</label></div>
				</div>
			</div>
			<div class="clr">&nbsp;</div>
		</div>
	</form>
</div>
<?php
';
$s['_LK_UserInfo'] = '
//v05
//==================================================================================
$lk= 106;
$reg= 107;
$auth= 108;
$restorepassword= 109;
$agreed= 110;
$DMTCaptcha= 111;
$DMTCaptcha_img= 112;
//==================================================================================
	
$topage_url= $modx->makeUrl( $modx->documentIdentifier );

if( ! $_SESSION[ \'webuserinfo\' ][ \'auth\' ] )
{
	header( \'location: \'. $modx->makeUrl( $auth ) );
	exit();
}

$webuserinfo= $_SESSION[ \'webuserinfo\' ][ \'info\' ];
$post[ \'urlico\' ]= $webuserinfo[ \'urlico\' ];

// =======================================================================================================


$vkladka_active= 1;
if( isset( $_GET[ \'ok21\' ] ) || isset( $_GET[ \'ok22\' ] ) || isset( $_POST[ \'save_2\' ] ) ) $vkladka_active= 2;
if( isset( $_GET[ \'ok3\' ] ) || isset( $_POST[ \'save_2\' ] ) ) $vkladka_active= 3;
	

if( isset( $_POST[ \'save_1\' ] ) )
{
	$save_surname= addslashes( trim( $_POST[ \'save_surname\' ] ) );
	$save_firstname= addslashes( trim( $_POST[ \'save_firstname\' ] ) );
	
	$save_email= addslashes( trim( $_POST[ \'save_email\' ] ) );
	$save_mobile= addslashes( trim( $_POST[ \'save_mobile\' ] ) );
	
	$save_passport= addslashes( trim( $_POST[ \'save_passport\' ] ) );
	$save_passport_dth= addslashes( trim( $_POST[ \'save_passport_dth\' ] ) );
	$save_passport_who= addslashes( trim( $_POST[ \'save_passport_who\' ] ) );
	$save_passport_address= addslashes( trim( $_POST[ \'save_passport_address\' ] ) );
	
	$qq= \'\';
	
	if( $save_firstname && $save_firstname != $webuserinfo[ \'firstname\' ] ) $qq .= ( ! empty( $qq ) ? ", " : "" ) ."firstname=\'{$save_firstname}\'";
	if( $save_surname && $save_surname != $webuserinfo[ \'surname\' ] ) $qq .= ( ! empty( $qq ) ? ", " : "" ) ."surname=\'{$save_surname}\'";
	
	if( $save_passport && $save_passport != $webuserinfo[ \'passport\' ] ) $qq .= ( ! empty( $qq ) ? ", " : "" ) ."passport=\'{$save_passport}\'";
	if( $save_passport_dth && $save_passport_dth != $webuserinfo[ \'passport_dth\' ] ) $qq .= ( ! empty( $qq ) ? ", " : "" ) ."passport_dth=\'{$save_passport_dth}\'";
	if( $save_passport_who && $save_passport_who != $webuserinfo[ \'passport_who\' ] ) $qq .= ( ! empty( $qq ) ? ", " : "" ) ."passport_who=\'{$save_passport_who}\'";
	if( $save_passport_address && $save_passport_address != $webuserinfo[ \'passport_address\' ] ) $qq .= ( ! empty( $qq ) ? ", " : "" ) ."passport_address=\'{$save_passport_address}\'";
	
	if( ! preg_match( "/^[a-z0-9-_\\.]{1,}@[a-z0-9-\\.]{1,}\\.[a-z]{2,10}$/i", $save_email ) )
	{
		$save_err .= \'<p>- Адрес электронной почты неверного формата</p>\';
		$save_err_flag[ \'save_email\' ]= true;
	}elseif( $save_email != $webuserinfo[ \'email\' ] ){
		//$qq .= ( ! empty( $qq ) ? ", " : "" ) ."email=\'{$save_email}\'";
	}
	
	if( ! preg_match( "/^\\+7 [0-9]{3} [0-9]{3}-[0-9]{4}$/i", $save_mobile ) )
	{
		$save_err .= \'<p>- Номер мобильного телефона неверного формата</p>\';
		$save_err_flag[ \'save_mobile\' ]= true;
	}elseif( $save_mobile != $webuserinfo[ \'mobile\' ] ){
		//$qq .= ( ! empty( $qq ) ? ", " : "" ) ."mobile=\'{$save_mobile}\'";
	}
	
	if( $qq )
	{
		mysql_query( "INSERT INTO ".$modx->getFullTableName( \'_user_h\' )." SELECT * FROM ".$modx->getFullTableName( \'_user\' )." WHERE id=". $_SESSION[ \'webuserinfo\' ][ \'id\' ] ." LIMIT 1" );
		mysql_query( "UPDATE ".$modx->getFullTableName( \'_user\' )." SET {$qq} WHERE id=". $_SESSION[ \'webuserinfo\' ][ \'id\' ] ." LIMIT 1" );
		
		header( \'location: \'. $topage_url .\'?ok1\' );
		exit();
	}
}
?>






<div class="vkladki_butts">
	<div class="vkldk_butt <?= ( $vkladka_active == 1 ? \'active\' : \'\' ) ?>" data-id="1">Данные физ.лица</div>
	<div class="vkldk_butt <?= ( $vkladka_active == 2 ? \'active\' : \'\' ) ?>" data-id="2">Данные юр.лица</div>
	<div class="vkldk_butt <?= ( $vkladka_active == 3 ? \'active\' : \'\' ) ?>" data-id="3">Склады</div>
	<div class="vkldk_butt <?= ( $vkladka_active == 4 ? \'active\' : \'\' ) ?>" data-id="4">Контакты</div>
	<div class="clr">&nbsp;</div>
</div>

<div class="vkladki_divs">
	<div class="vkldk_div vkldk_div_1 <?= ( $vkladka_active == 1 ? \'active\' : \'\' ) ?>">
		<div class="_LK_wrapper _LK_wrapper_big">
			<div class="_LK_form">
				<?php if( isset( $_GET[ \'ok1\' ] ) ){ ?>
				<div class="_LK_ok">
					<p>Данные успешно сохранены!</p>
				</div>
				<?php } ?>
				
				<?php if( ! empty( $save_err ) ) print \'<div class="_LK_error">\'. $save_err .\'</div>\'; ?>
				
				<form action="<?= $topage_url ?>" method="post">
					<div class="_LK_form_line">
						<div class="_LK_form_lbl">Фамилия</div>
						<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_surname\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_surname" value="<?= $webuserinfo[ \'surname\' ] ?>" /></div>
						<div class="clr">&nbsp;</div>
					</div>
					<div class="_LK_form_line _LK_form_line_br">
						<div class="_LK_form_lbl">Имя</div>
						<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_firstname\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_firstname" value="<?= $webuserinfo[ \'firstname\' ] ?>" /></div>
						<div class="clr">&nbsp;</div>
					</div>
					
					<div class="_LK_form_line">
						<div class="_LK_form_lbl">Адрес электронной почты</div>
						<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_email\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_email" value="<?= $webuserinfo[ \'email\' ] ?>" /></div>
						<div class="clr">&nbsp;</div>
					</div>
					<div class="_LK_form_line _LK_form_line_br">
						<div class="_LK_form_lbl">Номер мобильного телефона</div>
						<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_mobile\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input class="input_mask_mobile" type="text" name="save_mobile" value="<?= $webuserinfo[ \'mobile\' ] ?>" /></div>
						<div class="clr">&nbsp;</div>
					</div>
					
					<div class="_LK_form_line">
						<div class="_LK_form_lbl">Серия и номер паспорта</div>
						<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_passport\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_passport" value="<?= $webuserinfo[ \'passport\' ] ?>" /></div>
						<div class="clr">&nbsp;</div>
					</div>
					<div class="_LK_form_line">
						<div class="_LK_form_lbl">Дата выдачи</div>
						<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_passport_dth\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_passport_dth" value="<?= $webuserinfo[ \'passport_dth\' ] ?>" /></div>
						<div class="clr">&nbsp;</div>
					</div>
					<div class="_LK_form_line">
						<div class="_LK_form_lbl">Кем выдан</div>
						<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_passport_who\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_passport_who" value="<?= $webuserinfo[ \'passport_who\' ] ?>" /></div>
						<div class="clr">&nbsp;</div>
					</div>
					<div class="_LK_form_line _LK_form_line_br">
						<div class="_LK_form_lbl">Адрес регистрации (прописки)</div>
						<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_passport_address\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_passport_address" value="<?= $webuserinfo[ \'passport_address\' ] ?>" /></div>
						<div class="clr">&nbsp;</div>
					</div>
					
					<div class="_LK_form_line _LK_form_line_butt">
						<div class="_LK_form_lbl"> </div>
						<div class="_LK_form_inp"><button class="buttonsubmit" name="save_1" type="submit">Сохранить</button></div>
						<div class="clr">&nbsp;</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- ===================================================================================== -->
	
	
	
	
	
	
<?php

if( isset( $_POST[ \'save_2\' ] ) )
{
	$vkladka_active= 2;
	
	$save_company= addslashes( trim( $_POST[ \'save_company\' ] ) );
	$save_address_ur= addslashes( trim( $_POST[ \'save_address_ur\' ] ) );
	$save_address_ft= addslashes( trim( $_POST[ \'save_address_ft\' ] ) );
	$save_inn= addslashes( trim( $_POST[ \'save_inn\' ] ) );
	$save_kpp= addslashes( trim( $_POST[ \'save_kpp\' ] ) );
	$save_bik= addslashes( trim( $_POST[ \'save_bik\' ] ) );
	$save_ogrn= addslashes( trim( $_POST[ \'save_ogrn\' ] ) );
	$save_bank= addslashes( trim( $_POST[ \'save_bank\' ] ) );
	$save_rschet= addslashes( trim( $_POST[ \'save_rschet\' ] ) );
	$save_kschet= addslashes( trim( $_POST[ \'save_kschet\' ] ) );
	
	$save_agreed= ( $_POST[ \'save_agreed\' ] == \'y\' ? \'y\' : \'n\' );
	$save_urlico= ( $_POST[ \'save_urlico\' ] == \'y\' ? \'test\' : \'n\' );
	
	if( $webuserinfo[ \'urlico\' ] == \'y\' && $save_agreed != \'y\' )
	{
		$save_err .= \'<p>- Подтвердите изменение данных</p>\';
	}
	
	if( $save_urlico != \'n\' )
	{
		if( ! $save_company || ! $save_address_ur || ! $save_address_ft || ! $save_bank )
		{
			$save_err .= \'<p>- Заполните все реквизиты</p>\';
			$save_err_flag[ \'save_company\' ]= true;
			$save_err_flag[ \'save_address_ur\' ]= true;
			$save_err_flag[ \'save_address_ft\' ]= true;
			$save_err_flag[ \'save_bank\' ]= true;
		}
		if( ! preg_match( "/^[0-9]{10}$/", $save_inn ) )
		{
			$save_err .= \'<p>- ИНН неверного формата</p>\';
			$save_err_flag[ \'save_inn\' ]= true;
		}
		if( ! preg_match( "/^[A-Za-z0-9]{9}$/", $save_kpp ) )
		{
			$save_err .= \'<p>- КПП неверного формата</p>\';
			$save_err_flag[ \'save_kpp\' ]= true;
		}
		if( ! preg_match( "/^[0-9]{9}$/", $save_bik ) )
		{
			$save_err .= \'<p>- БИК неверного формата</p>\';
			$save_err_flag[ \'save_bik\' ]= true;
		}
		if( ! preg_match( "/^[A-Za-z0-9]{13,15}$/", $save_ogrn ) )
		{
			$save_err .= \'<p>- ОГРН (ОГРНИП) неверного формата</p>\';
			$save_err_flag[ \'save_ogrn\' ]= true;
		}
		if( ! preg_match( "/^[0-9]{20,25}$/", $save_rschet ) )
		{
			$save_err .= \'<p>- Рассчетный счет неверного формата</p>\';
			$save_err_flag[ \'save_rschet\' ]= true;
		}
		if( ! preg_match( "/^[0-9]{20}$/", $save_kschet ) )
		{
			$save_err .= \'<p>- Корреспондентский счёт неверного формата</p>\';
			$save_err_flag[ \'save_kschet\' ]= true;
		}
		if( ! $save_err )
		{
			mysql_query( "INSERT INTO ".$modx->getFullTableName( \'_user_h\' )." SELECT * FROM ".$modx->getFullTableName( \'_user\' )." WHERE id=". $_SESSION[ \'webuserinfo\' ][ \'id\' ] ." LIMIT 1" );
			
			mysql_query( "UPDATE ".$modx->getFullTableName( \'_user\' )." SET
						urlico=\'{$save_urlico}\',
						company=\'{$save_company}\',
						address_ur=\'{$save_address_ur}\',
						address_ft=\'{$save_address_ft}\',
						inn=\'{$save_inn}\',
						kpp=\'{$save_kpp}\',
						bik=\'{$save_bik}\',
						ogrn=\'{$save_ogrn}\',
						bank=\'{$save_bank}\',
						rschet=\'{$save_rschet}\',
						kschet=\'{$save_kschet}\'
							WHERE id=". $_SESSION[ \'webuserinfo\' ][ \'id\' ] ." LIMIT 1" );
			
			header( \'location: \'. $topage_url .\'?ok21\' );
			exit();
			
		}else{
			$post[ \'urlico\' ]= $save_urlico;
			
			$webuserinfo[ \'company\' ]= $save_company;
			$webuserinfo[ \'address_ur\' ]= $save_address_ur;
			$webuserinfo[ \'address_ft\' ]= $save_address_ft;
			$webuserinfo[ \'inn\' ]= $save_inn;
			$webuserinfo[ \'kpp\' ]= $save_kpp;
			$webuserinfo[ \'bik\' ]= $save_bik;
			$webuserinfo[ \'ogrn\' ]= $save_ogrn;
			$webuserinfo[ \'bank\' ]= $save_bank;
			$webuserinfo[ \'rschet\' ]= $save_rschet;
			$webuserinfo[ \'kschet\' ]= $save_kschet;
		}
	}
	
	if( $save_urlico == \'n\' )
	{
		if( ! $save_err )
		{
			mysql_query( "UPDATE ".$modx->getFullTableName( \'_user\' )." SET
						urlico=\'{$save_urlico}\'
							WHERE id=". $_SESSION[ \'webuserinfo\' ][ \'id\' ] ." LIMIT 1" );
			
			header( \'location: \'. $topage_url .\'?ok22\' );
			exit();
			
		}else{
			$post[ \'urlico\' ]= $save_urlico;
		}
	}
}
?>
	
	<div class="vkldk_div vkldk_div_2 <?= ( $vkladka_active == 2 ? \'active\' : \'\' ) ?>">
		<div class="_LK_wrapper _LK_wrapper_big">
			<div class="_LK_form">
				<?php if( isset( $_GET[ \'ok21\' ] ) ){ ?>
				<div class="_LK_ok">
					<p>Данные отправлены на проверку!</p>
					<p>Статус юридического лица пока еще не был присвоен!</p>
				</div>
				<?php } ?>
				
				<?php if( isset( $_GET[ \'ok22\' ] ) ){ ?>
				<div class="_LK_ok">
					<p>Сохранено!</p>
				</div>
				<?php } ?>
				
				<?php if( ! isset( $_GET[ \'ok21\' ] ) && $webuserinfo[ \'urlico\' ] == \'test\' ){ ?>
				<div class="_LK_info">
					<p>Данные проходят проверку!</p>
					<p>Статус юридического лица не присвоен!</p>
				</div>
				<?php } ?>
				
				<?php if( ! empty( $save_err ) ) print \'<div class="_LK_error">\'. $save_err .\'</div>\'; ?>
				
				<form action="<?= $topage_url ?>" method="post">
					
					<?php if( $webuserinfo[ \'urlico\' ] != \'n\' ){ ?>
					<div class="_LK_form_line _LK_form_line_br">
						<div class="_LK_form_lbl"><b>Статус</b></div>
						<div class="_LK_form_inp _LK_form_inp_txt"><b>
						<?php
							if( $webuserinfo[ \'urlico\' ] == \'y\' ) print \'Юридическое лицо. Данные подтверждены!\';
							elseif( $webuserinfo[ \'urlico\' ] == \'test\' ) print \'Данные юридического лица на проверке!\';
						?>
						</b></div>
						<div class="clr">&nbsp;</div>
					</div>
					<br />
					<?php } ?>
					
					<div class="_LK_form_line _LK_form_line_br">
						<div class="_LK_form_lbl"><input class="LK_form_urlico_checkbox" type="checkbox" name="save_urlico" value="y" <?=( $post[ \'urlico\' ] != \'n\' ? \'checked="checked"\' : \'\' )?> /></div>
						<div class="_LK_form_inp"><?= ( $post[ \'urlico\' ] == \'y\' ? \'Юридическое лицо\' : \'Отправить заявку<br />на получение статуса юридического лица\' ) ?></div>
						<div class="clr">&nbsp;</div>
					</div>
					
					<div class="LK_form_urlico <?=( $post[ \'urlico\' ] != \'n\' ? \'LK_form_urlico_active\' : \'\' )?>">
						<div class="_LK_form_line _LK_form_line_br">
							<div class="_LK_form_lbl">Наименование компании</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_company\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_company" value="<?= $webuserinfo[ \'company\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						<div class="_LK_form_line">
							<div class="_LK_form_lbl">Юридический адрес</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_address_ur\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_address_ur" value="<?= $webuserinfo[ \'address_ur\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						<div class="_LK_form_line _LK_form_line_br">
							<div class="_LK_form_lbl">Фактический адрес</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_address_ft\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_address_ft" value="<?= $webuserinfo[ \'address_ft\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						
						<div class="_LK_form_line">
							<div class="_LK_form_lbl">ИНН</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_inn\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_inn" value="<?= $webuserinfo[ \'inn\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						<div class="_LK_form_line">
							<div class="_LK_form_lbl">КПП</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_kpp\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_kpp" value="<?= $webuserinfo[ \'kpp\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						<div class="_LK_form_line">
							<div class="_LK_form_lbl">БИК</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_bik\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_bik" value="<?= $webuserinfo[ \'bik\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						<div class="_LK_form_line">
							<div class="_LK_form_lbl">ОГРН (ОГРНИП)</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_ogrn\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_ogrn" value="<?= $webuserinfo[ \'ogrn\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						<div class="_LK_form_line">
							<div class="_LK_form_lbl">Рассчетный счет</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_rschet\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_rschet" value="<?= $webuserinfo[ \'rschet\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						<div class="_LK_form_line">
							<div class="_LK_form_lbl">Наименование банка</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_bank\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_bank" value="<?= $webuserinfo[ \'bank\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
						<div class="_LK_form_line _LK_form_line_br">
							<div class="_LK_form_lbl">Корр. счет</div>
							<div class="_LK_form_inp <?= ( $save_err_flag[ \'save_kschet\' ] ? \'_LK_form_inp_error\' : \'\' ) ?>"><input type="text" name="save_kschet" value="<?= $webuserinfo[ \'kschet\' ] ?>" /></div>
							<div class="clr">&nbsp;</div>
						</div>
					</div>
						
					<?php if( $webuserinfo[ \'urlico\' ] == \'y\' ){ ?>
					<div class="_LK_form_line">
						<div class="_LK_form_lbl"><input type="checkbox" name="save_agreed" value="y" /></div>
						<div class="_LK_form_inp">Подтверждаю изменение данных</div>
						<div class="clr">&nbsp;</div>
					</div>
					<div class="_LK_form_line">
						<div class="_LK_form_lbl"> </div>
						<div class="_LK_form_inp">
							<div class="_LK_info">
								<p>Измененные данные подлежат проверке администратором.</p>
								<p>На время проверки функции юридического лица будут не доступны.</p>
							</div>
						</div>
						<div class="clr">&nbsp;</div>
					</div>
					<?php } ?>
					
					<div class="_LK_form_line _LK_form_line_butt">
						<div class="_LK_form_lbl"> </div>
						<div class="_LK_form_inp"><button class="buttonsubmit" name="save_2" type="submit">Сохранить</button></div>
						<div class="clr">&nbsp;</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- ===================================================================================== -->
	
	
	
	
	
	
	
	
	<div class="vkldk_div vkldk_div_3 <?= ( $vkladka_active == 3 ? \'active\' : \'\' ) ?>">Склады</div>
	<!-- ===================================================================================== -->
	
	
	
	
	
	
	
	
	<div class="vkldk_div vkldk_div_4 <?= ( $vkladka_active == 4 ? \'active\' : \'\' ) ?>">Контакты</div>
	
	<div class="clr">&nbsp;</div>
</div>

<?php
';
$s['_LK_LeftMenu'] = '
print \'<div class="_LK_leftblock">\';
print \'<div class="_LK_leftmenu"><ul>\';

$menu= $modx->runSnippet( \'GetDoc6\', array( \'ids\'=>115, \'type\'=>\'childs\', \'depth\'=>1, \'fields\'=>\'pagetitle\', \'sort\'=>\'menuindex\', \'isf\'=>\'all\' ) );
if( $menu )
{
	foreach( $menu AS $row )
	{
		print \'<li class="\'.( $row[ \'id\' ] == $modx->documentIdentifier ? \'active\' : \'\' ).\'"><a href="\'. $modx->makeUrl( $row[ \'id\' ] ) .\'"><span class="famicon">&nbsp;&nbsp;&nbsp;</span>\'. $row[ \'pagetitle\' ] .\'</a></li>\';
	}
}

print \'</ul></div>\';
print \'</div>\';
';
$p = &$this->pluginCache;
$p['TransAlias'] = 'require MODX_BASE_PATH.\'assets/plugins/transalias/plugin.transalias.php\';';
$p['TransAliasProps'] = '&table_name=Trans table;list;common,russian,dutch,german,czech,utf8,utf8lowercase;russian &char_restrict=Restrict alias to;list;lowercase alphanumeric,alphanumeric,legal characters;legal characters &remove_periods=Remove Periods;list;Yes,No;No &word_separator=Word Separator;list;dash,underscore,none;dash &override_tv=Override TV name;string; ';
$p['ManagerManager'] = '// You can put your ManagerManager rules EITHER in a chunk OR in an external file - whichever suits your development style the best

// To use an external file, put your rules in /assets/plugins/managermanager/mm_rules.inc.php 
// (you can rename default.mm_rules.inc.php and use it as an example)
// The chunk SHOULD have php opening tags at the beginning and end

// If you want to put your rules in a chunk (so you can edit them through the Manager),
// create the chunk, and enter its name in the configuration tab.
// The chunk should NOT have php tags at the beginning or end.

// See also user-friendly module for editing ManagerManager configuration file ddMMEditor (http://code.divandesign.biz/modx/ddmmeditor).

// ManagerManager requires jQuery 1.9.1, which is located in /assets/plugins/managermanager/js/ folder.

// You don\'t need to change anything else from here onwards
//-------------------------------------------------------

// Run the main code
include($modx->config[\'base_path\'].\'assets/plugins/managermanager/mm.inc.php\');';
$p['ManagerManagerProps'] = '&remove_deprecated_tv_types_pref=Remove deprecated TV types;list;yes,no;yes &config_chunk=Configuration Chunk;text;mm_rules ';
$p['FileSource'] = 'require MODX_BASE_PATH.\'assets/plugins/filesource/plugin.filesource.php\';';
$p['Forgot Manager Login'] = 'require MODX_BASE_PATH.\'assets/plugins/forgotmanagerlogin/plugin.forgotmanagerlogin.php\';';
$p['CodeMirror'] = '$_CM_BASE = \'assets/plugins/codemirror/\';

$_CM_URL = $modx->config[\'site_url\'] . $_CM_BASE;

require(MODX_BASE_PATH. $_CM_BASE .\'codemirror.plugin.php\');

';
$p['CodeMirrorProps'] = '&theme=Theme;list;default,ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,midnight,monokai,neat,night,rubyblue,solarized,twilight,vibrant-ink,xq-dark,xq-light; &indentUnit=Indent unit;int;4 &tabSize=The width of a tab character;int;4 &lineWrapping=lineWrapping;list;true,false;true &matchBrackets=matchBrackets;list;true,false;true &activeLine=activeLine;list;true,false;false &emmet=emmet;list;true,false;true &search=search;list;true,false;true ';
$p['TinyMCE Rich Text Editor'] = 'require MODX_BASE_PATH.\'assets/plugins/tinymce/plugin.tinymce.php\';
';
$p['TinyMCE Rich Text EditorProps'] = '&customparams=Custom Parameters;textarea;valid_elements : "*[*]", &mce_formats=Block Formats;text;p,h1,h2,h3,h4,h5,h6,div,blockquote,code,pre &entity_encoding=Entity Encoding;list;named,numeric,raw;named &entities=Entities;text; &mce_path_options=Path Options;list;Site config,Absolute path,Root relative,URL,No convert;Site config &mce_resizing=Advanced Resizing;list;true,false;true &disabledButtons=Disabled Buttons;text; &link_list=Link List;list;enabled,disabled;enabled &webtheme=Web Theme;list;simple,editor,creative,custom;simple &webPlugins=Web Plugins;text;style,advimage,advlink,searchreplace,contextmenu,paste,fullscreen,xhtmlxtras,media &webButtons1=Web Buttons 1;text;undo,redo,selectall,|,pastetext,pasteword,|,search,replace,|,hr,charmap,|,image,link,unlink,anchor,media,|,cleanup,removeformat,|,fullscreen,code,help &webButtons2=Web Buttons 2;text;bold,italic,underline,strikethrough,sub,sup,|,|,blockquote,bullist,numlist,outdent,indent,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,|,styleprops &webButtons3=Web Buttons 3;text; &webButtons4=Web Buttons 4;text; &webAlign=Web Toolbar Alignment;list;ltr,rtl;ltr &width=Width;text;100% &height=Height;text;500 ';
$p['Антиолень 3.0'] = '// - v3.00

$tb_1= \'site_content\';
$tb_2= \'site_htmlsnippets\';
$tb_3= \'site_snippets\';
$tb_4= \'site_templates\';
$tb_5= \'site_tmplvar_contentvalues\';
$tb_6= \'site_tmplvars\';

mysql_query( "
CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\' . $tb_1 )." (
  `idm` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT \'document\',
  `contentType` varchar(50) NOT NULL DEFAULT \'text/html\',
  `pagetitle` varchar(255) NOT NULL DEFAULT \'\',
  `longtitle` varchar(255) NOT NULL DEFAULT \'\',
  `description` varchar(255) NOT NULL DEFAULT \'\',
  `alias` varchar(255) DEFAULT \'\',
  `link_attributes` varchar(255) NOT NULL DEFAULT \'\',
  `published` int(1) NOT NULL DEFAULT \'0\',
  `pub_date` int(20) NOT NULL DEFAULT \'0\',
  `unpub_date` int(20) NOT NULL DEFAULT \'0\',
  `parent` int(10) NOT NULL DEFAULT \'0\',
  `isfolder` int(1) NOT NULL DEFAULT \'0\',
  `introtext` text,
  `content` mediumtext,
  `richtext` tinyint(1) NOT NULL DEFAULT \'1\',
  `template` int(10) NOT NULL DEFAULT \'1\',
  `menuindex` int(10) NOT NULL DEFAULT \'0\',
  `searchable` int(1) NOT NULL DEFAULT \'1\',
  `cacheable` int(1) NOT NULL DEFAULT \'1\',
  `createdby` int(10) NOT NULL DEFAULT \'0\',
  `createdon` int(20) NOT NULL DEFAULT \'0\',
  `editedby` int(10) NOT NULL DEFAULT \'0\',
  `editedon` int(20) NOT NULL DEFAULT \'0\',
  `deleted` int(1) NOT NULL DEFAULT \'0\',
  `deletedon` int(20) NOT NULL DEFAULT \'0\',
  `deletedby` int(10) NOT NULL DEFAULT \'0\',
  `publishedon` int(20) NOT NULL DEFAULT \'0\',
  `publishedby` int(10) NOT NULL DEFAULT \'0\',
  `menutitle` varchar(255) NOT NULL DEFAULT \'\',
  `donthit` tinyint(1) NOT NULL DEFAULT \'0\',
  `haskeywords` tinyint(1) NOT NULL DEFAULT \'0\',
  `hasmetatags` tinyint(1) NOT NULL DEFAULT \'0\',
  `privateweb` tinyint(1) NOT NULL DEFAULT \'0\',
  `privatemgr` tinyint(1) NOT NULL DEFAULT \'0\',
  `content_dispo` tinyint(1) NOT NULL DEFAULT \'0\',
  `hidemenu` tinyint(1) NOT NULL DEFAULT \'0\',
  `alias_visible` int(2) NOT NULL DEFAULT \'1\',
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;" );


mysql_query( "
CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\' . $tb_5 )." (
  `idm` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `tmplvarid` int(10) NOT NULL DEFAULT \'0\',
  `contentid` int(10) NOT NULL DEFAULT \'0\',
  `value` text,
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;" );


mysql_query( "
CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\' . $tb_2 )." (
  `idm` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `description` varchar(255) NOT NULL DEFAULT \'Chunk\',
  `editor_type` int(11) NOT NULL DEFAULT \'0\',
  `category` int(11) NOT NULL DEFAULT \'0\',
  `cache_type` tinyint(1) NOT NULL DEFAULT \'0\',
  `snippet` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;" );


mysql_query( "
CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\' . $tb_3 )." (
  `idm` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `description` varchar(255) NOT NULL DEFAULT \'Snippet\',
  `editor_type` int(11) NOT NULL DEFAULT \'0\',
  `category` int(11) NOT NULL DEFAULT \'0\',
  `cache_type` tinyint(1) NOT NULL DEFAULT \'0\',
  `snippet` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT \'0\',
  `properties` text,
  `moduleguid` varchar(32) NOT NULL DEFAULT \'\',
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;" );


mysql_query( "
CREATE TABLE IF NOT EXISTS ".$modx->getFullTableName( \'aaa_\' . $tb_4 )." (
  `idm` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `templatename` varchar(50) NOT NULL DEFAULT \'\',
  `description` varchar(255) NOT NULL DEFAULT \'Template\',
  `editor_type` int(11) NOT NULL DEFAULT \'0\',
  `category` int(11) NOT NULL DEFAULT \'0\',
  `icon` varchar(255) NOT NULL DEFAULT \'\',
  `template_type` int(11) NOT NULL DEFAULT \'0\',
  `content` mediumtext,
  `locked` tinyint(4) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`idm`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;" );



$e= &$modx->Event;
$mid= $e->params[ \'id\' ];



if( $e->name == "OnBeforeDocFormSave" || $e->name == "OnBeforeDocFormDelete" ) // СТРАНИЦЫ
{
	mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\' . $tb_1 )."
		( `id`,`type`,`contentType`,`pagetitle`,`longtitle`,`description`,`alias`,
		`link_attributes`,`published`,`pub_date`,`unpub_date`,`parent`,`isfolder`,`introtext`,
		`content`,`richtext`,`template`,`menuindex`,`searchable`,`cacheable`,`createdby`,
		`createdon`,`editedby`,`editedon`,`deleted`,`deletedon`,`deletedby`,`publishedon`,
		`publishedby`,`menutitle`,`donthit`,`haskeywords`,`hasmetatags`,`privateweb`,`privatemgr`,`content_dispo`,`hidemenu`,`alias_visible` ) SELECT * FROM ".$modx->getFullTableName( $tb_1 )."
		WHERE id={$mid} LIMIT 1" );
	
	$rr= mysql_query( "SELECT id FROM ".$modx->getFullTableName( $tb_6 )." ORDER BY id" );
	
	if( $rr && mysql_num_rows( $rr ) > 0 )
	{
		while( $row= mysql_fetch_assoc( $rr ) )
		{
			mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\' . $tb_5 )." ( `id`, `tmplvarid`, `contentid`, `value` ) SELECT * FROM ".$modx->getFullTableName( $tb_5 )." WHERE contentid={$mid} AND tmplvarid={$row[id]}" );
		}
	}
	
	
	
//----------------------------
	
}elseif( $e->name == "OnBeforeChunkFormSave" || $e->name == "OnBeforeChunkFormDelete" ){ // ЧАНКИ

	mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\' . $tb_2 )." ( `id`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked` ) SELECT * FROM ".$modx->getFullTableName( $tb_2 )."
		WHERE id={$mid} LIMIT 1" );
	
	
	
//----------------------------
	
}elseif( $e->name == "OnBeforeSnipFormSave" || $e->name == "OnBeforeSnipFormDelete" ){ // СНИППЕТЫ

	mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\' . $tb_3 )." ( `id`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid` ) SELECT * FROM ".$modx->getFullTableName( $tb_3 )."
		WHERE id={$mid} LIMIT 1" );

	
	
//----------------------------
	
}elseif( $e->name == "OnBeforeTempFormSave" || $e->name == "OnBeforeTempFormDelete" ){ // ШАБЛОНЫ

	mysql_query( "INSERT INTO ".$modx->getFullTableName( \'aaa_\' . $tb_4 )." ( `id`, `templatename`, `description`, `editor_type`, `category`, `icon`, `template_type`, `content`, `locked` ) SELECT * FROM ".$modx->getFullTableName( $tb_4 )."
		WHERE id={$mid} LIMIT 1" );
}';
$p['Highslide'] = '$html= $modx->documentOutput;

if( true || isset( $_GET[ \'test\' ] ) )
{
	preg_match_all( \'/<img(.*)class="(.*)highslidezoom(.*)"(.*)>/imU\', $html, $result );
	
	if( $result )
	{
		foreach( $result[ 0 ] AS $row )
		{
			preg_match_all( \'/src="(.*)"/imU\', $row, $src );
			$img= $modx->runSnippet( \'ImgCrop45\', array( \'img\'=>$src[ 1 ][ 0 ], \'wm\'=>true ) );
			$row2= str_replace( $src[ 1 ][ 0 ], $img, $row );
			if( $src[ 1 ] ) $html= str_replace( $row, \'<a class="highslide" onclick="return hs.expand(this)" href="\'. $img .\'">\'. $row2 .\'</a>\', $html );
		}
	}
}

$modx->documentOutput= $html;';
$p['REDIRECT'] = '$redirect= array(
	1 => array(
		\'/index.html\' => \'/\',
		\'/index.php\' => \'/\',
	)
);


//=================================================================


if( $redirect[ 1 ][ $_SERVER[ \'REQUEST_URI\' ] ] )
{
	header( \'HTTP/1.1 301 Moved Permanently\' );
	header( \'location: \'. $redirect[ 1 ][ $_SERVER[ \'REQUEST_URI\' ] ] );
	exit();
}';
$p['Base_and_Canonical'] = '//v004
//=========================================================================================
//MODX_SITE_URL = http://domain.ru/
	//$_SERVER[ \'REDIRECT_URL\' ] = /sdfsdf/mail.html
	
	//<base href="" />
	//<link rel="canonical" href="http://domain.ru/404.html" />
	//<base_and_canonical>

$html= $modx->documentOutput;

if( true || isset( $_GET[ \'test\' ] ) )
{
	$wsite= rtrim( MODX_SITE_URL, "/" );
	$redirurl= ( ! empty( $_SERVER[ \'REDIRECT_URL\' ] ) ? $_SERVER[ \'REDIRECT_URL\' ] : \'/\' );
	//$redirurl= $modx->makeUrl( $modx->documentIdentifier );
	
	$uri= strpos( $_SERVER[ \'REQUEST_URI\' ], "?" );
	$get= \'\';
	if( $uri !== false )
	{
		$get= substr( $_SERVER[ \'REQUEST_URI\' ], $uri );
	}
	
	$canonical= $wsite . $redirurl .( $get ? $get : \'\' );
	$base= MODX_SITE_URL;
	
	if( ! empty( $canonical ) && ! empty( $base ) )
	{
		$base_and_canonical .= \'<base href="\'. $base .\'" />\';
		$base_and_canonical .= "\\r\\n\\t";
		$base_and_canonical .= \'<link rel="canonical" href="\'. $canonical .\'" />\';
	}
	
	$html= str_replace( "<base_and_canonical />", $base_and_canonical, $html );
	
	/*
	//preg_match_all( "/<link (.*)rel=\\"canonical\\"(.*)href=(\\"(.*)\\"|\'(.*)\')(.*)>/imU", $html, $ss );
	preg_match_all( "/<link (.*)rel=\\"canonical\\"(.*)>/imU", $html, $ss );
	
	if( ! empty( $ss[ 0 ][ 0 ] ) )
	{
		preg_match_all( "/href=(\\"(.*)\\"|\'(.*)\')/imU", $ss[ 0 ][ 0 ], $sss );
		
		$redirurl= ( ! empty( $_SERVER[ \'REDIRECT_URL\' ] ) ? $_SERVER[ \'REDIRECT_URL\' ] : \'/\' );
		
		print \'Установлен: \'. $sss[ 2 ][ 0 ] ."\\r\\n";
		print \'Нужно:      \'. $wsite . $redirurl ."\\r\\n";
	}
	*/
}

$modx->documentOutput= $html;';
$e = &$this->pluginEvent;
$e['OnBeforeChunkFormDelete'] = array('Антиолень 3.0');
$e['OnBeforeChunkFormSave'] = array('Антиолень 3.0');
$e['OnBeforeDocFormDelete'] = array('Антиолень 3.0');
$e['OnBeforeDocFormSave'] = array('ManagerManager','Антиолень 3.0');
$e['OnBeforeManagerLogin'] = array('Forgot Manager Login');
$e['OnBeforePluginFormSave'] = array('FileSource');
$e['OnBeforeSnipFormDelete'] = array('Антиолень 3.0');
$e['OnBeforeSnipFormSave'] = array('FileSource','Антиолень 3.0');
$e['OnBeforeTempFormDelete'] = array('Антиолень 3.0');
$e['OnBeforeTempFormSave'] = array('Антиолень 3.0');
$e['OnChunkFormRender'] = array('CodeMirror');
$e['OnDocDuplicate'] = array('ManagerManager');
$e['OnDocFormPrerender'] = array('ManagerManager');
$e['OnDocFormRender'] = array('ManagerManager','CodeMirror');
$e['OnDocFormSave'] = array('ManagerManager');
$e['OnInterfaceSettingsRender'] = array('TinyMCE Rich Text Editor');
$e['OnManagerAuthentication'] = array('Forgot Manager Login');
$e['OnManagerLoginFormRender'] = array('Forgot Manager Login');
$e['OnModFormRender'] = array('CodeMirror');
$e['OnPluginFormPrerender'] = array('FileSource');
$e['OnPluginFormRender'] = array('ManagerManager','CodeMirror','FileSource');
$e['OnRichTextEditorInit'] = array('TinyMCE Rich Text Editor');
$e['OnRichTextEditorRegister'] = array('TinyMCE Rich Text Editor');
$e['OnSnipFormPrerender'] = array('FileSource');
$e['OnSnipFormRender'] = array('CodeMirror','FileSource');
$e['OnStripAlias'] = array('TransAlias');
$e['OnTempFormRender'] = array('CodeMirror');
$e['OnTVFormRender'] = array('ManagerManager');
$e['OnWebPagePrerender'] = array('Highslide','REDIRECT','Base_and_Canonical');

