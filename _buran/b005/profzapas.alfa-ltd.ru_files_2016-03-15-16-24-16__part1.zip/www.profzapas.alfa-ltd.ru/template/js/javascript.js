

var $= jQuery.noConflict();


$(window).scroll(function(){
	CTM_black();
});
$(window).resize(function(){
	CTM_black();
});


$( document ).ready(function(){
	//------------------------------------------------------------------
	$( '.default_value' ).each(function(){
		var defval= $( this ).data( 'default' );
		if( $( this ).val() == '' || $( this ).val() == defval )
		{
			$( this ).addClass( 'default_value_flag' );
			$( this ).val( $( this ).data( 'default' ) );
		}
	});
	$( '.default_value' ).focus(function(){
		var defval= $( this ).data( 'default' );
		if( $( this ).val() == '' || $( this ).val() == defval )
		{
			$( this ).val( '' );
			$( this ).removeClass( 'default_value_flag' );
		}
	});
	$( '.default_value' ).focusout(function(){
		var defval= $( this ).data( 'default' );
		if( $( this ).val() == '' || $( this ).val() == defval )
		{
			$( this ).val( defval );
			$( this ).addClass( 'default_value_flag' );
		}
	});
	
	//------------------------------------------------------------------
	$( '.tsch_maininput' ).focus(function(){
		$( this ).parent().addClass( 'tsch_pole_focus' );
	});
	$( '.tsch_maininput' ).focusout(function(){
		$( this ).parent().removeClass( 'tsch_pole_focus' );
	});
	
	//------------------------------------------------------------------
	$( '.tsch_dop' ).click(function(){
		if( $( '.topsearch' ).hasClass( 'topsearch_active' ) )
		{
			$( '.topsearch' ).removeClass( 'topsearch_active' );
			$( '.tsch_dop_input_flag' ).val( 'n' );
			$( '.tsch_block_2' )
				.stop()
				.animate({ opacity: 0 }, 300, function(){
					$( this ).hide();
				});
			}else{
			$( '.topsearch' ).addClass( 'topsearch_active' );
			$( '.tsch_dop_input_flag' ).val( 'y' );
			$( '.tsch_block_2' )
				.stop()
				.css({ opacity: 0 })
				.show()
				.animate({ opacity: 1 }, 500 );
		}
	});
	
	//------------------------------------------------------------------
	$( 'form' ).submit(function( event ){
		if( $( '.default_value', this ).val() == $( '.default_value', this ).data( 'default' ) )
			$( '.default_value', this ).val( '' );
	});
	
	//------------------------------------------------------------------
	$( '.catalog_table .descr' ).hover(function(){
		$( '.fulldescription', $( this ).parent() ).addClass( 'active' )
			.stop()
			.css({ opacity: 0 })
			.show()
			.animate({ opacity: 1 }, 200 );
	},function(){
		$( '.fulldescription', $( this ).parent() ).removeClass( 'active' ).stop().hide();
	});
	
	//------------------------------------------------------------------
	$( '.catalog_top_menu .ctm_button' ).click(function(){
		if( $( '.catalog_top_menu' ).hasClass( 'open' ) )
		{
			$( '.mainwrapper' ).css({ overflow: 'auto', height: 'auto' });
			$( '.catalog_top_menu' ).removeClass( 'open' );
			$( '.catalog_top_menu .ctm_black' )
				.stop()
				.animate({ opacity: 0 }, 200, function(){
					$( this ).hide();
				});
			$( '.catalog_top_menu .ctm_catalog' )
				.stop()
				.animate({ opacity: 0 }, 200, function(){
					$( this ).hide();
				});
		}else{
			//$( 'body' ).css({ overflow: 'hidden' });
			$( '.catalog_top_menu' ).addClass( 'open' );
			CTM_black();
			$( '.catalog_top_menu .ctm_black' )
				.stop()
				.css({ opacity: 0 })
				.show()
				.animate({ opacity: 1 }, 300 );
			$( '.catalog_top_menu .ctm_catalog' )
				.stop()
				.css({ opacity: 0 })
				.show()
				.animate({ opacity: 1 }, 300 );
			$( '.mainwrapper' ).css({ overflow: 'hidden', height: $( '.ctm_catalog_abs' ).offset().top + $( '.ctm_catalog_abs' ).outerHeight() + 50 });
		}
	});
	
	//------------------------------------------------------------------
});



$(window).load(function(){
	//------------------------------------------------------------------
	$( '.catalog_table .jqtric_name' ).each(function(){
		if( $( '.descr', this ).height() < 70 ) $( '.fulldescription', this ).remove();
		else $( '.descr', this ).append( '<div class="shadow">&nbsp;</div>' );
	});
	
	//------------------------------------------------------------------
});



function CTM_black()
{
	if( ! $( '.catalog_top_menu' ).hasClass( 'open' ) ) return;
	$( '.catalog_top_menu .ctm_black' ).css({
		width: $(window).width(),
		height: $(window).height(),
		left: 0,
		top: $(window).scrollTop()
	});
}







