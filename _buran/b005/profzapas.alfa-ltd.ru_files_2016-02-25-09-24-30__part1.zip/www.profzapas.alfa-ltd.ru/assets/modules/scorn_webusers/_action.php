<?php


$sc_site= 'profzapas.ru';
$sm_base= '../assets/modules/scorn_webusers/';
$module_url= MODX_MANAGER_URL .'?a='. $_GET[ 'a' ] .'&id='. $_GET[ 'id' ];
$module_url_orders= MODX_MANAGER_URL .'?a=112&id=3';

$webuser= intval( $_GET[ 'wu' ] );
$subpage= $_GET[ 'spg' ];
$act= $_GET[ 'act' ];







if( $result != '' ) $result .= '<br /><br />';
if( $result2 != '' ) $result2 .= '<br /><br />';

?><div class="modul_scorn_all">
<!-- -------------------------- -->
<link rel="stylesheet" type="text/css" href="<?php print $sm_base;?>_styles.css" />
<script type="text/javascript" src="//yandex.st/jquery/2.1.0/jquery.min.js"></script>
<script type="text/javascript" src="//yandex.st/jquery-ui/1.10.4/jquery-ui.min.js"></script>


<div class="topmenu">
	<ul>
		<li><a href="<?= $module_url ?>">Физ.лица</a></li>
		<li><a href="<?= $module_url ?>&spg=urlica">Юр.лица</a></li>
		<li><a href="<?= $module_url ?>&spg=search">Поиск</a></li>
	</ul>
	<div class="clr">&nbsp;</div>
</div>

<script type="text/javascript">
</script>



<?php

//===============================================================================================================
if( $subpage == 'urlica' )
{
	
	
	
	
	
	
	
	
	
	
	
	
	
//===============================================================================================================
}elseif( $subpage == 'search' ){
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//===============================================================================================================
}else{
	$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( '_user' )." WHERE urlico!='n1' ORDER BY enabled, id DESC" );
	if( $rr && mysql_num_rows( $rr ) > 0 )
	{
		$print .= '<table class="userstable">';
		while( $row= mysql_fetch_assoc( $rr ) )
		{
			$print .= '<tr>
				<td>'. $row[ 'id' ] .'</td>
			</tr>';
		}
		$print .= '</table>';
	}
}


if( $_GET[ 'act' ] == 'seluser' && $webuser )
{
$rr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( '_user' )." WHERE id={$webuser} LIMIT 1" );
if( $rr && mysql_num_rows( $rr ) == 1 )
{
	$wui= mysql_fetch_assoc( $rr );
	
	$balance= $modx->runSnippet( 'UserBalance', array( 'type' => 'balance', 'user' => $wui[ 'id' ] ) );
	
	$rrr= mysql_query( "SELECT COUNT(id) AS cc FROM ".$modx->getFullTableName( '_shop_orders' )." WHERE iduser=". $wui[ 'id' ] ."" );
	$orderscc= ( $rrr && mysql_num_rows( $rrr ) == 1 ? mysql_result( $rrr, 0, 'cc' ) : 0 );
	
	$print .= '<table class="userinfoedit" cellpadding="0" cellspacing="0">';
	
	$print .= '<tr><td class="tit">ID</td>
	<td>'. $wui[ 'id' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">Имя, Фамилия</td>
	<td>'. $wui[ 'fio' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">E-mail</td>
	<td>'. $wui[ 'email' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">Телефон</td>
	<td>'. $wui[ 'phone' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">Почтовый индекс</td>
	<td>'. $wui[ 'zip' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">Страна</td>
	<td>'. $wui[ 'strana' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">Регион</td>
	<td>'. $wui[ 'region' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">Город</td>
	<td>'. $wui[ 'gorod' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">Адрес</td>
	<td>'. $wui[ 'adres' ] .'</td></tr>';
	
	$print .= '<tr><td class="tit">Дата регистрации</td>
	<td>'. date( 'd.m.Y, H:i', $wui[ 'dt' ] ) .'</td></tr>';
	
	$print .= '<tr><td class="tit">Кол-во заказов</td>
	<td>'. $orderscc .'<br /><br /><a class="link" href="'. $module_url_orders .'&wu='. $webuser .'">показать заказы этого покупателя</a></td></tr>';
	
	$print .= '<tr><td class="tit">Баллов на счету</td>
	<td>'. $balance .'</td></tr>';
	
	$print .= '</table><br /><br />';
	
	$rrr= mysql_query( "SELECT * FROM ".$modx->getFullTableName( '_balance' )." WHERE userid={$webuser} ORDER BY dt DESC" );
	if( $rrr && mysql_num_rows( $rrr ) > 0 )
	{
		$print .= '<table class="userinfoedit" cellpadding="0" cellspacing="0">';
			$print .= '<tr>
				<td class="tit">Описание</td>
				<td class="col_tit">Зачисление</td>
				<td class="col_tit">Списание</td>
				<td class="col_tit">Баланс</td>
				<td class="">Дата и время</td>
			</tr>';
		while( $row= mysql_fetch_assoc( $rrr ) )
		{
			$print .= '<tr>
				<td class="tit minpadding">'. $row[ 'descr' ] .'</td>
				<td class="plus minpadding">'.( $row[ 'plus' ] ? $row[ 'plus' ] : '' ).'</td>
				<td class="minus minpadding">'.( $row[ 'minus' ] ? $row[ 'minus' ] : '' ).'</td>
				<td class="balance minpadding">'. $row[ 'balance' ] .'</td>
				<td class="bldt minpadding">'. date( 'd.m.Y, H:i', $row[ 'dt' ] ) .'</td>
			</tr>';
		}
		$print .= '</table>';
	}
}
	
	
	
	
	
	
	
	

}else{
}

print $print;

/*
*/
?>