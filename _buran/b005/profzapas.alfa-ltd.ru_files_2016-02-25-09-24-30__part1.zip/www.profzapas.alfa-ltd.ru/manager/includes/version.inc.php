<?php
$modx_version = '1.0.15';           // Current version number
$modx_release_date = 'Oct 31, 2014'; // Date of release
$modx_branch = 'Evolution';        // Codebase name
$modx_full_appname = 'MODX '.$modx_branch.' '.$modx_version.' ('.$modx_release_date.')';
