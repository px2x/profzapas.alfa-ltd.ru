

var $= jQuery.noConflict();



$( document ).ready(function(){
	//------------------------------------------------------------------
	if( $( '.input_mask_mobile' ).length ) $( '.input_mask_mobile' ).mask( '+7 999 999-9999' );
	
	//------------------------------------------------------------------
	$( '.vkladki_butts .vkldk_butt' ).click(function(){
		var id1= $( '.vkladki_butts .active' ).data( 'id' );
		var id2= $( this ).data( 'id' );
		if( ! $( this ).hasClass( 'active' ) )
		{
			var e1= $( '.vkldk_div_'+id1 );
			var e2= $( '.vkldk_div_'+id2 );
			
			$( '.vkladki_butts .active' ).removeClass( 'active' );
			$( this ).addClass( 'active' );
			e1.css({ zIndex: 1 });
			e2.css({ zIndex: 5, opacity: 0 });
			e1.removeClass( 'active' );
			e2.addClass( 'active' );
			e1.stop();
			e2.stop();
			e1.animate({ opacity: 0 }, 300, function(){ e1.hide(); });
			e2.show();
			e2.animate({ opacity: 1 }, 300 );
		}
	});
	
	//------------------------------------------------------------------
	$( '.LK_form_urlico_checkbox' ).change(function(){
		var flag= $( this ).is(':checked');
		if( flag )
		{
			$( '.LK_form_urlico' ).addClass( 'LK_form_urlico_active' );
		}else{
			$( '.LK_form_urlico' ).removeClass( 'LK_form_urlico_active' );
		}
	});
	
	//------------------------------------------------------------------
});



$(window).load(function(){
	//------------------------------------------------------------------
	var maxheight= 0;
	$( '.vkladki_divs .vkldk_div' ).each(function(){
		if( $( this ).outerHeight( true ) > maxheight ) maxheight= $( this ).outerHeight( true );
	});
	$( '.vkladki_divs' ).css({ height: maxheight });
	
	//------------------------------------------------------------------
});











