<?php
define('MODX_SITE_HOSTNAMES', '');
