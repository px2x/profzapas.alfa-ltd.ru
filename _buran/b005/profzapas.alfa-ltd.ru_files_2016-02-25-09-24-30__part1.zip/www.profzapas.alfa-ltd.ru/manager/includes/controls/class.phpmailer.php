<?php
include_once(MODX_MANAGER_PATH . 'includes/controls/phpmailer/class.phpmailer.php');
